'use client';

import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { AlertCircle, Loader2 } from 'lucide-react';
import { AIgendLogo } from '@/components/icons';
import { useTranslations } from 'next-intl';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export default function LoginPage() {
  const { signInWithGoogle, loading, user, isFirebaseEnabled, authError, authErrorDetails } = useAuth();
  const tLogin = useTranslations('Login');

  if (loading && !authError) {
    return (
      <main className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </main>
    );
  }
  
  if (user) {
    // Redirecting is handled in the AuthContext, so we just show a loader
    return (
      <main className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </main>
    );
  }

  return (
    <main className="flex h-screen w-full items-center justify-center p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
          <AIgendLogo className="mx-auto h-16 w-16 text-primary mb-4" />
          <CardTitle>{tLogin('title')}</CardTitle>
          <CardDescription>{tLogin('description')}</CardDescription>
        </CardHeader>
        <CardContent>
          {authError && (
            <Alert variant="destructive" className="mb-6 text-left">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>{tLogin('errorTitle')}</AlertTitle>
              <AlertDescription>
                <p>{tLogin(authError as any)}</p>
                {authError === 'unauthorizedDomainError' && (
                  <>
                    {authErrorDetails && (
                      <p className="mt-2 font-mono bg-muted p-2 rounded-md text-sm text-foreground">
                        {tLogin('authorizeThisDomain')}: <br/><strong>{authErrorDetails}</strong>
                      </p>
                    )}
                    <a
                      href={`https://console.firebase.google.com/project/${process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID}/authentication/settings`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-2 inline-block text-sm font-bold text-white underline"
                    >
                      {tLogin('goToFirebaseSettings')}
                    </a>
                  </>
                )}
              </AlertDescription>
            </Alert>
          )}

          <div className="flex flex-col gap-4">
            <Button
              onClick={signInWithGoogle}
              className="w-full shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold"
              size="lg"
              disabled={loading || !isFirebaseEnabled}
            >
              {loading && !user ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <svg className="mr-2 h-4 w-4" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512">
                  <path fill="currentColor" d="M488 261.8C488 403.3 381.5 512 244 512 109.8 512 0 402.2 0 261.8 0 121.2 109.8 11.2 244 11.2c67.3 0 122.5 24.8 166.7 68.2l-77.8 77.8c-33.5-31.5-76.3-51.5-124.2-51.5-94.8 0-172.2 77.2-172.2 172.2s77.3 172.2 172.2 172.2c103 0 149.3-77.3 154.5-116.1H244v-96h244z"></path>
                </svg>
              )}
              <span className="drop-shadow-cyan-glow">{tLogin('signInWithGoogle')}</span>
            </Button>
            
            {!isFirebaseEnabled && (
                <p className="text-xs text-muted-foreground text-center px-4">
                    {tLogin('firebaseNotConfigured')}
                </p>
            )}

          </div>
        </CardContent>
      </Card>
    </main>
  );
}
