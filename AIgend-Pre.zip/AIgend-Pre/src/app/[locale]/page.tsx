
"use client";

import * as React from "react";
import dynamic from 'next/dynamic';
import { ChevronLeft, ChevronRight, Loader2, Minimize2 } from "lucide-react";
import { useTranslations } from "next-intl";

import { useAuth } from '@/contexts/AuthContext';
import { useCalendar } from "@/contexts/CalendarContext";
import { useFinancialData } from "@/contexts/FinancialContext";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeHeader } from "@/components/home/HomeHeader";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

// --- Dynamic Imports for Lazy Loading ---
const DynamicDailyBriefing = dynamic(
  () => import('@/components/home/DailyBriefing').then(mod => mod.DailyBriefing),
  {
    loading: () => <div className="flex justify-center"><Skeleton className="h-[650px] w-full max-w-3xl" /></div>,
    ssr: false
  }
);

export default function HomePage() {
  const tPage = useTranslations("Page");
  const tHome = useTranslations("Home");
  const tBriefing = useTranslations("DailyBriefing");
  const { loading: authLoading } = useAuth();
  const { events, loading: eventsLoading } = useCalendar();
  const { financialData: personalData, loading: financialDataLoading } = useFinancialData();

  // Tab state management
  const tabs = React.useMemo(() => [
    { value: 'introduction', label: tHome('introductionTab') },
    { value: 'briefing', label: tHome('briefingTab') },
  ], [tHome]);

  const [activeTab, setActiveTab] = React.useState(tabs[0].value);
  const activeTabIndex = React.useMemo(() => tabs.findIndex(tab => tab.value === activeTab), [tabs, activeTab]);
  
  const [expandedView, setExpandedView] = React.useState<string | null>(null);

  const handlePrevTab = () => {
    const newIndex = activeTabIndex > 0 ? activeTabIndex - 1 : tabs.length - 1;
    setActiveTab(tabs[newIndex].value);
  };

  const handleNextTab = () => {
    const newIndex = activeTabIndex < tabs.length - 1 ? activeTabIndex + 1 : 0;
    setActiveTab(tabs[newIndex].value);
  };

  const loading = eventsLoading || authLoading || financialDataLoading;

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2 text-lg">{tPage('loading')}</p>
      </div>
    );
  }

  return (
    <>
      <div className="flex flex-col min-h-screen text-foreground">
        <HomeHeader />
        <main className="flex-1 flex flex-col p-4 lg:p-6 overflow-auto items-center">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full max-w-4xl space-y-4">
              <div className="flex items-center justify-center gap-4 px-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrevTab}>
                      <ChevronLeft className="h-5 w-5" />
                  </Button>

                  <div className="flex items-center justify-center gap-4 flex-1">
                      {tabs.map((tab, index) => (
                          <button
                              key={tab.value}
                              onClick={() => setActiveTab(tab.value)}
                              className={cn(
                                  "py-1 font-medium transition-colors",
                                  activeTabIndex === index
                                      ? "text-foreground text-sm"
                                      : "text-muted-foreground text-2xl leading-none"
                              )}
                          >
                              {activeTabIndex === index ? tab.label : '•'}
                          </button>
                      ))}
                  </div>
                  
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNextTab}>
                      <ChevronRight className="h-5 w-5" />
                  </Button>
              </div>
              
              <TabsContent value="introduction" className="mt-4">
                <Card className="w-full max-w-3xl mx-auto">
                  <CardHeader>
                      <CardTitle>{tHome('introductionTitle')}</CardTitle>
                      <CardDescription>{tHome('introductionDescription')}</CardDescription>
                  </CardHeader>
                  <CardContent className="prose prose-sm dark:prose-invert max-w-none space-y-4">
                      <div>
                        <h4>{tHome('introductionSubtitle1')}</h4>
                        <p>{tHome('introductionContent1')}</p>
                      </div>
                      <div>
                        <h4>{tHome('introductionSubtitle2')}</h4>
                        <p>{tHome('introductionContent2')}</p>
                      </div>
                      <div>
                        <h4>{tHome('introductionSubtitle3')}</h4>
                        <p>{tHome('introductionContent3')}</p>
                      </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="briefing" className="mt-4">
                <div onClick={() => setExpandedView('briefing')} className="cursor-pointer">
                  <DynamicDailyBriefing personalData={personalData} events={events} />
                </div>
              </TabsContent>

          </Tabs>
        </main>
      </div>

      {expandedView && (
        <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0">
          <div className="w-full h-full flex flex-col p-4 md:p-6">
            <header className="flex items-center justify-between pb-4 shrink-0">
                <h2 className="text-2xl font-bold">{tBriefing('title')}</h2>
                <Button variant="ghost" size="icon" onClick={() => setExpandedView(null)}>
                    <Minimize2 className="h-6 w-6" />
                    <span className="sr-only">Minimize</span>
                </Button>
            </header>
            <div className="flex-1 overflow-auto flex items-center justify-center">
              {expandedView === 'briefing' && (
                <div className="h-full w-full">
                  <DynamicDailyBriefing personalData={personalData} events={events} />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
