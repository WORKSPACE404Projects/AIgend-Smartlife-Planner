'use client';

import * as React from 'react';
import { CheckersHeader } from '@/components/games/CheckersHeader';
import { Checkers } from '@/components/games/Checkers';

export default function CheckersPage() {

  return (
    <div className="flex h-screen flex-col text-foreground">
      <CheckersHeader />
      <main className="flex-1 overflow-auto p-4 md:p-6 flex flex-col items-center justify-center">
        <Checkers />
      </main>
    </div>
  );
}
