
'use client';

import * as React from 'react';
import { useFinancialData } from "@/contexts/FinancialContext";
import { DietView } from "@/components/diet/DietView";
import { Loader2 } from "lucide-react";
import { useTranslations } from "next-intl";
import { useAuth } from "@/contexts/AuthContext";
import { useCalendar } from '@/contexts/CalendarContext';
import { EventDialog } from '@/components/calendar/EventDialog';
import type { CalendarEvent } from '@/lib/types';

export default function DietPage() {
  const { financialData: personalData, loading: financialDataLoading } = useFinancialData();
  const { loading: authLoading } = useAuth();
  const { events, loading: eventsLoading } = useCalendar();
  const tPage = useTranslations('Page');

  const dietEvents = React.useMemo(() => {
    return events.filter(e => e.category === 'diet');
  }, [events]);

  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [selectedEvent, setSelectedEvent] = React.useState<CalendarEvent | null>(null);

  const handleEditEvent = (event: CalendarEvent) => {
    setSelectedEvent(event);
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setSelectedEvent(null);
  };

  const loading = financialDataLoading || authLoading || eventsLoading;

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2 text-lg">{tPage('loading')}</p>
      </div>
    );
  }

  return (
    <>
      <DietView 
        personalData={personalData} 
        dietEvents={dietEvents}
        onEventClick={handleEditEvent}
      />
      <EventDialog
        isOpen={isDialogOpen}
        onOpenChange={handleCloseDialog}
        event={selectedEvent}
        date={null}
      />
    </>
  );
}
