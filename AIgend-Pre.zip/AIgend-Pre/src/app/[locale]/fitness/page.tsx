
'use client';

import * as React from 'react';
import { useFinancialData } from "@/contexts/FinancialContext";
import { FitnessView } from "@/components/fitness/FitnessView";
import { Loader2 } from "lucide-react";
import { useTranslations } from "next-intl";
import { useAuth } from "@/contexts/AuthContext";
import { useCalendar } from '@/contexts/CalendarContext';
import { EventDialog } from '@/components/calendar/EventDialog';
import type { CalendarEvent } from '@/lib/types';
import { LogWorkoutDialog } from '@/components/fitness/LogWorkoutDialog';

export default function FitnessPage() {
  const { financialData: personalData, loading: financialDataLoading } = useFinancialData();
  const { loading: authLoading } = useAuth();
  const { events, loading: eventsLoading } = useCalendar();
  const tPage = useTranslations('Page');

  const fitnessEvents = React.useMemo(() => {
    return events.filter(e => e.category === 'fitness');
  }, [events]);

  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [selectedEvent, setSelectedEvent] = React.useState<CalendarEvent | null>(null);

  const [isLogDialogOpen, setIsLogDialogOpen] = React.useState(false);
  const [selectedEventForLog, setSelectedEventForLog] = React.useState<CalendarEvent | null>(null);

  const handleEditEvent = (event: CalendarEvent) => {
    setSelectedEvent(event);
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setSelectedEvent(null);
  };
  
  const handleLogClick = (event: CalendarEvent) => {
    setSelectedEventForLog(event);
    setIsLogDialogOpen(true);
  };

  const handleCloseLogDialog = () => {
    setIsLogDialogOpen(false);
    setSelectedEventForLog(null);
  };

  const loading = financialDataLoading || authLoading || eventsLoading;

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2 text-lg">{tPage('loading')}</p>
      </div>
    );
  }

  return (
    <>
      <FitnessView 
        personalData={personalData} 
        fitnessEvents={fitnessEvents}
        onEventClick={handleEditEvent}
        onLogClick={handleLogClick}
      />
      <EventDialog
        isOpen={isDialogOpen}
        onOpenChange={handleCloseDialog}
        event={selectedEvent}
        date={null}
      />
       <LogWorkoutDialog
        isOpen={isLogDialogOpen}
        onOpenChange={handleCloseLogDialog}
        event={selectedEventForLog}
      />
    </>
  );
}
