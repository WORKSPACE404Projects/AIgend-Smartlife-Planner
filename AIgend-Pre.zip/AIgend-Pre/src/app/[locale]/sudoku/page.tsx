
'use client';

import * as React from 'react';
import { SudokuHeader } from '@/components/games/SudokuHeader';
import { Sudoku } from '@/components/games/Sudoku';

export default function SudokuPage() {

  return (
    <div className="flex h-screen flex-col text-foreground">
      <SudokuHeader />
      <main className="flex-1 overflow-auto p-4 md:p-6 flex flex-col items-center justify-center">
        <Sudoku />
      </main>
    </div>
  );
}
