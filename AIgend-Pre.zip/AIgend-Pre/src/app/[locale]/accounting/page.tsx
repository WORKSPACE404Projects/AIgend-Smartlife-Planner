
'use client';

import * as React from 'react';
import { useFinancialData } from '@/contexts/FinancialContext';
import { AccountingView } from '@/components/accounting/AccountingView';
import { Loader2 } from 'lucide-react';
import { useTranslations } from 'next-intl';
import { useAuth } from '@/contexts/AuthContext';
import { useAccounting } from '@/contexts/AccountingContext';

export default function AccountingPage() {
  const { financialData, loading: financialDataLoading } = useFinancialData();
  const { transactions, loading: transactionsLoading } = useAccounting();
  const { user, loading: authLoading } = useAuth();
  const tPage = useTranslations('Page');
  
  const loading = financialDataLoading || transactionsLoading || authLoading;

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2 text-lg">{tPage('loading')}</p>
      </div>
    );
  }

  return <AccountingView transactions={transactions} personalData={financialData} />;
}
