
"use client";

import * as React from "react";
import dynamic from 'next/dynamic';
import { startOfToday, add, sub, format, isSameDay } from "date-fns";
import { Bot, Loader2, Minimize2 } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";

import { Header } from "@/components/calendar/Header";
import { EventDialog } from "@/components/calendar/EventDialog";
import type { CalendarEvent } from "@/lib/types";
import { useAuth } from '@/contexts/AuthContext';
import { useCalendar } from "@/contexts/CalendarContext";
import { Skeleton } from "@/components/ui/skeleton";
import { useFinancialData } from "@/contexts/FinancialContext";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AgentChat } from "@/components/home/AgentChat";
import { cn } from "@/lib/utils";
import { getDateFnsLocale } from "@/lib/i18n";


const DynamicCalendar = dynamic(
  () => import('@/components/calendar/Calendar').then(mod => mod.Calendar),
  {
    loading: () => <Skeleton className="h-full w-full min-h-[600px]" />,
    ssr: false
  }
);

const DynamicDailyView = dynamic(
  () => import('@/components/calendar/DailyView').then(mod => mod.DailyView),
  {
    loading: () => <Skeleton className="h-full w-full" />,
    ssr: false
  }
);

export default function CalendarPage() {
  const tPage = useTranslations("Page");
  const tHeader = useTranslations("Header");
  const tAgent = useTranslations("PlanningAgent");
  const tCalendar = useTranslations("CalendarPage");
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);

  const { loading: authLoading } = useAuth();
  const { events, loading: eventsLoading } = useCalendar();
  const { financialData: personalData, loading: financialDataLoading } = useFinancialData();

  const generalEvents = React.useMemo(() => {
    return events.filter(e => e.category === 'general' || !e.category);
  }, [events]);
  
  const today = startOfToday();
  const [view, setView] = React.useState<"month" | "week" | "day">("month");
  const [currentDate, setCurrentDate] = React.useState<Date>(today);
  
  const [isEventDialogOpen, setIsEventDialogOpen] = React.useState(false);
  const [selectedEvent, setSelectedEvent] = React.useState<CalendarEvent | null>(null);
  const [dialogDate, setDialogDate] = React.useState<Date | null>(null);
  
  const [isAgentChatOpen, setIsAgentChatOpen] = React.useState(false);
  const [fullScreenDate, setFullScreenDate] = React.useState<Date | null>(null);
  
  const handleAddEvent = (date?: Date) => {
    setSelectedEvent(null);
    setDialogDate(date || new Date());
    setIsEventDialogOpen(true);
  };

  const handleEditEvent = (event: CalendarEvent) => {
    setSelectedEvent(event);
    setDialogDate(null);
    setIsEventDialogOpen(true);
  };

  const handleMonthCellClick = (date: Date) => {
    setFullScreenDate(date);
  };

  const handleCloseDialog = () => {
    setIsEventDialogOpen(false);
    setSelectedEvent(null);
    setDialogDate(null);
  }

  const handlePrev = () => {
    const period = view === 'month' ? { months: 1 } : view === 'week' ? { weeks: 1 } : { days: 1 };
    setCurrentDate(sub(currentDate, period));
  };

  const handleNext = () => {
    const period = view === 'month' ? { months: 1 } : view === 'week' ? { weeks: 1 } : { days: 1 };
    setCurrentDate(add(currentDate, period));
  };
  
  const handleToday = () => {
    setCurrentDate(new Date());
  };

  const loading = eventsLoading || authLoading || financialDataLoading;

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2 text-lg">{tPage('loading')}</p>
      </div>
    );
  }

  return (
    <>
      <div className="flex h-screen flex-col">
        <Header
          currentDate={currentDate}
          onPrev={handlePrev}
          onNext={handleNext}
          onAddEvent={() => handleAddEvent()}
        />
        <main className="flex-1 flex flex-col overflow-hidden relative">
          <DynamicCalendar
              view={view}
              currentDate={currentDate}
              events={generalEvents}
              onEventClick={handleEditEvent}
              onCellClick={view === 'month' ? handleMonthCellClick : handleAddEvent}
          />
          <div className="absolute bottom-6 left-6 flex flex-col items-start gap-1 z-10">
              <Button 
                  onClick={handleToday} 
                  variant="ghost" 
                  size="sm" 
                  className="h-7 px-3 text-xs rounded-md border bg-background/80 dark:bg-gray-950/70 backdrop-blur-sm shadow-lg"
              >
                  {tHeader('today')}
              </Button>
              <div className="flex rounded-md bg-background/80 dark:bg-gray-950/70 backdrop-blur-sm shadow-lg p-0.5 border">
                  <Button
                      variant="ghost"
                      size="sm"
                      className={cn("h-7 px-2 text-xs", view === "month" && "text-cyan-400 drop-shadow-cyan-glow")}
                      onClick={() => setView("month")}
                  >
                      {tHeader('month')}
                  </Button>
                  <Button
                      variant="ghost"
                      size="sm"
                      className={cn("h-7 px-2 text-xs", view === "week" && "text-cyan-400 drop-shadow-cyan-glow")}
                      onClick={() => setView("week")}
                  >
                      {tHeader('week')}
                  </Button>
                  <Button
                      variant="ghost"
                      size="sm"
                      className={cn("h-7 px-2 text-xs", view === "day" && "text-cyan-400 drop-shadow-cyan-glow")}
                      onClick={() => setView("day")}
                  >
                      {tHeader('day')}
                  </Button>
              </div>
          </div>
          <Button 
            className="absolute bottom-6 right-6 h-14 w-14 rounded-full shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 transition-all"
            size="icon"
            onClick={() => setIsAgentChatOpen(true)}
          >
            <Bot className="h-7 w-7 text-cyan-400 drop-shadow-cyan-glow" />
            <span className="sr-only">Open Planning Agent</span>
          </Button>
        </main>
        <EventDialog
          isOpen={isEventDialogOpen}
          onOpenChange={handleCloseDialog}
          event={selectedEvent}
          date={dialogDate}
        />
        <Dialog open={isAgentChatOpen} onOpenChange={setIsAgentChatOpen}>
          <DialogContent className="sm:max-w-2xl h-[80vh] flex flex-col p-0 gap-0">
            <DialogHeader className="sr-only">
              <DialogTitle>{tAgent('title')}</DialogTitle>
            </DialogHeader>
            <AgentChat personalData={personalData} generalEvents={generalEvents} />
          </DialogContent>
        </Dialog>
      </div>
      
      {fullScreenDate && (
        <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0">
          <div className="w-full h-full flex flex-col p-4 md:p-6">
            <header className="flex items-center justify-between pb-4 shrink-0">
              <h2 className="text-2xl font-bold">
                {format(fullScreenDate, 'PPPP', { locale: dateFnsLocale })}
              </h2>
              <Button variant="ghost" size="icon" onClick={() => setFullScreenDate(null)}>
                <Minimize2 className="h-6 w-6" />
                <span className="sr-only">{tCalendar('closeDayView')}</span>
              </Button>
            </header>
            <div className="flex-1 overflow-auto">
              <DynamicDailyView
                currentDate={fullScreenDate}
                events={events}
                onEventClick={(event) => {
                  setFullScreenDate(null);
                  handleEditEvent(event);
                }}
                onCellClick={(date) => {
                  setFullScreenDate(null);
                  handleAddEvent(date);
                }}
              />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
