'use client';

import * as React from 'react';
import { SettingsHeader } from '@/components/settings/SettingsHeader';
import { SettingsView } from '@/components/settings/SettingsView';

export default function SettingsPage() {

  return (
    <div className="flex h-screen flex-col text-foreground">
      <SettingsHeader />
      <main className="h-[85vh] overflow-auto p-4 md:p-6">
        <SettingsView />
      </main>
    </div>
  );
}
