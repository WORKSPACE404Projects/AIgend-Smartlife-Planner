
'use client';

import * as React from 'react';
import { SubscriptionHeader } from '@/components/subscription/SubscriptionHeader';
import { SubscriptionView } from '@/components/subscription/SubscriptionView';

export default function SubscriptionPage() {

  return (
    <div className="flex h-screen flex-col text-foreground">
      <SubscriptionHeader />
      <main className="h-[85vh] overflow-auto p-4 md:p-6">
        <SubscriptionView />
      </main>
    </div>
  );
}
