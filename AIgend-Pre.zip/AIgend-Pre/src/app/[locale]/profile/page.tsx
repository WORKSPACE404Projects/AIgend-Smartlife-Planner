
'use client';

import * as React from 'react';
import { useFinancialData } from "@/contexts/FinancialContext";
import { ProfileForm } from "@/components/profile/ProfileForm";
import { Loader2, Gem, Power, Copy } from "lucide-react";
import { useTranslations } from "next-intl";
import { useAuth } from "@/contexts/AuthContext";
import { ProfileHeader } from '@/components/profile/ProfileHeader';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export default function ProfilePage() {
  const { financialData, loading: financialDataLoading } = useFinancialData();
  const { user, loading: authLoading } = useAuth();
  const tPage = useTranslations('Page');
  const tProfile = useTranslations('Profile');
  const { toast } = useToast();

  const loading = financialDataLoading || authLoading;

  const handleCopyUid = () => {
    if (user?.uid) {
      navigator.clipboard.writeText(user.uid);
      toast({
        title: tProfile('uidCopied'),
      });
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <p className="ml-2 text-lg">{tPage('loading')}</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col text-foreground">
      <ProfileHeader />
      <main className="flex-1 overflow-auto p-4 md:p-6">
        <div className="max-w-4xl mx-auto space-y-8 pb-8">
            <Card>
                <CardHeader>
                    <CardTitle>{tProfile('accountInfoTitle')}</CardTitle>
                    <CardDescription>{tProfile('accountInfoDescription')}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="space-y-2">
                        <Label htmlFor="uid">{tProfile('userIdLabel')}</Label>
                        <div className="flex items-center gap-2">
                            <Input id="uid" value={user?.uid ?? 'N/A'} readOnly className="font-mono text-xs" />
                            <Button variant="ghost" size="icon" onClick={handleCopyUid}>
                               <Copy className="h-4 w-4" />
                            </Button>
                        </div>
                    </div>
                     <div className="space-y-2">
                        <Label>{tProfile('planLabel')}</Label>
                        {/* This would be dynamic based on user's subscription status */}
                        <div className="flex items-center gap-2 text-lg font-semibold">
                            <Gem className="h-5 w-5 text-primary" />
                            <span>{tProfile('planPremium')}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{tProfile('billingAnnually')}</p>
                    </div>

                    <div className="flex items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                            <Label htmlFor="auto-renew" className="font-semibold">{tProfile('autoRenewLabel')}</Label>
                            <p className="text-sm text-muted-foreground">
                                {tProfile('autoRenewDescription')}
                            </p>
                        </div>
                        {/* This would be dynamic based on user's subscription status */}
                        <Switch id="auto-renew" defaultChecked />
                    </div>
                </CardContent>
            </Card>

            <ProfileForm initialData={financialData} />
        </div>
      </main>
    </div>
  );
}
