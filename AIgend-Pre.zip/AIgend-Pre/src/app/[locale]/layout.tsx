
import { Toaster } from "@/components/ui/toaster";
import { NextIntlClientProvider } from 'next-intl';
import { getMessages, unstable_setRequestLocale } from 'next-intl/server';
import { Providers } from '@/components/Providers';
import { Sidebar } from '@/components/calendar/Sidebar';

export function generateStaticParams() {
  return [{locale: 'es'}];
}

export default async function LocaleLayout({
  children,
  params: {locale}
}: Readonly<{
  children: React.ReactNode;
  params: {locale: string};
}>) {
  unstable_setRequestLocale(locale);
  const messages = await getMessages();

  return (
    <NextIntlClientProvider locale={locale} messages={messages}>
      <Providers attribute="class" defaultTheme="system" enableSystem>
        <Sidebar />
        <div className="md:pl-14">
          {children}
        </div>
        <Toaster />
      </Providers>
    </NextIntlClientProvider>
  );
}
