'use client';

import * as React from 'react';
import { useTranslations } from 'next-intl';
import { GamesHeader } from '@/components/games/GamesHeader';
import { TicTacToe } from '@/components/games/TicTacToe';
import { Card, CardContent } from '@/components/ui/card';

export default function GamesPage() {

  return (
    <div className="flex h-screen flex-col text-foreground">
      <GamesHeader />
      <main className="flex-1 overflow-auto p-4 md:p-6 flex flex-col items-center justify-center">
        <Card className="w-full max-w-sm">
          <CardContent className="p-6">
            <TicTacToe />
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
