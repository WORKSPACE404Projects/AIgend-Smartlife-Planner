import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function NotFound() {
  return (
    <div className="flex h-screen w-full flex-col items-center justify-center text-center bg-background p-4">
      <h1 className="text-4xl font-bold text-foreground">404 - Página No Encontrada</h1>
      <p className="mt-4 text-muted-foreground">
        Lo sentimos, la página que estás buscando no existe.
      </p>
      <Link href="/es" className="mt-6">
          <Button>
            Volver al Inicio
          </Button>
      </Link>
    </div>
  );
}
