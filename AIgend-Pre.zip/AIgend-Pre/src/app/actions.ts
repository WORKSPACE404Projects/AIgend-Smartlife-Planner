
// NOTE: The application's data management has been moved to client-side
// React Contexts (`src/contexts/*`) to support guest mode persistence
// via localStorage. The server actions below were previously used for revalidation
// but are not compatible with the static export (`output: 'export'`) required
// for Capacitor builds. This file is kept as a placeholder for potential future
// backend integration.

export async function revalidateCalendar() {
  // This is a no-op because revalidatePath is not available in static exports.
}

export async function revalidateAccounting() {
  // This is a no-op because revalidatePath is not available in static exports.
}
