
/**
 * @fileOverview Calendar management tools for the central AI assistant.
 * This file is temporarily modified for static export.
 */

// Tool functionality is disabled for static export.
// In a server environment, this would define and export Genkit tools.
export const scheduleEvent = null;
