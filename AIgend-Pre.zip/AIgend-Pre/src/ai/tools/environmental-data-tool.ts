
/**
 * @fileOverview A tool to fetch environmental data like weather and air quality.
 * This file is temporarily modified for static export.
 */

// Tool functionality is disabled for static export.
// In a server environment, this would define and export Genkit tools.
export const getEnvironmentalData = null;
