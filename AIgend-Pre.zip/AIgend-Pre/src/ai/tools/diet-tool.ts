
/**
 * @fileOverview A tool for the AI assistant to access the diet coach functionality.
 * This file is temporarily modified for static export.
 */

// Tool functionality is disabled for static export.
// In a server environment, this would define and export Genkit tools.
export const getDietPlan = null;
