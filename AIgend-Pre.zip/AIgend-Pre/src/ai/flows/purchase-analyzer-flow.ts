
'use server';
/**
 * @fileOverview An AI-powered purchase advisor.
 *
 * - analyzePurchase: A function that analyzes a potential purchase against the user's overall life data.
 * - PurchaseAnalyzerInput: The input type for the analyzePurchase function.
 * - PurchaseAnalyzerOutput: The return type for the analyzePurchase function.
 */

import {ai} from '@/ai/genkit';
import {
  PurchaseAnalyzerInputSchema,
  PurchaseAnalyzerOutputSchema,
  type PurchaseAnalyzerInput,
  type PurchaseAnalyzerOutput,
} from '@/ai/schemas';

export async function analyzePurchase(
  input: PurchaseAnalyzerInput
): Promise<PurchaseAnalyzerOutput> {
  return await purchaseAnalyzerFlow(input);
}

const purchaseAnalyzerPrompt = ai.definePrompt({
  name: 'purchaseAnalyzerPrompt',
  input: {schema: PurchaseAnalyzerInputSchema},
  output: {schema: PurchaseAnalyzerOutputSchema},
  system: `You are an empathetic and insightful financial and life coach named AIgend. Your task is to analyze a potential purchase for the user, considering their entire life context.
The user's locale is '{{locale}}'. You MUST reply in this language.

USER'S DATA:
- Personal and Financial Profile: {{json personalData}}

PURCHASE DETAILS:
- Item/Service: {{purchaseDescription}}
- Cost: {{purchaseAmount}}
- Category: {{purchaseCategory}}
- User's Justification: {{purchaseJustification}}

Your analysis must:
1.  **Assess Affordability**: Can the user truly afford this? Consider their income, expenses, and savings.
2.  **Evaluate Goal Alignment**: Does this purchase help or hinder their financial goals? How does it impact their savings rate and goal timelines?
3.  **Consider Life Context**: Look beyond the numbers. Does this purchase align with their health, fitness, or personal development goals? For example, a new bike for a user with a fitness goal is different from a video game console.
4.  **Provide a Clear Recommendation**: Choose 'recommended', 'caution', or 'not_recommended'.
5.  **Write a Detailed Analysis**: In Markdown format, explain your reasoning. Be empathetic. Acknowledge their justification. If you recommend against it, offer alternatives or a savings plan.
6.  **Summarize the Financial Impact**: Provide a short, direct summary of the financial consequence (e.g., "This will consume 15% of your monthly savings").`,
});

const purchaseAnalyzerFlow = ai.defineFlow(
  {
    name: 'purchaseAnalyzerFlow',
    inputSchema: PurchaseAnalyzerInputSchema,
    outputSchema: PurchaseAnalyzerOutputSchema,
  },
  async input => {
    const {output} = await purchaseAnalyzerPrompt(input);
    return output!;
  }
);
