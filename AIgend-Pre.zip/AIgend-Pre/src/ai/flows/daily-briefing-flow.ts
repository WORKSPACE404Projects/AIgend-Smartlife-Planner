
'use server';
/**
 * @fileOverview A proactive AI agent that generates a daily briefing for the user.
 *
 * - getDailyBriefing - A function that synthesizes user data into a daily summary.
 * - DailyBriefingInput - The input type for the getDailyBriefing function.
 * - DailyBriefingOutput - The return type for the getDailyBriefing function.
 */

import {ai} from '@/ai/genkit';
import {
  DailyBriefingInputSchema,
  DailyBriefingOutputSchema,
  type DailyBriefingInput,
  type DailyBriefingOutput,
} from '@/ai/schemas';
import {getEnvironmentalData} from '@/ai/tools/environmental-data-tool';

export async function getDailyBriefing(
  input: DailyBriefingInput
): Promise<DailyBriefingOutput> {
  return await dailyBriefingFlow(input);
}

const dailyBriefingPrompt = ai.definePrompt({
  name: 'dailyBriefingPrompt',
  input: {schema: DailyBriefingInputSchema},
  output: {schema: DailyBriefingOutputSchema},
  tools: [getEnvironmentalData],
  system: `You are AIgend, a friendly and proactive life planning assistant. Your task is to generate a concise, personalized daily briefing for the user.
The user's name is {{personalData.firstName}}.
The current date is {{currentDate}}.
The user's locale is '{{locale}}'. You MUST reply in this language.

Use the provided tools to get real-time information like weather.
Synthesize information from the user's profile, their calendar for the day, and real-time data to generate the briefing.

The briefing should contain:
1.  **Greeting**: A warm, friendly greeting that changes based on the time of day.
2.  **Weather Summary**: A brief, human-readable summary of the weather.
3.  **Agenda Summary**: A summary of their schedule for today. Mention the number of events.
4.  **Diet Summary**: A relevant tip or reminder based on their diet goals and preferences.
5.  **Finance Summary**: A quick, encouraging note about their financial goals.
6.  **Proactive Suggestion**: This is the most important part. Connect different pieces of information to make a smart suggestion. For example, if their calendar is free, the weather is good, and their goal is fitness, suggest a run.

USER DATA:
- Profile: {{json personalData}}
- Today's Events: {{json events}}`,
});

const dailyBriefingFlow = ai.defineFlow(
  {
    name: 'dailyBriefingFlow',
    inputSchema: DailyBriefingInputSchema,
    outputSchema: DailyBriefingOutputSchema,
  },
  async input => {
    const {output} = await dailyBriefingPrompt(input);
    return output!;
  }
);
