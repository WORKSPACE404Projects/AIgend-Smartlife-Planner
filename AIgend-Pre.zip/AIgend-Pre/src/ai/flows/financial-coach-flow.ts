
'use server';
/**
 * @fileOverview A financial coach AI agent that uses a router to select the best model for the job.
 *
 * Exports:
 * - getFinancialAdvice: A function that provides financial advice based on user data and a query.
 * - FinancialCoachInput: The input type for the getFinancialAdvice function.
 * - FinancialCoachOutput: The return type for the getFinancialAdvice function.
 */
import {ai} from '@/ai/genkit';
import {
  FinancialCoachInputSchema,
  FinancialCoachOutputSchema,
  type FinancialCoachInput,
  type FinancialCoachOutput,
} from '@/ai/schemas';

export async function getFinancialAdvice(
  input: FinancialCoachInput
): Promise<FinancialCoachOutput> {
  return await financialCoachFlow(input);
}

const financialAdvicePrompt = ai.definePrompt({
  name: 'financialAdvicePrompt',
  input: {schema: FinancialCoachInputSchema},
  output: {schema: FinancialCoachOutputSchema},
  system: `You are an expert financial advisor named AIgend. Your tone is encouraging, empathetic, and clear.
The user's name is {{userName}}.
You are helping them with a financial question.

Their current financial data is:
- Total Monthly Income: {{financialData.totalMonthlyIncome}}
- Fixed Monthly Expenses: {{financialData.fixedMonthlyExpenses}}
- Variable Monthly Expenses: {{financialData.variableMonthlyExpenses}}
- Total Debt: {{financialData.totalDebt}}
- Liquid Savings: {{financialData.liquidSavings}}
- Monthly Investment: {{financialData.monthlyInvestment}}
- Financial Goals: {{json financialData.goals}}

The user's specific question is: "{{query}}"

Provide a clear, actionable, and personalized response. Break down complex topics into simple steps.
Your entire response should be contained within the 'advice' field.`,
});

const financialCoachFlow = ai.defineFlow(
  {
    name: 'financialCoachFlow',
    inputSchema: FinancialCoachInputSchema,
    outputSchema: FinancialCoachOutputSchema,
  },
  async input => {
    const {output} = await financialAdvicePrompt(input);
    return output!;
  }
);
