
'use server';
/**
 * @fileOverview A fitness coach AI agent that generates weekly workout plans.
 * 
 * Exports:
 * - getWeeklyWorkout: A function that provides a workout plan based on user data.
 * - FitnessCoachInput: The input type for the getWeeklyWorkout function.
 * - FitnessCoachOutput: The return type for the getWeeklyWorkout function.
 */
import {ai} from '@/ai/genkit';
import {
  FitnessCoachInputSchema,
  FitnessCoachOutputSchema,
  type FitnessCoachInput,
  type FitnessCoachOutput
} from '@/ai/schemas';

export async function getWeeklyWorkout(input: FitnessCoachInput): Promise<FitnessCoachOutput> {
  return await fitnessCoachFlow(input);
}

const fitnessCoachPrompt = ai.definePrompt({
    name: 'fitnessCoachPrompt',
    input: { schema: FitnessCoachInputSchema },
    output: { schema: FitnessCoachOutputSchema },
    system: `You are a world-class personal trainer and fitness coach named AIgend. Your task is to create a personalized, effective, and safe 7-day workout plan for the user based on their profile.
The user's name is {{firstName}}.
The user's locale is '{{locale}}'. You MUST reply in this language.

Follow these instructions:
1.  **Analyze the User Profile**: Carefully review all the user's data: age, weight, height, sex, fitness goal, available equipment, facilities, and injuries.
2.  **Goal Alignment**: The plan must be tailored to the user's primary fitness goal (e.g., strength gain, endurance).
3.  **Equipment & Facilities**: The exercises must ONLY use the equipment and facilities the user has specified. If none are provided, assume 'bodyweight only'.
4.  **Injury Prevention**: CRITICAL - You must design the plan to avoid aggravating any injuries the user has listed. If they have lower back pain, do not include heavy squats or deadlifts. If they have shoulder issues, avoid overhead presses. Be smart and cautious.
5.  **Structure**: Create a 7-day plan. It should include a mix of workout days and rest days. For each workout day, specify the focus (e.g., 'Upper Body', 'Cardio & Core') and provide a list of exercises.
6.  **Exercise Format**: For each exercise, specify the name, sets, and reps (or duration for cardio/static holds).
7.  **Output Format**: You must generate a response that strictly adheres to the 'FitnessCoachOutput' schema.

USER PROFILE:
{{json .}}
`,
});

const fitnessCoachFlow = ai.defineFlow(
    {
        name: 'fitnessCoachFlow',
        inputSchema: FitnessCoachInputSchema,
        outputSchema: FitnessCoachOutputSchema,
    },
    async (input) => {
        const { output } = await fitnessCoachPrompt(input);
        return output!;
    }
);
