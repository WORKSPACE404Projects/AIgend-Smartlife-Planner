
'use server';
/**
 * @fileOverview An AI flow to generate a guide for a specific fitness exercise.
 * 
 * Exports:
 * - getExerciseGuide: A function that provides a detailed guide for a given exercise.
 * - ExerciseGuideInput: The input type for the getExerciseGuide function.
 * - ExerciseGuideOutput: The return type for the getExerciseGuide function.
 */

import {ai} from '@/ai/genkit';
import {
    ExerciseGuideInputSchema,
    ExerciseGuideOutputSchema,
    type ExerciseGuideInput,
    type ExerciseGuideOutput
} from '@/ai/schemas';

export async function getExerciseGuide(input: ExerciseGuideInput): Promise<ExerciseGuideOutput> {
  return await exerciseGuideFlow(input);
}

const exerciseGuidePrompt = ai.definePrompt({
    name: 'exerciseGuidePrompt',
    input: { schema: ExerciseGuideInputSchema },
    output: { schema: ExerciseGuideOutputSchema },
    system: `You are a master fitness trainer. Your task is to provide a clear, concise, and helpful guide for the specified exercise.
The user wants to know about: {{exerciseName}}.
The user's locale is '{{locale}}'. You MUST reply in this language.

The guide must include:
1.  A brief, one-paragraph description of the exercise, its purpose, and the primary muscles worked.
2.  A list of step-by-step instructions on how to perform the movement correctly.
3.  A list of common mistakes to avoid.
`,
});

const exerciseGuideFlow = ai.defineFlow(
    {
        name: 'exerciseGuideFlow',
        inputSchema: ExerciseGuideInputSchema,
        outputSchema: ExerciseGuideOutputSchema,
    },
    async (input) => {
        const { output } = await exerciseGuidePrompt(input);
        return output!;
    }
);
