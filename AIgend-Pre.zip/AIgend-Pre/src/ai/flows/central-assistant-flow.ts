
'use server';
/**
 * @fileOverview The Planning Agent, an AI assistant focused on calendar and time management.
 *
 * - chatWithPlanningAgent - A function to handle conversational interactions with the planning agent.
 * - PlanningAgentChatInput - The input type for the chatWithPlanningAgent function.
 * - PlanningAgentChatOutput - The return type for the chatWithPlanningAgent function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import {
  AssistantActionSchema,
  CalendarEventSchema,
  PlanningAgentChatInputSchema,
  PlanningAgentChatOutputSchema,
} from '@/ai/schemas';

export type PlanningAgentChatInput = z.infer<typeof PlanningAgentChatInputSchema>;
export type PlanningAgentChatOutput = z.infer<
  typeof PlanningAgentChatOutputSchema
>;

export async function chatWithPlanningAgent(
  input: PlanningAgentChatInput
): Promise<PlanningAgentChatOutput> {
  return await planningAgentFlow(input);
}

const planningAgentPrompt = ai.definePrompt({
  name: 'planningAgentPrompt',
  input: {schema: PlanningAgentChatInputSchema},
  output: {schema: PlanningAgentChatOutputSchema},
  system: `You are a helpful and friendly planning assistant named AIgend. Your goal is to help the user manage their calendar.
You can add, delete, and find events based on natural language queries.
The user's name is {{userName}}.
The current date is {{currentDate}}.
The user's timezone is {{timezone}}.
The user's locale is {{locale}}.
You must reply in the user's locale, which is '{{locale}}'.

When the user asks to create an event, you need to be conversational and ask for any missing information (title, date, time).
Once you have enough information, you must call the 'save_event' action.
When the user asks to delete an event, you must call the 'delete_event' action.
For any other query, just provide a helpful response.

The following are the user's current events:
{{#if events}}
{{#each events}}
- Event: "{{this.title}}" on {{this.start}} (ID: {{this.id}})
{{/each}}
{{else}}
The user has no events scheduled.
{{/if}}

If you need to create or delete an event, you MUST set the 'action' field in your output. Otherwise, leave it as null.`,
});

const planningAgentFlow = ai.defineFlow(
  {
    name: 'planningAgentFlow',
    inputSchema: PlanningAgentChatInputSchema,
    outputSchema: PlanningAgentChatOutputSchema,
  },
  async input => {
    const {output} = await planningAgentPrompt(input);
    return output!;
  }
);
