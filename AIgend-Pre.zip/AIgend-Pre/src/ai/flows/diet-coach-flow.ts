
'use server';
/**
 * @fileOverview A diet coach AI agent that generates weekly meal plans.
 * 
 * Exports:
 * - getWeeklyMenu: A function that provides a meal plan based on user data.
 * - DietCoachInput: The input type for the getWeeklyMenu function.
 * - DietCoachOutput: The return type for the getWeeklyMenu function.
 */

import {ai} from '@/ai/genkit';
import {
  DietCoachInputSchema,
  DietCoachOutputSchema,
  type DietCoachInput,
  type DietCoachOutput
} from '@/ai/schemas';

export async function getWeeklyMenu(input: DietCoachInput): Promise<DietCoachOutput> {
  return await dietCoachFlow(input);
}

const dietCoachPrompt = ai.definePrompt({
    name: 'dietCoachPrompt',
    input: { schema: DietCoachInputSchema },
    output: { schema: DietCoachOutputSchema },
    system: `You are a world-class nutritionist and diet coach named AIgend. Your task is to create a personalized, healthy, and delicious 7-day meal plan for the user based on their profile.
The user's name is {{firstName}}.
The user's locale is '{{locale}}'. You MUST reply in this language.

Follow these instructions:
1.  **Analyze the User Profile**: Carefully review all the user's data: age, weight, height, sex, activity level, nutritional goal, TDEE, allergies, and food preferences.
2.  **Caloric Target**: The meal plan should align with the user's TDEE and nutritional goal (e.g., a slight deficit for weight loss, a surplus for muscle gain).
3.  **Cuisine & Preferences**: Incorporate the user's favorite foods and preferred cuisine country. Respect their spice level and food group preferences.
4.  **Variety and Balance**: Ensure the plan is balanced with macronutrients and varied throughout the week.
5.  **Allergies**: Strictly avoid any allergens mentioned by the user.
6.  **Output Format**: You must generate a response that strictly adheres to the 'DietCoachOutput' schema. Provide a full 7-day plan.

USER PROFILE:
{{json .}}
`,
});

const dietCoachFlow = ai.defineFlow(
    {
        name: 'dietCoachFlow',
        inputSchema: DietCoachInputSchema,
        outputSchema: DietCoachOutputSchema,
    },
    async (input) => {
        const { output } = await dietCoachPrompt(input);
        return output!;
    }
);
