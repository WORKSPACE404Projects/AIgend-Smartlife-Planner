/**
 * @fileOverview Centralized Zod schemas for AI flows.
 * This file does not contain server-specific logic and can be imported safely on the client and server.
 */

import { z } from 'zod';

// We need a zod schema for CalendarEvent to pass it to the prompt
export const CalendarEventSchema = z.object({
    id: z.string(),
    title: z.string(),
    start: z.string().datetime(),
    end: z.string().datetime(),
    allDay: z.boolean(),
    description: z.string().optional(),
    category: z.enum(['diet', 'general', 'fitness']).optional().default('general').describe("The category of the event, e.g., 'diet' for meals or 'general' for other appointments."),
});


// Schemas for Diet Coach
export const DietCoachInputSchema = z.object({
  firstName: z.string().optional(),
  age: z.number().optional(),
  weight: z.number().optional(),
  height: z.number().optional(),
  sex: z.enum(['male', 'female']).optional(),
  activityLevel: z.enum(['sedentary', 'light', 'moderate', 'intense', 'very_intense']).optional(),
  nutritionalGoal: z.enum(['weight_maintenance', 'weight_loss', 'muscle_gain']).optional(),
  dietaryPreferences: z.enum(['omnivore', 'vegetarian', 'vegan', 'gluten_free']).optional(),
  allergies: z.string().optional(),
  favoriteFoods: z.string().optional(),
  tdee: z.number().describe('The user\'s Total Daily Energy Expenditure in kcal.'),
  country: z.string().optional(),
  spiceLevel: z.number().min(0).max(5).optional(),
  foodGroupPreferences: z.object({
    vegetables: z.number().min(0).max(5),
    fruits: z.number().min(0).max(5),
    redMeat: z.number().min(0).max(5),
    poultry: z.number().min(0).max(5),
    fish: z.number().min(0).max(5),
    legumes: z.number().min(0).max(5),
  }).optional(),
  locale: z.string().optional().describe("The user's locale (e.g., 'en', 'es') to generate the response in that language."),
});
export type DietCoachInput = z.infer<typeof DietCoachInputSchema>;

const MealSchema = z.object({
  name: z.string().describe("Name of the meal."),
  description: z.string().describe("A short description of the meal including main ingredients."),
});

const DailyMenuSchema = z.object({
  day: z.string().describe("Day of the week (e.g., Monday)."),
  breakfast: MealSchema,
  lunch: MealSchema,
  dinner: MealSchema,
  snacks: z.array(MealSchema).max(2).describe("One or two healthy snacks for the day."),
  totalCalories: z.number().describe("Estimated total calories for the day.")
});

export const DietCoachOutputSchema = z.object({
  weeklyMenu: z.array(DailyMenuSchema).describe("A 7-day menu plan."),
  summary: z.string().describe("A brief summary of the generated plan and why it's suitable for the user.")
});
export type DietCoachOutput = z.infer<typeof DietCoachOutputSchema>;


// Schemas for Financial Coach
const FinancialGoalSchema = z.object({
  id: z.string(),
  name: z.string(),
  targetAmount: z.coerce.number(),
  currentAmount: z.coerce.number(),
});

const FinancialDataSchema = z.object({
  totalMonthlyIncome: z.coerce.number().describe('The user\'s total monthly income.'),
  fixedMonthlyExpenses: z.coerce.number().describe('The user\'s fixed monthly expenses.'),
  variableMonthlyExpenses: z.coerce.number().describe('The user\'s variable monthly expenses.'),
  totalDebt: z.coerce.number().describe('The user\'s total current debt.'),
  liquidSavings: z.coerce.number().describe('The user\'s total liquid savings.'),
  monthlyInvestment: z.coerce.number().describe('The amount the user invests monthly.'),
  goals: z.array(FinancialGoalSchema).describe('A list of the user\'s financial goals.'),
});

export const FinancialCoachInputSchema = z.object({
  financialData: FinancialDataSchema,
  query: z.string().describe('The user\'s specific question or request for advice.'),
  userName: z.string().optional().describe("The user's first name, for personalization."),
});
export type FinancialCoachInput = z.infer<typeof FinancialCoachInputSchema>;

export const FinancialCoachOutputSchema = z.object({
  advice: z.string().describe('The generated financial advice.'),
});
export type FinancialCoachOutput = z.infer<typeof FinancialCoachOutputSchema>;


// Schemas for Assistant Actions
export const AssistantActionSaveEventSchema = z.object({
    type: z.enum(['save_event']),
    payload: z.object({
        id: z.string().optional(),
        title: z.string(),
        start: z.string().datetime(),
        end: z.string().datetime(),
        allDay: z.boolean(),
        description: z.string().optional(),
    }),
});

export const AssistantActionDeleteEventSchema = z.object({
    type: z.enum(['delete_event']),
    payload: z.object({
        eventId: z.string(),
    }),
});

export const AssistantActionSchema = z.union([
    AssistantActionSaveEventSchema,
    AssistantActionDeleteEventSchema,
]).nullable().optional().describe("The specific action the assistant should prepare for the application to execute, if any. This is used instead of calling a tool directly for calendar operations.");


// Schema for full PersonalData object
export const PersonalDataSchema = z.object({
    firstName: z.string().optional().describe("The user's first name, for personalization."),
    totalMonthlyIncome: z.coerce.number(),
    fixedMonthlyExpenses: z.coerce.number(),
    variableMonthlyExpenses: z.coerce.number(),
    totalDebt: z.coerce.number(),
    liquidSavings: z.coerce.number(),
    monthlyInvestment: z.coerce.number(),
    goals: z.array(FinancialGoalSchema),
    age: z.number().optional(),
    weight: z.number().optional(),
    height: z.number().optional(),
    sex: z.enum(['male', 'female']).optional(),
    activityLevel: z.enum(['sedentary', 'light', 'moderate', 'intense', 'very_intense']).optional(),
    allergies: z.string().optional(),
    nutritionalGoal: z.enum(['weight_maintenance', 'weight_loss', 'muscle_gain']).optional(),
    fitnessGoal: z.enum(['strength_gain', 'endurance', 'flexibility', 'general_fitness']).optional(),
    availableEquipment: z.string().optional().describe("A list of available workout equipment, e.g., 'dumbbells, yoga mat'. Defaults to 'bodyweight only' if not provided."),
    trainingFacilities: z.string().optional().describe("A comma-separated string of training facilities available to the user (e.g., 'commercial_gym,calisthenics_park')."),
    injuries: z.string().optional().describe("A description of any injuries or physical limitations the user has, which should be considered when creating the plan."),
    dietaryPreferences: z.enum(['omnivore', 'vegetarian', 'vegan', 'gluten_free']).optional(),
    favoriteFoods: z.string().optional(),
    country: z.string().optional(),
    spiceLevel: z.number().min(0).max(5).optional(),
    foodGroupPreferences: z.object({
        vegetables: z.number().min(0).max(5),
        fruits: z.number().min(0).max(5),
        redMeat: z.number().min(0).max(5),
        poultry: z.number().min(0).max(5),
        fish: z.number().min(0).max(5),
        legumes: z.number().min(0).max(5),
    }).optional(),
    timezone: z.string().optional().describe("The user's IANA timezone name (e.g., 'Europe/Madrid') for accurate local time interpretation."),
}).describe("The user's complete personal, financial, and health data.");


// Schemas for Purchase Analyzer
export const PurchaseAnalyzerInputSchema = z.object({
  personalData: PersonalDataSchema,
  purchaseDescription: z.string().describe("A brief description of the item or service to be purchased."),
  purchaseAmount: z.coerce.number().positive().describe("The cost of the purchase."),
  purchaseCategory: z.string().describe("The category of the purchase (e.g., 'Technology', 'Leisure', 'Health')."),
  purchaseJustification: z.string().describe("The user's reasoning or justification for making this purchase."),
  locale: z.string().optional().describe("The user's locale (e.g., 'en', 'es') to generate the response in that language."),
});
export type PurchaseAnalyzerInput = z.infer<typeof PurchaseAnalyzerInputSchema>;


export const PurchaseAnalyzerOutputSchema = z.object({
  recommendation: z.enum(['recommended', 'caution', 'not_recommended']).describe("The AI's final verdict on the purchase."),
  analysis: z.string().describe("A detailed, empathetic analysis explaining the reasoning behind the recommendation. This should be formatted in Markdown."),
  financialImpact: z.string().describe("A brief summary of the direct financial impact (e.g., 'Reduces savings by 5%')."),
});
export type PurchaseAnalyzerOutput = z.infer<typeof PurchaseAnalyzerOutputSchema>;


// Schemas for Daily Briefing
export const DailyBriefingInputSchema = z.object({
  personalData: PersonalDataSchema.describe("The user's complete personal, financial, and health data."),
  events: z.array(CalendarEventSchema).describe("A list of the user's calendar events scheduled for today."),
  currentDate: z.string().datetime().describe("The current date and time in ISO 8601 format."),
  locale: z.string().optional().describe("The user's locale (e.g., 'en', 'es') to generate the response in that language."),
});
export type DailyBriefingInput = z.infer<typeof DailyBriefingInputSchema>;

export const DailyBriefingOutputSchema = z.object({
  greeting: z.string().describe("A friendly, context-aware greeting for the user (e.g., 'Good morning!', 'Good afternoon!')."),
  weatherSummary: z.string().describe("A friendly summary of the current weather and air quality. e.g., 'It's currently 22°C and partly cloudy.'"),
  agendaSummary: z.string().describe("A concise summary of the day's agenda. Mention the number of events and highlight the most important or first one. Formatted in Markdown."),
  dietSummary: z.string().describe("A brief, relevant tip or status related to the user's diet plan for the day. Could mention a specific meal from their plan. Formatted in Markdown."),
  financeSummary: z.string().describe("A short, encouraging update on their financial goals or savings. Formatted in Markdown."),
  proactiveSuggestion: z.string().describe("A smart, actionable suggestion based on all available data. For example, suggest scheduling a workout if the calendar is free and the goal is health-related. Formatted in Markdown."),
});
export type DailyBriefingOutput = z.infer<typeof DailyBriefingOutputSchema>;

// Schemas for Fitness Coach
export const ExerciseSchema = z.object({
  name: z.string().describe("The name of the exercise."),
  sets: z.union([z.string(), z.number()]).describe("Number of sets (e.g., 3, '3-4', or 'As many as possible')."),
  reps: z.union([z.string(), z.number()]).describe("Number of repetitions or duration (e.g., 12, '8-10', '30 sec')."),
  weight: z.union([z.string(), z.number()]).optional().describe("Suggested starting weight or intensity (e.g., 'Bodyweight', '10 kg', '50% of max')."),
  description: z.string().optional().describe("A brief description or instructions for the exercise."),
});

export const DailyWorkoutSchema = z.object({
  day: z.string().describe("Day of the week (e.g., Monday)."),
  focus: z.string().describe("The main focus of the workout (e.g., 'Upper Body', 'Legs & Glutes', 'Cardio & Core', 'Rest')."),
  exercises: z.array(ExerciseSchema).describe("A list of exercises for the day. Should be empty if it's a rest day."),
});

export const FitnessCoachInputSchema = z.object({
  firstName: z.string().optional(),
  age: z.number().optional(),
  weight: z.number().optional(),
  height: z.number().optional(),
  sex: z.enum(['male', 'female']).optional(),
  activityLevel: z.enum(['sedentary', 'light', 'moderate', 'intense', 'very_intense']).optional(),
  fitnessGoal: z.enum(['strength_gain', 'endurance', 'flexibility', 'general_fitness']).optional().default('general_fitness'),
  nutritionalGoal: z.enum(['weight_maintenance', 'weight_loss', 'muscle_gain']).optional(),
  availableEquipment: z.string().optional().describe("A list of available workout equipment, e.g., 'dumbbells, yoga mat'. Defaults to 'bodyweight only' if not provided."),
  trainingFacilities: z.string().optional().describe("A comma-separated string of training facilities available to the user (e.g., 'commercial_gym,calisthenics_park')."),
  injuries: z.string().optional().describe("A description of any injuries or physical limitations the user has, which should be considered when creating the plan."),
  locale: z.string().optional().describe("The user's locale (e.g., 'en', 'es') to generate the response in that language."),
});
export type FitnessCoachInput = z.infer<typeof FitnessCoachInputSchema>;

export const FitnessCoachOutputSchema = z.object({
  weeklyPlan: z.array(DailyWorkoutSchema).length(7).describe("A 7-day workout plan."),
  summary: z.string().describe("A brief, encouraging summary of the generated plan and how it aligns with the user's goals.")
});
export type FitnessCoachOutput = z.infer<typeof FitnessCoachOutputSchema>;


// Schemas for Exercise Guide
export const ExerciseGuideInputSchema = z.object({
  exerciseName: z.string().describe("The name of the exercise to get a guide for."),
  locale: z.string().optional().describe("The user's locale (e.g., 'en', 'es') to generate the response in that language."),
});
export type ExerciseGuideInput = z.infer<typeof ExerciseGuideInputSchema>;

export const ExerciseGuideOutputSchema = z.object({
  name: z.string().describe("The name of the exercise."),
  description: z.string().describe("A brief, one-paragraph description of the exercise, its purpose, and the main muscles worked."),
  instructions: z.array(z.string()).describe("A list of step-by-step instructions on how to perform the exercise correctly."),
  commonMistakes: z.array(z.string()).describe("A list of common mistakes to avoid while performing the exercise."),
});
export type ExerciseGuideOutput = z.infer<typeof ExerciseGuideOutputSchema>;
