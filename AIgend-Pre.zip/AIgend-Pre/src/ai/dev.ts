// Flows will be imported for their side effects in this file.
import './flows/financial-coach-flow';
import './flows/diet-coach-flow';
import './flows/central-assistant-flow';
import './flows/purchase-analyzer-flow';
import './flows/daily-briefing-flow';
import './flows/text-to-speech-flow';
import './flows/fitness-coach-flow';
import './flows/exercise-guide-flow';
import './tools/environmental-data-tool';
