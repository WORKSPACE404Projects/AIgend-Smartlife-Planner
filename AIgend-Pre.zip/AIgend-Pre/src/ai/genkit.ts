
import {genkit} from 'genkit';
import {googleAI} from '@genkit-ai/googleai';
import 'dotenv/config';

export const ai = genkit({
  plugins: [
    googleAI({
      // This tells Genkit to use your Google Cloud project,
      // which enables billing and unlocks higher rate limits.
      project: process.env.GOOGLE_CLOUD_PROJECT,
      // Specifying a location can help ensure requests are routed correctly.
      location: 'us-central1',
    }),
  ],
  // No default model needed, as flows specify their own.
});
