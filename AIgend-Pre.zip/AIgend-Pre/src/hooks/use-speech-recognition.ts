
'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useToast } from './use-toast';
import { useTranslations } from 'next-intl';

interface SpeechRecognitionHook {
  text: string;
  isListening: boolean;
  startListening: () => void;
  stopListening: () => void;
  hasRecognitionSupport: boolean;
}

// Maps the app's generic locale to a more specific BCP 47 language tag
// that the Web Speech API prefers for better accuracy.
const getBcp47Locale = (locale: string): string => {
  switch (locale) {
    case 'es': return 'es-ES';
    case 'fr': return 'fr-FR';
    case 'pt': return 'pt-BR';
    case 'zh': return 'zh-CN';
    case 'en':
    default:
      return 'en-US';
  }
};


const useSpeechRecognition = (locale: string): SpeechRecognitionHook => {
  const t = useTranslations('SpeechRecognition');
  const { toast } = useToast();
  const [text, setText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  const hasRecognitionSupport =
    typeof window !== 'undefined' &&
    ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window);

  useEffect(() => {
    if (!hasRecognitionSupport) {
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    // Set the specific language for recognition to improve accuracy
    recognition.lang = getBcp47Locale(locale);

    recognition.onresult = (event) => {
      let interimTranscript = '';
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript;
        } else {
          interimTranscript += event.results[i][0].transcript;
        }
      }
      setText(finalTranscript + interimTranscript);
    };

    recognition.onerror = (event) => {
      let errorMessage = t('genericError');
      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        errorMessage = t('permissionDenied');
      } else if (event.error === 'no-speech') {
        errorMessage = t('noSpeech');
      }
      toast({
        title: t('errorTitle'),
        description: errorMessage,
        variant: 'destructive',
      });
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => {
        if (recognitionRef.current) {
            recognitionRef.current.stop();
        }
    };
  }, [locale, hasRecognitionSupport, t, toast]);

  const startListening = useCallback(() => {
    if (recognitionRef.current && !isListening) {
      setText('');
      recognitionRef.current.start();
      setIsListening(true);
    }
  }, [isListening]);

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    }
  }, [isListening]);

  return { text, isListening, startListening, stopListening, hasRecognitionSupport };
};

export default useSpeechRecognition;
