import type { CapacitorConfig } from '@capacitor/core';

const config: CapacitorConfig = {
  appId: 'com.aigend.smartlifeplanner',
  appName: 'AIgend: Smart Life Planner',
  webDir: 'out',
  server: {
    androidScheme: 'https',
  },
};

export default config;
