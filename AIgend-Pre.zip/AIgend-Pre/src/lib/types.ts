export interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  allDay: boolean;
  description?: string;
  reminder?: number; // minutes before
  category?: 'diet' | 'general' | 'fitness';
  color?: string;
}

export interface AccountingTransaction {
  id: string;
  type: 'income' | 'expense';
  description: string;
  amount: number;
  date: Date;
}

export interface FinancialGoal {
  id:string;
  name: string;
  targetAmount: number;
  currentAmount: number;
}

export interface PersonalData {
  firstName?: string;
  // Financial fields
  totalMonthlyIncome: number;
  fixedMonthlyExpenses: number;
  variableMonthlyExpenses: number;
  totalDebt: number;
  liquidSavings: number;
  monthlyInvestment: number;
  goals: FinancialGoal[];
  // Diet fields
  age?: number;
  weight?: number;
  height?: number;
  sex?: 'male' | 'female';
  activityLevel?: 'sedentary' | 'light' | 'moderate' | 'intense' | 'very_intense';
  allergies?: string;
  nutritionalGoal?: 'weight_maintenance' | 'weight_loss' | 'muscle_gain';
  fitnessGoal?: 'strength_gain' | 'endurance' | 'flexibility' | 'general_fitness';
  availableEquipment?: string;
  trainingFacilities?: string; // Comma-separated values
  injuries?: string;
  dietaryPreferences?: 'omnivore' | 'vegetarian' | 'vegan' | 'gluten_free';
  favoriteFoods?: string;
  country?: string;
  spiceLevel?: number; // 0-5
  foodGroupPreferences?: {
    vegetables: number;
    fruits: number;
    redMeat: number;
    poultry: number;
    fish: number;
    legumes: number;
  };
  timezone?: string;
}

export interface LoggedSet {
  reps: number;
  weight: number;
}

export interface LoggedExercise {
  name: string;
  sets: LoggedSet[];
}

export interface LoggedWorkout {
  id: string; // unique id for the log entry
  calendarEventId: string; // link to the planned event
  date: Date; // date the workout was actually performed
  notes?: string;
  exercises: LoggedExercise[];
}
