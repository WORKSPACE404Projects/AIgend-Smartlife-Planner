
const SIZE = 9;
const BOX_SIZE = 3;

function createEmptyGrid(): number[][] {
  return Array(SIZE).fill(0).map(() => Array(SIZE).fill(0));
}

function isSafe(grid: number[][], row: number, col: number, num: number): boolean {
  for (let x = 0; x < SIZE; x++) {
    if (grid[row][x] === num || grid[x][col] === num) {
      return false;
    }
  }

  const startRow = row - (row % BOX_SIZE);
  const startCol = col - (col % BOX_SIZE);
  for (let i = 0; i < BOX_SIZE; i++) {
    for (let j = 0; j < BOX_SIZE; j++) {
      if (grid[i + startRow][j + startCol] === num) {
        return false;
      }
    }
  }
  return true;
}

function shuffle(array: any[]) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

export function solveSudoku(grid: number[][]): boolean {
  for (let row = 0; row < SIZE; row++) {
    for (let col = 0; col < SIZE; col++) {
      if (grid[row][col] === 0) {
        for (let num = 1; num <= SIZE; num++) {
          if (isSafe(grid, row, col, num)) {
            grid[row][col] = num;
            if (solveSudoku(grid)) {
              return true;
            }
            grid[row][col] = 0; 
          }
        }
        return false;
      }
    }
  }
  return true;
}


function fillGrid(grid: number[][]): boolean {
    for (let i = 0; i < SIZE * SIZE; i++) {
        const row = Math.floor(i / SIZE);
        const col = i % SIZE;
        if (grid[row][col] === 0) {
            const numbers = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
            for (const num of numbers) {
                if (isSafe(grid, row, col, num)) {
                    grid[row][col] = num;
                    if (fillGrid(grid)) {
                        return true;
                    }
                    grid[row][col] = 0;
                }
            }
            return false;
        }
    }
    return true;
}


export function generateSudoku(difficulty: 'easy' | 'medium' | 'hard' = 'medium'): number[][] {
    const grid = createEmptyGrid();
    fillGrid(grid);

    let attempts;
    switch (difficulty) {
        case 'easy':
            attempts = 40;
            break;
        case 'hard':
            attempts = 55;
            break;
        case 'medium':
        default:
            attempts = 50;
            break;
    }

    const puzzle = grid.map(row => [...row]);
    let removed = 0;
    while (removed < attempts) {
        const row = Math.floor(Math.random() * SIZE);
        const col = Math.floor(Math.random() * SIZE);
        if (puzzle[row][col] !== 0) {
            puzzle[row][col] = 0;
            removed++;
        }
    }

    return puzzle;
}
