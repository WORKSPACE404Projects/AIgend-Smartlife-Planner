import { es, enUS, pt, fr, zhCN } from 'date-fns/locale';
import type { Locale } from 'date-fns';

export function getDateFnsLocale(locale: string): Locale {
    switch (locale) {
        case 'es': return es;
        case 'pt': return pt;
        case 'fr': return fr;
        case 'zh': return zhCN;
        default: return enUS;
    }
}
