// ==================== TIPOS ====================
export type Player = 1 | 2;
export type PieceType = 'normal' | 'king';
export type Piece = { player: Player; type: PieceType } | null;
export type Board = Piece[][];
export type Position = { row: number; col: number };
export type Move = { from: Position; to: Position; captures?: Position[] };

export interface GameState {
  board: Board;
  currentPlayer: Player;
  selectedPiece: Position | null;
  validMoves: Position[];
  lastMove: Move | null;
  winner: Player | null;
}

// ==================== LÓGICA DEL JUEGO ====================
export class CheckersGame {
  private state: GameState;
  private readonly BOARD_SIZE = 8;

  constructor(initialState?: GameState) {
    this.state = initialState || this.createInitialState();
  }

  private createInitialState(): GameState {
    const board: Board = Array(this.BOARD_SIZE).fill(null).map(() => Array(this.BOARD_SIZE).fill(null));
    
    for (let row = 0; row < this.BOARD_SIZE; row++) {
      for (let col = 0; col < this.BOARD_SIZE; col++) {
        if ((row + col) % 2 === 1) {
          if (row < 3) board[row][col] = { player: 2, type: 'normal' };
          else if (row > 4) board[row][col] = { player: 1, type: 'normal' };
        }
      }
    }

    return {
      board,
      currentPlayer: 1,
      selectedPiece: null,
      validMoves: [],
      lastMove: null,
      winner: null,
    };
  }

  public getState(): GameState {
    return JSON.parse(JSON.stringify(this.state)); 
  }

  public selectPiece(position: Position): void {
    if (this.state.winner) return;
    const piece = this.state.board[position.row][position.col];
    if (!piece || piece.player !== this.state.currentPlayer) {
        this.state.selectedPiece = null;
        this.state.validMoves = [];
        return;
    };

    const validMoves = this.calculateValidMovesForPiece(position);
    this.state.selectedPiece = position;
    this.state.validMoves = validMoves;
  }

  public movePiece(to: Position): void {
    const from = this.state.selectedPiece;
    if (!from || this.state.winner) return;
    
    const isValid = this.state.validMoves.some(m => m.row === to.row && m.col === to.col);
    if (!isValid) {
      this.state.selectedPiece = null;
      this.state.validMoves = [];
      return;
    }

    const newBoard = this.copyBoard(this.state.board);
    const piece = newBoard[from.row][from.col]!;
    
    const isCapture = Math.abs(to.row - from.row) === 2;
    if (isCapture) {
        const capturedRow = from.row + (to.row - from.row) / 2;
        const capturedCol = from.col + (to.col - from.col) / 2;
        newBoard[capturedRow][capturedCol] = null;
    }

    newBoard[from.row][from.col] = null;
    newBoard[to.row][to.col] = piece;

    this.promoteIfNeeded(newBoard, to);
    
    const furtherCaptures = this.calculateValidMovesForPiece(to, true);
    
    if(isCapture && furtherCaptures.length > 0) {
        this.state.board = newBoard;
        this.state.selectedPiece = to;
        this.state.validMoves = furtherCaptures;
        this.state.winner = this.checkWinner(newBoard);
    } else {
        this.state.board = newBoard;
        this.state.currentPlayer = this.state.currentPlayer === 1 ? 2 : 1;
        this.state.selectedPiece = null;
        this.state.validMoves = [];
        this.state.winner = this.checkWinner(newBoard);
    }
  }

  private promoteIfNeeded(board: Board, pos: Position): void {
    const piece = board[pos.row][pos.col];
    if (!piece) return;

    const shouldPromote = (piece.player === 1 && pos.row === 0) || 
                         (piece.player === 2 && pos.row === this.BOARD_SIZE - 1);
    if (shouldPromote) piece.type = 'king';
  }

  private calculateAllPlayerMoves(player: Player) {
      const allMoves = [];
      for (let r = 0; r < this.BOARD_SIZE; r++) {
          for (let c = 0; c < this.BOARD_SIZE; c++) {
              if (this.state.board[r][c]?.player === player) {
                  allMoves.push(...this.calculateValidMovesForPiece({row: r, col: c}));
              }
          }
      }
      return allMoves;
  }
  
  private calculateValidMovesForPiece(pos: Position, capturesOnly = false): Position[] {
    const piece = this.state.board[pos.row][pos.col];
    if (!piece) return [];

    const moves: Position[] = [];
    const captureMoves: Position[] = [];
    const directions = piece.type === 'king' ? [-1, 1] : piece.player === 1 ? [-1] : [1];

    for (const rowDir of directions) {
      for (const colDir of [-1, 1]) {
        // Movimiento simple
        const newRow = pos.row + rowDir;
        const newCol = pos.col + colDir;
        if (this.isValid(newRow, newCol) && !this.state.board[newRow][newCol]) {
          moves.push({ row: newRow, col: newCol });
        }
        
        // Captura
        const captureRow = pos.row + rowDir * 2;
        const captureCol = pos.col + colDir * 2;
        if (this.isValid(captureRow, captureCol) &&
            !this.state.board[captureRow][captureCol] &&
            this.isEnemy(pos.row + rowDir, pos.col + colDir)) {
          captureMoves.push({ row: captureRow, col: captureCol });
        }
      }
    }
    
    // Check for mandatory captures for any piece
    const mandatoryCaptures = [];
     for (let r = 0; r < this.BOARD_SIZE; r++) {
        for (let c = 0; c < this.BOARD_SIZE; c++) {
            if (this.state.board[r][c]?.player === this.state.currentPlayer) {
                mandatoryCaptures.push(...this.calculateValidMovesForPiece({row: r, col: c}, true));
            }
        }
    }

    if (mandatoryCaptures.length > 0) {
        if(captureMoves.length > 0) return captureMoves;
        return [];
    }

    return capturesOnly ? captureMoves : moves;
  }


  private checkWinner(board: Board): Player | null {
    let p1Pieces = 0, p2Pieces = 0;
    let p1Moves = 0, p2Moves = 0;

    for (let row = 0; row < this.BOARD_SIZE; row++) {
      for (let col = 0; col < this.BOARD_SIZE; col++) {
        const piece = board[row][col];
        if (!piece) continue;

        if (piece.player === 1) {
            p1Pieces++;
            p1Moves += this.calculateValidMovesForPiece({row, col}).length;
        } else {
            p2Pieces++;
            p2Moves += this.calculateValidMovesForPiece({row, col}).length;
        }
      }
    }
    
    if (p1Pieces === 0 || p1Moves === 0) return 2;
    if (p2Pieces === 0 || p2Moves === 0) return 1;
    return null;
  }

  private isValid(row: number, col: number): boolean {
    return row >= 0 && row < this.BOARD_SIZE && col >= 0 && col < this.BOARD_SIZE;
  }

  private isEnemy(row: number, col: number): boolean {
    const piece = this.state.board[row]?.[col];
    return !!piece && piece.player !== this.state.currentPlayer;
  }

  private copyBoard(board: Board): Board {
    return board.map(row => row.map(piece => piece ? { ...piece } : null));
  }

  public reset(): void {
    this.state = this.createInitialState();
  }
}
