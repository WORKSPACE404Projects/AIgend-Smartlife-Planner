"use client";

import * as React from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { Bot, Loader2, Sparkles, CalendarPlus, Dumbbell, Info } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import type { PersonalData } from '@/lib/types';
import { getWeeklyWorkout, type FitnessCoachInput, type FitnessCoachOutput } from '@/ai/flows/fitness-coach-flow';
import { useToast } from '@/hooks/use-toast';
import { useCalendar } from '@/contexts/CalendarContext';
import { ExerciseGuideDialog } from './ExerciseGuideDialog';

interface WorkoutPlannerProps {
  personalData: PersonalData;
}

export function WorkoutPlanner({ personalData }: WorkoutPlannerProps) {
  const t = useTranslations('Fitness');
  const locale = useLocale();
  const { toast } = useToast();
  const { saveWorkoutPlanAsEvents } = useCalendar();

  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [workoutPlan, setWorkoutPlan] = React.useState<FitnessCoachOutput | null>(null);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = React.useState(false);
  const [isGuideOpen, setIsGuideOpen] = React.useState(false);
  const [selectedExercise, setSelectedExercise] = React.useState<string | null>(null);

  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  React.useEffect(() => {
    if(isLoading || workoutPlan) {
        scrollToBottom();
    }
  }, [isLoading, workoutPlan]);


  const handleGenerateWorkout = async () => {
    setIsLoading(true);
    setError(null);
    setWorkoutPlan(null);

    const flowInput: FitnessCoachInput = {
        ...personalData,
        locale: locale,
    };
    
    try {
      const result = await getWeeklyWorkout(flowInput);
      setWorkoutPlan(result);
    } catch (err) {
      console.error("Error generating workout plan:", err);
      setError(t('errorMessage'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToCalendar = async () => {
    if (!workoutPlan) return;
    try {
        await saveWorkoutPlanAsEvents(workoutPlan.weeklyPlan);
        toast({
            title: t('planAddedSuccess'),
            description: t('planAddedSuccessDescription'),
        });
    } catch (err) {
        console.error("Error saving workout plan to calendar:", err);
        toast({
            title: t('planAddedError'),
            variant: 'destructive',
        });
    } finally {
        setIsConfirmDialogOpen(false);
    }
  };

  const handleShowGuide = (exerciseName: string) => {
    setSelectedExercise(exerciseName);
    setIsGuideOpen(true);
  };


  return (
    <>
    <Card className="max-w-2xl mx-auto flex flex-col h-full min-h-[500px]">
      <CardHeader>
        <CardTitle>{t('plannerTab')}</CardTitle>
        <CardDescription>{t('description')}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col overflow-hidden">
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            <div className="flex items-start gap-3 justify-start">
              <Avatar className="h-8 w-8 shadow-cyan-glow">
                <AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback>
              </Avatar>
              <div className="rounded-lg p-3 text-sm border border-border/20 bg-card/50 backdrop-blur-sm">
                <p>{t('initialMessage')}</p>
              </div>
            </div>

            {isLoading && (
              <div className="flex items-start gap-3 justify-start">
                <Avatar className="h-8 w-8 shadow-cyan-glow">
                  <AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback>
                </Avatar>
                <div className="rounded-lg p-3 flex items-center space-x-2 border border-border/20 bg-card/50 backdrop-blur-sm">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm text-muted-foreground">{t('loading')}</span>
                </div>
              </div>
            )}

            {error && (
                 <Alert variant="destructive">
                    <AlertTitle>{t('errorTitle')}</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}

            {workoutPlan && (
                 <div className="flex items-start gap-3 justify-start">
                    <Avatar className="h-8 w-8 shadow-cyan-glow">
                        <AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback>
                    </Avatar>
                     <div className="rounded-lg p-4 text-sm w-full border border-border/20 bg-card/50 backdrop-blur-sm">
                        <p className="font-semibold mb-2">{t('planTitle')}</p>
                        <p className="italic mb-4">{workoutPlan.summary}</p>

                        <Accordion type="single" collapsible className="w-full">
                            {workoutPlan.weeklyPlan.map((dailyWorkout, index) => (
                                <AccordionItem value={`item-${index}`} key={index}>
                                    <AccordionTrigger>{dailyWorkout.day} - {dailyWorkout.focus}</AccordionTrigger>
                                    <AccordionContent>
                                        {dailyWorkout.exercises.length > 0 ? (
                                            <ul className="space-y-3">
                                                {dailyWorkout.exercises.map((ex, exIndex) => (
                                                <li key={exIndex} className="flex items-start gap-3">
                                                    <Dumbbell className="h-4 w-4 mt-1 shrink-0 text-primary" />
                                                    <div className="flex-1">
                                                        <p className="font-semibold">{ex.name}</p>
                                                        <p className="text-xs text-muted-foreground">
                                                            {ex.sets} sets x {ex.reps} reps
                                                        </p>
                                                        {ex.description && <p className="text-xs italic">{ex.description}</p>}
                                                    </div>
                                                     <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => handleShowGuide(ex.name)}>
                                                        <Info className="h-4 w-4" />
                                                     </Button>
                                                </li>
                                                ))}
                                            </ul>
                                        ) : (
                                            <p className="text-sm text-muted-foreground italic">{t('restDay')}</p>
                                        )}
                                    </AccordionContent>
                                </AccordionItem>
                            ))}
                        </Accordion>
                     </div>
                </div>
            )}
             <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row gap-2 pt-6">
        <Button 
            onClick={handleGenerateWorkout} 
            disabled={isLoading} 
            className="w-full shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold"
        >
          <Sparkles className="mr-2 h-4 w-4 drop-shadow-cyan-glow" />
          <span className="drop-shadow-cyan-glow">{workoutPlan ? t('regenerateButton') : t('generateButton')}</span>
        </Button>
        {workoutPlan && (
            <Button onClick={() => setIsConfirmDialogOpen(true)} variant="secondary" className="w-full">
                <CalendarPlus className="mr-2 h-4 w-4" />
                {t('addToCalendarButton')}
            </Button>
        )}
      </CardFooter>
    </Card>
    <AlertDialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <AlertDialogContent>
            <AlertDialogHeader>
                <AlertDialogTitle>{t('addToCalendarTitle')}</AlertDialogTitle>
                <AlertDialogDescription>
                    {t('addToCalendarDescription')}
                </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setIsConfirmDialogOpen(false)}>{t('cancelButton')}</AlertDialogCancel>
                <AlertDialogAction onClick={handleAddToCalendar}>{t('confirmButton')}</AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
    </AlertDialog>
     <ExerciseGuideDialog
        isOpen={isGuideOpen}
        onOpenChange={setIsGuideOpen}
        exerciseName={selectedExercise}
      />
    </>
  );
}
