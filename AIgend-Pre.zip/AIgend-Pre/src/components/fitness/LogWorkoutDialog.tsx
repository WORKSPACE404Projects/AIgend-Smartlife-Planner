"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useFieldArray, useForm } from "react-hook-form";
import { z } from "zod";
import { useTranslations } from "next-intl";
import { Plus, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogClose } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import type { CalendarEvent, LoggedExercise } from "@/lib/types";
import { useExercise } from "@/contexts/ExerciseContext";
import { useToast } from "@/hooks/use-toast";
import { Textarea } from "../ui/textarea";

const createLogWorkoutFormSchema = (t: (key: any) => string) => z.object({
    notes: z.string().optional(),
    exercises: z.array(z.object({
        name: z.string(),
        sets: z.array(z.object({
            reps: z.coerce.number().min(0),
            weight: z.coerce.number().min(0),
        })).min(1),
    })),
});

type LogWorkoutFormValues = z.infer<ReturnType<typeof createLogWorkoutFormSchema>>;

function useLogWorkoutFormSchema() {
    const t = useTranslations("Fitness");
    return React.useMemo(() => createLogWorkoutFormSchema(t), [t]);
}

interface LogWorkoutDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  event: CalendarEvent | null;
}

const parseExercisesFromDescription = (description: string = ""): LoggedExercise[] => {
    return description.split('\n').map(line => {
        const name = line.split(':')[0].trim();
        const setsMatch = line.match(/(\d+)\s*sets/);
        const numSets = setsMatch ? parseInt(setsMatch[1], 10) : 1;
        
        return {
            name,
            sets: Array.from({ length: numSets }, () => ({ reps: 0, weight: 0 })),
        };
    }).filter(ex => ex.name);
};

export function LogWorkoutDialog({ isOpen, onOpenChange, event }: LogWorkoutDialogProps) {
  const t = useTranslations("Fitness");
  const logWorkoutFormSchema = useLogWorkoutFormSchema();
  const { logWorkout } = useExercise();
  const { toast } = useToast();

  const form = useForm<LogWorkoutFormValues>({
    resolver: zodResolver(logWorkoutFormSchema),
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "exercises",
  });
  
  const { reset, control } = form;

  React.useEffect(() => {
    if (event) {
        const plannedExercises = parseExercisesFromDescription(event.description);
        reset({ exercises: plannedExercises, notes: '' });
    }
  }, [event, reset]);

  const onSubmit = async (data: LogWorkoutFormValues) => {
    if (!event) return;
    
    await logWorkout({
        calendarEventId: event.id,
        date: new Date(),
        notes: data.notes,
        exercises: data.exercises,
    });
    
    toast({
        title: "Workout Logged!",
        description: "Your progress has been saved.",
    });
    onOpenChange(false);
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{t('logWorkoutTitle')}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <ScrollArea className="max-h-[60vh] p-1">
                <div className="space-y-6 pr-4">
                    {fields.map((field, exerciseIndex) => (
                        <div key={field.id} className="p-4 border rounded-lg">
                            <h3 className="font-semibold mb-2">{field.name}</h3>
                            <div className="space-y-2">
                                {field.sets.map((set, setIndex) => (
                                     <div key={`${field.id}-set-${setIndex}`} className="flex items-center gap-2">
                                        <span className="text-sm font-medium text-muted-foreground w-12">{t('sets')} {setIndex + 1}</span>
                                         <FormField
                                            control={control}
                                            name={`exercises.${exerciseIndex}.sets.${setIndex}.reps`}
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormControl><Input type="number" placeholder={t('reps')} {...field} /></FormControl>
                                                </FormItem>
                                            )}
                                        />
                                        <FormField
                                            control={control}
                                            name={`exercises.${exerciseIndex}.sets.${setIndex}.weight`}
                                            render={({ field }) => (
                                                <FormItem>
                                                    <FormControl><Input type="number" placeholder={t('weight')} {...field} /></FormControl>
                                                </FormItem>
                                            )}
                                        />
                                     </div>
                                ))}
                            </div>
                        </div>
                    ))}
                     <FormField
                        control={control}
                        name="notes"
                        render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('notes')}</FormLabel>
                                <FormControl><Textarea placeholder={t('notesPlaceholder')} {...field} /></FormControl>
                            </FormItem>
                        )}
                    />
                </div>
            </ScrollArea>
            <DialogFooter>
              <DialogClose asChild>
                <Button type="button" variant="outline">{t('cancelButton', {ns: 'EventDialog'})}</Button>
              </DialogClose>
              <Button type="submit" className="shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold">
                <span className="drop-shadow-cyan-glow">{t('saveLog')}</span>
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
