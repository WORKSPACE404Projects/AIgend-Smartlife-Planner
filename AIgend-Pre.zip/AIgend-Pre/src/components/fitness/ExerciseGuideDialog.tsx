"use client";

import * as React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useExercise } from '@/contexts/ExerciseContext';
import type { ExerciseGuideOutput } from '@/ai/schemas';
import { AlertCircle, FileText, ListChecks, Loader2 } from 'lucide-react';
import { useLocale, useTranslations } from 'next-intl';
import { Alert, AlertDescription, AlertTitle } from '../ui/alert';

interface ExerciseGuideDialogProps {
    isOpen: boolean;
    onOpenChange: (isOpen: boolean) => void;
    exerciseName: string | null;
}

export function ExerciseGuideDialog({ isOpen, onOpenChange, exerciseName }: ExerciseGuideDialogProps) {
    const t = useTranslations('Fitness');
    const locale = useLocale();
    const { getGuide, loadingGuides } = useExercise();
    const [guide, setGuide] = React.useState<ExerciseGuideOutput | null>(null);
    const [error, setError] = React.useState<string | null>(null);

    const isLoading = exerciseName ? loadingGuides[exerciseName] : false;
    
    React.useEffect(() => {
        if (isOpen && exerciseName) {
            setGuide(null);
            setError(null);
            getGuide(exerciseName, locale)
                .then(setGuide)
                .catch(() => setError(t('guideError')));
        }
    }, [isOpen, exerciseName, getGuide, locale, t]);

    const handleOpenChange = (open: boolean) => {
        if (!open) {
            setGuide(null);
            setError(null);
        }
        onOpenChange(open);
    }
    
    return (
        <Dialog open={isOpen} onOpenChange={handleOpenChange}>
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle>{t('guideTitle')}: {exerciseName}</DialogTitle>
                </DialogHeader>
                <div className="py-4 space-y-6 max-h-[70vh] overflow-y-auto pr-4">
                    {isLoading && (
                        <div className="flex items-center justify-center h-48">
                            <Loader2 className="h-8 w-8 animate-spin text-primary" />
                        </div>
                    )}
                    {error && (
                         <Alert variant="destructive">
                            <AlertCircle className="h-4 w-4" />
                            <AlertTitle>{t('errorTitle')}</AlertTitle>
                            <AlertDescription>{error}</AlertDescription>
                        </Alert>
                    )}
                    {guide && (
                        <div className="space-y-4">
                             <div className="flex items-start gap-4">
                                <FileText className="h-5 w-5 mt-1 text-primary shrink-0" />
                                <p className="text-sm text-muted-foreground">{guide.description}</p>
                            </div>
                             <div>
                                <h4 className="font-semibold text-lg mb-2 flex items-center gap-2"><ListChecks className="h-5 w-5 text-primary"/>{t('instructions')}</h4>
                                <ol className="list-decimal list-inside space-y-2 text-sm">
                                    {guide.instructions.map((step, i) => <li key={i}>{step}</li>)}
                                </ol>
                            </div>
                            <div>
                                <h4 className="font-semibold text-lg mb-2 flex items-center gap-2"><AlertCircle className="h-5 w-5 text-chart-2"/>{t('commonMistakes')}</h4>
                                <ul className="list-disc list-inside space-y-2 text-sm">
                                    {guide.commonMistakes.map((mistake, i) => <li key={i}>{mistake}</li>)}
                                </ul>
                            </div>
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
}
