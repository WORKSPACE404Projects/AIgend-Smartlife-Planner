
"use client";

import * as React from 'react';
import { useTranslations } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { useExercise } from '@/contexts/ExerciseContext';
import { Loader2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { format, parseISO } from 'date-fns';

export function FitnessProgressView() {
    const t = useTranslations('Fitness');
    const { loggedWorkouts, loadingLogs } = useExercise();
    const [selectedExercise, setSelectedExercise] = React.useState<string | null>(null);

    const uniqueExercises = React.useMemo(() => {
        const names = new Set<string>();
        loggedWorkouts.forEach(log => {
            log.exercises.forEach(ex => names.add(ex.name));
        });
        return Array.from(names);
    }, [loggedWorkouts]);

    const chartData = React.useMemo(() => {
        if (!selectedExercise) return [];
        
        return loggedWorkouts
            .map(log => {
                const exerciseData = log.exercises.find(ex => ex.name === selectedExercise);
                if (!exerciseData) return null;

                const maxWeight = Math.max(...exerciseData.sets.map(set => set.weight || 0));

                return {
                    date: format(new Date(log.date), 'dd MMM'),
                    maxWeight,
                };
            })
            .filter(Boolean)
            .reverse(); // Show oldest logs first

    }, [loggedWorkouts, selectedExercise]);


    if (loadingLogs) {
        return <div className="flex justify-center items-center h-48"><Loader2 className="h-8 w-8 animate-spin" /></div>;
    }
    
    if (loggedWorkouts.length === 0) {
        return (
            <Card>
                <CardHeader>
                    <CardTitle>{t('progressTab')}</CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">{t('noLogsYet')}</p>
                </CardContent>
            </Card>
        );
    }
    
    return (
        <Card>
            <CardHeader>
                <CardTitle>{t('progressTab')}</CardTitle>
                <CardDescription>{t('helpProgress2')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
                <Select onValueChange={setSelectedExercise} value={selectedExercise || ''}>
                    <SelectTrigger className="w-full md:w-1/2">
                        <SelectValue placeholder={t('selectExercise')} />
                    </SelectTrigger>
                    <SelectContent>
                        {uniqueExercises.map(name => (
                            <SelectItem key={name} value={name}>{name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>

                {selectedExercise && chartData.length > 0 && (
                    <div className="h-[400px]">
                        <h3 className="text-lg font-semibold mb-4 text-center">{t('progressChartTitle', { exercise: selectedExercise })}</h3>
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="date" />
                                <YAxis />
                                <Tooltip 
                                     contentStyle={{
                                        backgroundColor: "hsl(var(--background))",
                                        borderColor: "hsl(var(--border))",
                                    }}
                                />
                                <Legend />
                                <Line type="monotone" dataKey="maxWeight" name={t('maxWeight')} stroke="hsl(var(--primary))" strokeWidth={2} activeDot={{ r: 8 }} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                )}
                 {selectedExercise && chartData.length === 0 && (
                    <p className="text-muted-foreground">{t('noLogsYet')}</p>
                 )}
            </CardContent>
        </Card>
    );
}

