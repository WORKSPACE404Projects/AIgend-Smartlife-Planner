
"use client";

import * as React from "react";
import dynamic from 'next/dynamic';
import { useTranslations } from "next-intl";
import Link from 'next/link';
import { AlertCircle, ChevronLeft, ChevronRight, Minimize2 } from "lucide-react";

import { FitnessHeader } from "@/components/fitness/FitnessHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import type { CalendarEvent, PersonalData } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent } from "../ui/tabs";
import { Skeleton } from "../ui/skeleton";

// --- Dynamic Import for Lazy Loading ---
const DynamicWorkoutPlanner = dynamic(() => import('@/components/fitness/WorkoutPlanner').then(mod => mod.WorkoutPlanner), {
  loading: () => (
    <div className="max-w-2xl mx-auto">
      <Skeleton className="h-[500px] w-full" />
    </div>
  ),
  ssr: false
});

const DynamicWorkoutCalendarView = dynamic(() => import('@/components/fitness/WorkoutCalendarView').then(mod => mod.WorkoutCalendarView), {
  loading: () => <Skeleton className="h-full w-full min-h-[200px]" />,
  ssr: false
});

const DynamicFitnessProgressView = dynamic(() => import('@/components/fitness/FitnessProgressView').then(mod => mod.FitnessProgressView), {
  loading: () => <Skeleton className="h-[400px] w-full" />,
  ssr: false
});


interface FitnessViewProps {
  personalData: PersonalData;
  fitnessEvents: CalendarEvent[];
  onEventClick: (event: CalendarEvent) => void;
  onLogClick: (event: CalendarEvent) => void;
}

export function FitnessView({ personalData, fitnessEvents, onEventClick, onLogClick }: FitnessViewProps) {
  const t = useTranslations("Fitness");
  const [expandedView, setExpandedView] = React.useState<string | null>(null);

  // Tab state management
  const tabs = React.useMemo(() => [
    { value: 'help', label: t('title') },
    { value: 'planner', label: t('plannerTab') },
    { value: 'weekly-view', label: t('weeklyViewTab') },
    { value: 'progress', label: t('progressTab') },
  ], [t]);

  const [activeTab, setActiveTab] = React.useState(tabs[0].value);
  const activeTabIndex = React.useMemo(() => tabs.findIndex(tab => tab.value === activeTab), [tabs, activeTab]);

  const handlePrevTab = () => {
    const newIndex = activeTabIndex > 0 ? activeTabIndex - 1 : tabs.length - 1;
    setActiveTab(tabs[newIndex].value);
  };

  const handleNextTab = () => {
    const newIndex = activeTabIndex < tabs.length - 1 ? activeTabIndex + 1 : 0;
    setActiveTab(tabs[newIndex].value);
  };

  const isProfileComplete = personalData.age && personalData.weight && personalData.height && personalData.sex && personalData.activityLevel && personalData.fitnessGoal;

  const getExpandedViewTitle = () => {
    switch (expandedView) {
      case 'planner':
        return t('plannerTab');
      case 'progress':
        return t('progressTab');
      default:
        return '';
    }
  };

  return (
    <>
      <div className="flex h-screen flex-col text-foreground">
        <FitnessHeader />
        <main className="h-[85vh] overflow-auto p-4 md:p-6">
          {!isProfileComplete ? (
            <Alert variant="destructive" className="max-w-2xl mx-auto">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>{t('dataNeededTitle')}</AlertTitle>
              <AlertDescription>
                  <p className="mb-4">{t('dataNeeded')}</p>
                  <Link href="/profile">
                      <Button variant="outline">{t('profile')}</Button>
                  </Link>
              </AlertDescription>
            </Alert>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
              <div className="flex items-center justify-center gap-4 px-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrevTab}>
                      <ChevronLeft className="h-5 w-5" />
                  </Button>

                  <div className="flex items-center justify-center gap-4 flex-1">
                      {tabs.map((tab, index) => (
                          <button
                              key={tab.value}
                              onClick={() => setActiveTab(tab.value)}
                              className={cn(
                                  "py-1 font-medium transition-colors",
                                  activeTabIndex === index
                                      ? "text-foreground text-sm"
                                      : "text-muted-foreground text-2xl leading-none"
                              )}
                          >
                              {activeTabIndex === index ? tab.label : '•'}
                          </button>
                      ))}
                  </div>
                  
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNextTab}>
                      <ChevronRight className="h-5 w-5" />
                  </Button>
              </div>
              
              <TabsContent value="help" className="mt-4">
                <Card className="max-w-2xl mx-auto">
                    <CardHeader>
                        <CardTitle>{t('title')}</CardTitle>
                        <CardDescription>{t('helpDescription')}</CardDescription>
                    </CardHeader>
                    <CardContent className="prose prose-sm dark:prose-invert max-w-none space-y-4">
                        <div>
                            <h4>{t('plannerTab')}</h4>
                            <ul>
                                <li>{t('helpPlanner1')}</li>
                                <li>{t('helpPlanner2')}</li>
                            </ul>
                        </div>
                        <div>
                            <h4>{t('weeklyViewTab')}</h4>
                            <ul>
                                <li>{t('helpWeeklyView1')}</li>
                            </ul>
                        </div>
                        <div>
                            <h4>{t('progressTab')}</h4>
                            <ul>
                                <li>{t('helpProgress1')}</li>
                                <li>{t('helpProgress2')}</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="planner" className="mt-4">
                <div onClick={() => setExpandedView('planner')} className="cursor-pointer">
                  <DynamicWorkoutPlanner personalData={personalData} />
                </div>
              </TabsContent>
              <TabsContent value="weekly-view" className="mt-4">
                  <DynamicWorkoutCalendarView 
                      events={fitnessEvents} 
                      onEventClick={onEventClick}
                      onLogClick={onLogClick}
                  />
              </TabsContent>
              <TabsContent value="progress" className="mt-4">
                <div onClick={() => setExpandedView('progress')} className="cursor-pointer">
                  <DynamicFitnessProgressView />
                </div>
              </TabsContent>
            </Tabs>
          )}
        </main>
      </div>

      {expandedView && (
        <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0">
          <div className="w-full h-full flex flex-col p-4 md:p-6">
            <header className="flex items-center justify-between pb-4 shrink-0">
                <h2 className="text-2xl font-bold">{getExpandedViewTitle()}</h2>
                <Button variant="ghost" size="icon" onClick={() => setExpandedView(null)}>
                    <Minimize2 className="h-6 w-6" />
                    <span className="sr-only">Minimize</span>
                </Button>
            </header>
            <div className="flex-1 overflow-auto flex items-center justify-center">
              {expandedView === 'planner' && (
                <div className="w-full h-full">
                  <DynamicWorkoutPlanner personalData={personalData} />
                </div>
              )}
              {expandedView === 'progress' && (
                 <div className="w-full h-full">
                    <DynamicFitnessProgressView />
                 </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
