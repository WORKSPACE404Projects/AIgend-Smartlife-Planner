
"use client";

import { eachDayOfInterval, endOfWeek, format, isSameDay, startOfWeek } from "date-fns";
import { useLocale, useTranslations } from "next-intl";
import { cn } from "@/lib/utils";
import type { CalendarEvent } from "@/lib/types";
import { getDateFnsLocale } from "@/lib/i18n";
import { Dumbbell, ClipboardList } from "lucide-react";
import { Button } from "../ui/button";

interface WorkoutCalendarViewProps {
  events: CalendarEvent[];
  onEventClick: (event: CalendarEvent) => void;
  onLogClick: (event: CalendarEvent) => void;
}

export function WorkoutCalendarView({ events, onEventClick, onLogClick }: WorkoutCalendarViewProps) {
  const t = useTranslations("Fitness");
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);
  const currentDate = new Date();

  const workoutEvents = events.filter(e => e.category === 'fitness');

  const weekStart = startOfWeek(currentDate, { locale: dateFnsLocale, weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentDate, { locale: dateFnsLocale, weekStartsOn: 1 });
  const daysInWeek = eachDayOfInterval({ start: weekStart, end: weekEnd });

  const getEventsForDay = (day: Date) => {
    return workoutEvents
      .filter((event) => isSameDay(event.start, day))
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  };

  return (
    <div className="h-full overflow-auto">
      <div className="grid grid-cols-1 md:grid-cols-7">
        {daysInWeek.map((day) => (
          <div key={day.toString()} className="border-b md:border-b-0 md:border-r">
            <div className="text-center py-2 border-b bg-muted/50">
              <p className="text-sm font-semibold">{format(day, "eee", { locale: dateFnsLocale })}</p>
              <p className="text-xs text-muted-foreground">{format(day, "d MMM", { locale: dateFnsLocale })}</p>
            </div>
            <div className="p-2 space-y-2 min-h-[120px]">
              {getEventsForDay(day).length > 0 ? getEventsForDay(day).map(event => (
                <div 
                  key={event.id}
                  className="p-2 rounded-md text-xs"
                  style={{ backgroundColor: event.color ? `${event.color}20` : undefined }}
                >
                  <p className="font-bold cursor-pointer" onClick={() => onEventClick(event)}>{event.title}</p>
                  <p className="text-muted-foreground truncate">{event.description}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start mt-2 h-7 px-2 text-xs"
                    onClick={() => onLogClick(event)}
                  >
                    <ClipboardList className="mr-2 h-3 w-3" />
                    {t('logWorkout')}
                  </Button>
                </div>
              )) : (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <Dumbbell className="h-5 w-5 opacity-50" />
                  <p className="text-xs mt-1">{t('noWorkout')}</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
