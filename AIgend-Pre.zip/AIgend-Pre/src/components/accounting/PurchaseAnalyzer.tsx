"use client";

import * as React from 'react';
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useLocale, useTranslations } from 'next-intl';
import { AlertCircle, Bot, CheckCircle, Loader2, Sparkles, XCircle } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { analyzePurchase, type PurchaseAnalyzerInput, type PurchaseAnalyzerOutput } from '@/ai/flows/purchase-analyzer-flow';
import type { PersonalData } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Avatar, AvatarFallback } from '../ui/avatar';
import { ScrollArea } from '../ui/scroll-area';

const createAnalyzerFormSchema = (t: (key: any) => string) => z.object({
  purchaseDescription: z.string().min(3, { message: t('errorDescription') }),
  purchaseAmount: z.coerce.number().positive({ message: t('errorAmount') }),
  purchaseCategory: z.string().min(1, { message: t('errorCategory') }),
  purchaseJustification: z.string().min(10, { message: t('errorJustification') }),
});

type AnalyzerFormValues = z.infer<ReturnType<typeof createAnalyzerFormSchema>>;

function useAnalyzerFormSchema() {
  const t = useTranslations("PurchaseAnalyzer");
  return React.useMemo(() => createAnalyzerFormSchema(t), [t]);
}

interface PurchaseAnalyzerProps {
  personalData: PersonalData;
}

export function PurchaseAnalyzer({ personalData }: PurchaseAnalyzerProps) {
  const t = useTranslations("PurchaseAnalyzer");
  const locale = useLocale();
  const analyzerFormSchema = useAnalyzerFormSchema();

  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = React.useState<PurchaseAnalyzerOutput | null>(null);

  const form = useForm<AnalyzerFormValues>({
    resolver: zodResolver(analyzerFormSchema),
    defaultValues: {
      purchaseDescription: "",
      purchaseAmount: undefined,
      purchaseCategory: "",
      purchaseJustification: ""
    }
  });

  const onSubmit = async (data: AnalyzerFormValues) => {
    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);

    const flowInput: PurchaseAnalyzerInput = {
      personalData,
      ...data,
      locale,
    };
    
    try {
      const result = await analyzePurchase(flowInput);
      setAnalysisResult(result);
    } catch (err) {
      console.error("Error analyzing purchase:", err);
      setError(t('errorMessage'));
    } finally {
      setIsLoading(false);
    }
  };

  const ResultIcon = () => {
    if (!analysisResult) return null;
    switch(analysisResult.recommendation) {
      case 'recommended':
        return <CheckCircle className="h-12 w-12 text-chart-1" />;
      case 'caution':
        return <AlertCircle className="h-12 w-12 text-chart-2" />;
      case 'not_recommended':
        return <XCircle className="h-12 w-12 text-chart-3" />;
      default:
        return null;
    }
  }

  const recommendationText = analysisResult ? t(analysisResult.recommendation) : '';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>{t('title')}</CardTitle>
          <CardDescription>{t('description')}</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField control={form.control} name="purchaseDescription" render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('purchaseDescriptionLabel')}</FormLabel>
                  <FormControl><Input placeholder={t('purchaseDescriptionPlaceholder')} {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <div className="grid grid-cols-2 gap-4">
                <FormField control={form.control} name="purchaseAmount" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('amountLabel')}</FormLabel>
                    <FormControl><Input type="number" placeholder={t('amountPlaceholder')} {...field} value={field.value ?? ''} /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="purchaseCategory" render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t('categoryLabel')}</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl><SelectTrigger><SelectValue placeholder={t('categoryPlaceholder')} /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="technology">{t('categoryTechnology')}</SelectItem>
                        <SelectItem value="leisure">{t('categoryLeisure')}</SelectItem>
                        <SelectItem value="health">{t('categoryHealth')}</SelectItem>
                        <SelectItem value="education">{t('categoryEducation')}</SelectItem>
                        <SelectItem value="home">{t('categoryHome')}</SelectItem>
                        <SelectItem value="other">{t('categoryOther')}</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>

              <FormField control={form.control} name="purchaseJustification" render={({ field }) => (
                <FormItem>
                  <FormLabel>{t('justificationLabel')}</FormLabel>
                  <FormControl><Textarea placeholder={t('justificationPlaceholder')} {...field} /></FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold"
              >
                {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4 drop-shadow-cyan-glow" />}
                <span className="drop-shadow-cyan-glow">{t('analyzeButton')}</span>
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <Card className="flex flex-col">
        <CardHeader>
          <CardTitle>{t('resultTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col items-center justify-center overflow-hidden">
          {isLoading && (
            <div className="text-center">
              <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
              <p className="mt-4 text-muted-foreground">{t('loading')}</p>
            </div>
          )}
          {error && (
            <Alert variant="destructive" className="w-full">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>{t('errorTitle')}</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {!isLoading && !error && !analysisResult && (
             <div className="text-center text-muted-foreground">
                <Bot className="h-16 w-16 mx-auto mb-4 text-cyan-400 drop-shadow-cyan-glow" />
                <p>{t('waiting')}</p>
             </div>
          )}
          {analysisResult && (
            <ScrollArea className="h-full w-full pr-4">
              <div className="flex flex-col items-center text-center mb-6">
                <ResultIcon />
                <h3 className="text-2xl font-bold mt-4">{recommendationText}</h3>
                <p className="text-sm text-muted-foreground">{analysisResult.financialImpact}</p>
              </div>
              <div className="prose prose-sm dark:prose-invert max-w-none text-left">
                <ReactMarkdown>{analysisResult.analysis}</ReactMarkdown>
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
