
"use client";

import * as React from "react";
import dynamic from 'next/dynamic';
import { startOfToday, format, isWithinInterval, startOfMonth, endOfMonth, startOfWeek, endOfWeek, startOfDay, endOfDay } from "date-fns";
import { BarChart3, ChevronLeft, ChevronRight, Scale, TrendingUp, Minimize2 } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";

import { AccountingHeader } from "@/components/accounting/AccountingHeader";
import { TransactionDialog } from "@/components/accounting/TransactionDialog";
import type { AccountingTransaction, PersonalData } from "@/lib/types";
import { getDateFnsLocale } from "@/lib/i18n";
import { SummaryCards } from "./SummaryCards";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Skeleton } from "../ui/skeleton";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";

// --- Dynamic Imports for Lazy Loading ---

const DynamicAccountingChart = dynamic(() => import('@/components/accounting/AccountingChart').then(mod => mod.AccountingChart), {
  loading: () => <Skeleton className="h-[350px] w-full md:h-[500px]" />,
  ssr: false
});
const DynamicFinancialHealthIndex = dynamic(() => import('@/components/accounting/FinancialHealthIndex').then(mod => mod.FinancialHealthIndex), {
  loading: () => <Skeleton className="h-[250px] w-full" />,
  ssr: false
});
const DynamicTransactionList = dynamic(() => import('@/components/accounting/TransactionList').then(mod => mod.TransactionList), {
  loading: () => <Skeleton className="h-[400px] w-full" />,
  ssr: false
});
const DynamicPurchaseAnalyzer = dynamic(() => import('@/components/accounting/PurchaseAnalyzer').then(mod => mod.PurchaseAnalyzer), {
  loading: () => <Skeleton className="h-[550px] w-full" />,
  ssr: false
});
const DynamicFinancialCoach = dynamic(() => import('@/components/accounting/FinancialCoach').then(mod => mod.FinancialCoach), {
  loading: () => <Skeleton className="h-[450px] w-full" />,
  ssr: false
});


interface AccountingViewProps {
  transactions: AccountingTransaction[];
  personalData: PersonalData;
}

export function AccountingView({ transactions, personalData }: AccountingViewProps) {
  const t = useTranslations("Accounting");
  const tFinancialHealth = useTranslations("FinancialHealthIndex");
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);

  const [view, setView] = React.useState<"month" | "week" | "day">("month");
  const [currentDate, setCurrentDate] = React.useState<Date>(startOfToday());
  const [isDialogOpen, setIsDialogOpen] = React.useState(false);
  const [selectedTransaction, setSelectedTransaction] = React.useState<AccountingTransaction | null>(null);
  const [expandedView, setExpandedView] = React.useState<string | null>(null);

  const tabs = React.useMemo(() => [
    { value: 'help', label: t('title') },
    { value: 'summary', label: t('summaryTab') },
    { value: 'transactions', label: t('transactionsTab') },
    { value: 'analyzer', label: t('analyzerTab') },
    { value: 'coach', label: t('coachTab') },
  ], [t]);

  const [activeTab, setActiveTab] = React.useState(tabs[0].value);
  const activeTabIndex = React.useMemo(() => tabs.findIndex(tab => tab.value === activeTab), [tabs, activeTab]);

  const handlePrevTab = () => {
    const newIndex = activeTabIndex > 0 ? activeTabIndex - 1 : tabs.length - 1;
    setActiveTab(tabs[newIndex].value);
  };

  const handleNextTab = () => {
    const newIndex = activeTabIndex < tabs.length - 1 ? activeTabIndex + 1 : 0;
    setActiveTab(tabs[newIndex].value);
  };

  const { filteredTransactions, totalIncome, totalExpenses, netSavings } = React.useMemo(() => {
    let interval;
    if (view === 'month') {
      interval = { start: startOfMonth(currentDate), end: endOfMonth(currentDate) };
    } else if (view === 'week') {
      interval = { start: startOfWeek(currentDate, { locale: dateFnsLocale }), end: endOfWeek(currentDate, { locale: dateFnsLocale }) };
    } else { // day
      interval = { start: startOfDay(currentDate), end: endOfDay(currentDate) };
    }
    
    const relevantTransactions = transactions.filter(t => isWithinInterval(new Date(t.date), interval));

    const income = relevantTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);

    const expenses = relevantTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      filteredTransactions: relevantTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
      totalIncome: income,
      totalExpenses: expenses,
      netSavings: income - expenses,
    };
  }, [transactions, currentDate, view, dateFnsLocale]);

  const handleAddTransaction = () => {
    setSelectedTransaction(null);
    setIsDialogOpen(true);
  };

  const handleEditTransaction = (transaction: AccountingTransaction) => {
    setSelectedTransaction(transaction);
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setSelectedTransaction(null);
  };

  const getHeaderText = () => {
    if (view === "month" || view === "week") {
      return format(currentDate, "MMMM yyyy", { locale: dateFnsLocale });
    }
    return format(currentDate, "do LLL yyyy", { locale: dateFnsLocale });
  };
  
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(amount);
  };

  const getExpandedViewTitle = () => {
    switch (expandedView) {
      case 'summary':
        return t('netSavings');
      case 'chart':
        return t('chartTitle');
      case 'pfi':
        return tFinancialHealth('title');
      default:
        return '';
    }
  };


  return (
    <div className="flex h-screen flex-col text-foreground">
      <AccountingHeader
        view={view}
        onViewChange={setView}
        onAddTransaction={handleAddTransaction}
        headerText={getHeaderText()}
      />
      <main className="flex-1 overflow-auto p-4 md:p-6 min-h-0">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <div className="flex items-center justify-center gap-4 px-1">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrevTab}>
                    <ChevronLeft className="h-5 w-5" />
                </Button>

                <div className="flex items-center justify-center gap-4 flex-1">
                    {tabs.map((tab, index) => (
                        <button
                            key={tab.value}
                            onClick={() => setActiveTab(tab.value)}
                            className={cn(
                                "py-1 font-medium",
                                activeTabIndex === index
                                    ? "text-foreground text-sm"
                                    : "text-muted-foreground text-2xl leading-none"
                            )}
                        >
                            {activeTabIndex === index ? tab.label : '•'}
                        </button>
                    ))}
                </div>
                
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNextTab}>
                    <ChevronRight className="h-5 w-5" />
                </Button>
            </div>
            
            <TabsContent value="help" className="mt-4">
                <Card>
                    <CardHeader>
                        <CardTitle>{t('title')}</CardTitle>
                        <CardDescription>{t('helpDescription')}</CardDescription>
                    </CardHeader>
                    <CardContent className="prose prose-sm dark:prose-invert max-w-none space-y-4">
                        <div>
                            <h4>{t('summaryTab')}</h4>
                            <ul>
                                <li>{t('helpSummary1')}</li>
                                <li>{t('helpSummary2')}</li>
                            </ul>
                        </div>
                        <div>
                            <h4>{t('transactionsTab')}</h4>
                            <ul>
                                <li>{t('helpTransactions1')}</li>
                                <li>{t('helpTransactions2')}</li>
                            </ul>
                        </div>
                        <div>
                            <h4>{t('analyzerTab')}</h4>
                            <ul>
                                <li>{t('helpAnalyzer1')}</li>
                                <li>{t('helpAnalyzer2')}</li>
                            </ul>
                        </div>
                        <div>
                            <h4>{t('coachTab')}</h4>
                            <ul>
                                <li>{t('helpCoach1')}</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="summary" className="mt-4">
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-6">
                <Card
                  className="flex flex-col justify-between cursor-pointer"
                  onClick={() => setExpandedView('summary')}
                >
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle>{t('netSavings')}</CardTitle>
                      <Scale className="h-6 w-6 text-muted-foreground" />
                    </div>
                    <CardDescription>{t('summaryCardDescription')}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex items-center justify-center flex-1">
                    <p className={cn("text-3xl md:text-5xl font-bold", netSavings >= 0 ? "text-chart-1" : "text-chart-3")}>
                      {formatCurrency(netSavings)}
                    </p>
                  </CardContent>
                </Card>

                <Card
                  className="flex flex-col justify-between cursor-pointer"
                  onClick={() => setExpandedView('chart')}
                >
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle>{t('chartTitle')}</CardTitle>
                      <BarChart3 className="h-6 w-6 text-muted-foreground" />
                    </div>
                    <CardDescription>{t('chartCardDescription')}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex items-center justify-center flex-1">
                    <p className="text-muted-foreground">{t('chartCardContent')}</p>
                  </CardContent>
                </Card>

                <Card
                  className="flex flex-col justify-between cursor-pointer"
                  onClick={() => setExpandedView('pfi')}
                >
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle>{tFinancialHealth('title')}</CardTitle>
                      <TrendingUp className="h-6 w-6 text-muted-foreground" />
                    </div>
                    <CardDescription>{tFinancialHealth('description')}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex items-center justify-center flex-1">
                    <p className="text-muted-foreground">{t('pfiCardContent')}</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="transactions" className="mt-4">
                 <DynamicTransactionList
                    transactions={filteredTransactions} 
                    onRowClick={handleEditTransaction}
                />
            </TabsContent>
            <TabsContent value="analyzer" className="mt-4">
                <DynamicPurchaseAnalyzer personalData={personalData} />
            </TabsContent>
            <TabsContent value="coach" className="mt-4">
                <DynamicFinancialCoach data={personalData} />
            </TabsContent>
        </Tabs>
      </main>

      {expandedView && (
        <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0">
          <div className="w-full h-full flex flex-col p-4 md:p-6">
            <header className="flex items-center justify-between pb-4 shrink-0">
                <h2 className="text-2xl font-bold">{getExpandedViewTitle()}</h2>
                <Button variant="ghost" size="icon" onClick={() => setExpandedView(null)}>
                    <Minimize2 className="h-6 w-6" />
                    <span className="sr-only">Minimize</span>
                </Button>
            </header>
            <div className="flex-1 overflow-auto flex items-center justify-center">
              {expandedView === 'summary' && (
                <SummaryCards income={totalIncome} expense={totalExpenses} net={netSavings} />
              )}
              {expandedView === 'chart' && (
                  <div className="h-full w-full">
                      <DynamicAccountingChart
                        view={view}
                        currentDate={currentDate}
                        transactions={transactions}
                        onBarClick={(transaction) => {
                          handleEditTransaction(transaction);
                          setExpandedView(null);
                        }}
                      />
                  </div>
              )}
              {expandedView === 'pfi' && (
                 <DynamicFinancialHealthIndex data={personalData} />
              )}
            </div>
          </div>
        </div>
      )}
      
      <TransactionDialog
        isOpen={isDialogOpen}
        onOpenChange={handleCloseDialog}
        transaction={selectedTransaction}
      />
    </div>
  );
}
