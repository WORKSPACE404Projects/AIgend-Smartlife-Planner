"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { format } from "date-fns";
import { CalendarIcon, Trash2 } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { cn } from "@/lib/utils";
import type { AccountingTransaction } from "@/lib/types";
import { getDateFnsLocale } from "@/lib/i18n";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAccounting } from "@/contexts/AccountingContext";

const createTransactionFormSchema = (t: (key: any) => string) => z.object({
    description: z.string().min(1, { message: t('descriptionError') }),
    amount: z.coerce.number().positive({ message: t('amountError') }),
    type: z.enum(['income', 'expense']),
    date: z.date(),
});

type TransactionFormValues = z.infer<ReturnType<typeof createTransactionFormSchema>>;

function useTransactionFormSchema() {
    const t = useTranslations("Accounting");
    return React.useMemo(() => createTransactionFormSchema(t), [t]);
}

interface TransactionDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  transaction: AccountingTransaction | null;
}

export function TransactionDialog({ isOpen, onOpenChange, transaction }: TransactionDialogProps) {
  const t = useTranslations("Accounting");
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);
  const transactionFormSchema = useTransactionFormSchema();
  const { saveTransaction, deleteTransaction } = useAccounting();

  const form = useForm<TransactionFormValues>({
    resolver: zodResolver(transactionFormSchema),
  });

  const { reset } = form;

  React.useEffect(() => {
    if (isOpen) {
      const defaultValues = transaction
        ? { ...transaction, date: new Date(transaction.date) }
        : {
            description: "",
            amount: 0,
            type: "expense" as "income" | "expense",
            date: new Date(),
          };
      reset(defaultValues);
    }
  }, [isOpen, transaction, reset]);

  const onSubmit = async (data: TransactionFormValues) => {
    if (transaction) {
      await saveTransaction({ ...data, id: transaction.id });
    } else {
      await saveTransaction(data);
    }
    onOpenChange(false);
  };
  
  const handleDelete = async () => {
    if (transaction) {
        await deleteTransaction(transaction.id);
        onOpenChange(false);
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent 
        className="sm:max-w-[480px]"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        <ScrollArea className="max-h-[90vh]">
          <div className="p-6">
            <DialogHeader>
              <DialogTitle>{transaction ? t('editTransaction') : t('addTransaction')}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>{t('typeLabel')}</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex space-x-4"
                        >
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="income" />
                            </FormControl>
                            <FormLabel className="font-normal">{t('income')}</FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="expense" />
                            </FormControl>
                            <FormLabel className="font-normal">{t('expense')}</FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('descriptionLabel')}</FormLabel>
                      <FormControl>
                        <Input placeholder={t('descriptionPlaceholder')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('amountLabel')}</FormLabel>
                        <FormControl>
                           <Input type="number" step="0.01" placeholder={t('amountPlaceholder')} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>{t('dateLabel')}</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button variant={"outline"} className={cn("pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                {field.value ? format(field.value, 'MMM d, yyyy', {locale: dateFnsLocale}) : <span>{t('datePlaceholder')}</span>}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus locale={dateFnsLocale} />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <DialogFooter className="pt-4">
                  {transaction && (
                    <Button type="button" variant="destructive" onClick={handleDelete} className="mr-auto">
                      <Trash2 className="mr-2 h-4 w-4" /> {t('deleteButton')}
                    </Button>
                  )}
                  <DialogClose asChild>
                    <Button type="button" variant="outline">{t('cancelButton')}</Button>
                  </DialogClose>
                  <Button type="submit" className="shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold">
                    <span className="drop-shadow-cyan-glow">{t('saveButton')}</span>
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
