"use client";

import { useLocale, useTranslations } from "next-intl";
import { format } from 'date-fns';

import type { AccountingTransaction } from "@/lib/types";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { getDateFnsLocale } from "@/lib/i18n";

interface TransactionListProps {
  transactions: AccountingTransaction[];
  onRowClick: (transaction: AccountingTransaction) => void;
}

const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(amount);
};


export function TransactionList({ transactions, onRowClick }: TransactionListProps) {
  const t = useTranslations("Accounting");
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('transactionsTitle')}</CardTitle>
        <CardDescription>{t('transactionsDescription')}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="border rounded-md">
            <Table>
            <TableHeader>
                <TableRow>
                <TableHead>{t('dateLabel')}</TableHead>
                <TableHead>{t('descriptionLabel')}</TableHead>
                <TableHead className="text-right">{t('amountLabel')}</TableHead>
                </TableRow>
            </TableHeader>
            <TableBody>
                {transactions.length > 0 ? (
                transactions.map((transaction) => (
                    <TableRow key={transaction.id} onClick={() => onRowClick(transaction)} className="cursor-pointer">
                    <TableCell className="font-medium">{format(transaction.date, 'dd MMM yyyy', {locale: dateFnsLocale})}</TableCell>
                    <TableCell>
                        {transaction.description}
                        <Badge variant="outline" className={cn('ml-2 border-transparent text-primary-foreground', transaction.type === 'income' ? 'bg-chart-1' : 'bg-chart-3')}>
                            {t(transaction.type)}
                        </Badge>
                    </TableCell>
                    <TableCell className={cn("text-right font-semibold", transaction.type === 'income' ? 'text-chart-1' : 'text-chart-3')}>
                        {transaction.type === 'income' ? '+' : '-'} {formatCurrency(Math.abs(transaction.amount))}
                    </TableCell>
                    </TableRow>
                ))
                ) : (
                <TableRow>
                    <TableCell colSpan={3} className="text-center h-24">
                    {t('noTransactions')}
                    </TableCell>
                </TableRow>
                )}
            </TableBody>
            </Table>
        </div>
      </CardContent>
    </Card>
  );
}
