"use client";

import * as React from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { Bot, Loader2, Send, User, Maximize2, Minimize2, Mic, MicOff } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import type { PersonalData } from '@/lib/types';
import { getFinancialAdvice, type FinancialCoachInput } from '@/ai/flows/financial-coach-flow';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import useSpeechRecognition from '@/hooks/use-speech-recognition';

interface FinancialCoachProps {
  data: PersonalData;
}

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export function FinancialCoach({ data }: FinancialCoachProps) {
  const t = useTranslations('FinancialCoach');
  const locale = useLocale();
  const [messages, setMessages] = React.useState<Message[]>([]);
  const [input, setInput] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const [isExpanded, setIsExpanded] = React.useState(false);
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  const {
    text: transcript,
    isListening,
    startListening,
    stopListening,
    hasRecognitionSupport
  } = useSpeechRecognition(locale);

  React.useEffect(() => {
    if (transcript) {
      setInput(transcript);
    }
  }, [transcript]);


  React.useEffect(() => {
    setMessages([
      { role: 'assistant', content: t('initialMessage') }
    ]);
  }, [t]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  React.useEffect(() => {
    if (messages.length > 1 || isLoading) {
      scrollToBottom();
    }
  }, [messages, isLoading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const financialDataForFlow = {
        totalMonthlyIncome: data.totalMonthlyIncome,
        fixedMonthlyExpenses: data.fixedMonthlyExpenses,
        variableMonthlyExpenses: data.variableMonthlyExpenses,
        totalDebt: data.totalDebt,
        liquidSavings: data.liquidSavings,
        monthlyInvestment: data.monthlyInvestment,
        goals: data.goals,
      };
      
      const flowInput: FinancialCoachInput = {
        financialData: financialDataForFlow,
        query: input,
        userName: data.firstName,
      };
      const result = await getFinancialAdvice(flowInput);
      const assistantMessage: Message = { role: 'assistant', content: result.advice };
      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = { role: 'assistant', content: t('errorMessage') };
      setMessages((prev) => [...prev, errorMessage]);
      console.error("Error calling financial coach flow:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className={cn(
        "flex flex-col relative transition-all duration-300 ease-in-out", 
        isExpanded ? "fixed inset-0 z-50 rounded-none border-none" : "h-[450px]"
      )}>
      <CardHeader>
        <CardTitle>{t('title')}</CardTitle>
        <CardDescription>{t('description')}</CardDescription>
      </CardHeader>
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute top-4 right-4 h-8 w-8 text-muted-foreground"
              onClick={() => setIsExpanded(!isExpanded)}
              aria-label={isExpanded ? t('collapse') : t('expand')}
            >
              {isExpanded ? <Minimize2 className="h-5 w-5" /> : <Maximize2 className="h-5 w-5" />}
            </Button>
          </TooltipTrigger>
          <TooltipContent>
            <p>{isExpanded ? t('collapse') : t('expand')}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      <CardContent className="flex-1 overflow-hidden">
        <ScrollArea className="h-full pr-4">
          <div className="space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={cn(
                  'flex items-start gap-3',
                  message.role === 'user' ? 'justify-end' : 'justify-start'
                )}
              >
                {message.role === 'assistant' && (
                  <Avatar className="h-8 w-8 shadow-cyan-glow">
                    <AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={cn(
                    'max-w-md rounded-lg p-3 text-sm whitespace-pre-wrap',
                    message.role === 'user'
                      ? 'bg-primary/30 text-primary-foreground border border-primary/50 backdrop-blur-sm'
                      : 'border border-border/20 bg-card/50 backdrop-blur-sm'
                  )}
                >
                  {message.content}
                </div>
                 {message.role === 'user' && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback><User /></AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex items-start gap-3 justify-start">
                  <Avatar className="h-8 w-8 shadow-cyan-glow">
                    <AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback>
                  </Avatar>
                 <div className="rounded-lg p-3 flex items-center space-x-2 border border-border/20 bg-card/50 backdrop-blur-sm">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm text-muted-foreground">{t('loading')}</span>
                </div>
              </div>
            )}
             <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter>
        <form onSubmit={handleSubmit} className="flex w-full items-center space-x-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isListening ? t('inputPlaceholderListening') : t('inputPlaceholder')}
            disabled={isLoading}
            className="bg-transparent"
          />
          {hasRecognitionSupport && (
              <Button
                  type="button"
                  size="icon"
                  variant={isListening ? "destructive" : "outline"}
                  onClick={isListening ? stopListening : startListening}
                  disabled={isLoading}
                  aria-label={isListening ? "Stop listening" : "Start listening"}
              >
                  {isListening ? <MicOff /> : <Mic />}
              </Button>
          )}
          <Button 
            type="submit" 
            size="icon"
            className="shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400"
            disabled={isLoading || !input.trim()}>
            <Send className="h-4 w-4 drop-shadow-cyan-glow" />
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
}
