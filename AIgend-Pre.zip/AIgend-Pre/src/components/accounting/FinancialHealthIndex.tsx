"use client";

import * as React from 'react';
import { useTranslations } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import type { PersonalData } from '@/lib/types';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface FinancialHealthIndexProps {
  data: PersonalData;
}

const getScoreColor = (score: number): string => {
  if (score >= 75) return 'bg-chart-1'; // Green
  if (score >= 40) return 'bg-chart-2'; // Yellow
  return 'bg-chart-3'; // Red
};

const getRatioColor = (score: number, thresholds: [number, number], invert = false): string => {
    if (invert) {
        if (score <= thresholds[0]) return 'bg-chart-1'; // Green
        if (score <= thresholds[1]) return 'bg-chart-2'; // Yellow
        return 'bg-chart-3'; // Red
    }
    if (score >= thresholds[1]) return 'bg-chart-1'; // Green
    if (score >= thresholds[0]) return 'bg-chart-2'; // Yellow
    return 'bg-chart-3'; // Red
};


const Indicator = ({ label, value, tooltip, colorClass }: { label: string; value: number; tooltip: string, colorClass: string }) => (
  <TooltipProvider>
    <Tooltip>
      <TooltipTrigger className="w-full text-left">
        <div className="space-y-1">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">{label}</span>
            <span>{Math.round(value)}%</span>
          </div>
          <Progress value={value} className={cn('h-2', colorClass)} />
        </div>
      </TooltipTrigger>
      <TooltipContent>
        <p>{tooltip}</p>
      </TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

export function FinancialHealthIndex({ data }: FinancialHealthIndexProps) {
  const t = useTranslations('FinancialHealthIndex');

  const {
    totalMonthlyIncome: income = 0,
    fixedMonthlyExpenses: fixed = 0,
    variableMonthlyExpenses: variable = 0,
    totalDebt: debt = 0,
    liquidSavings: savings = 0,
    monthlyInvestment = 0,
    goals = [],
  } = data || {};

  const totalExpenses = fixed + variable;

  const calculations = React.useMemo(() => {
    // 1. Savings Rate
    const savingsRate = income > 0 ? ((income - totalExpenses) / income) * 100 : 0;
    const savingsRateScore = Math.min(Math.max(savingsRate / 20, 0), 1) * 100;

    // 2. Fixed Expenses Ratio
    const fixedRatio = income > 0 ? (fixed / income) * 100 : 100;
    const fixedRatioScore = Math.min(Math.max(1 - (fixedRatio - 50) / 20, 0), 1) * 100;

    // 3. Debt to Income Ratio (Total Debt / Annual Income)
    const annualIncome = income * 12;
    const debtRatio = annualIncome > 0 ? (debt / annualIncome) * 100 : 100;
    const debtRatioScore = Math.max(0, 100 - debtRatio * 2);

    // 4. Financial Autonomy
    const autonomyMonths = totalExpenses > 0 ? savings / totalExpenses : 0;
    const autonomyScore = Math.min((autonomyMonths / 6) * 100, 100);

    // 5. Goals Progress
    const totalTarget = goals.reduce((acc, goal) => acc + goal.targetAmount, 0);
    const totalSaved = goals.reduce((acc, goal) => acc + goal.currentAmount, 0);
    const goalsProgress = totalTarget > 0 ? (totalSaved / totalTarget) * 100 : 100;

    // 6. Investment Rate
    const investmentRate = income > 0 ? (monthlyInvestment / income) * 100 : 0;
    const investmentScore = Math.min(Math.max(investmentRate / 15, 0), 1) * 100;

    // PFI Calculation
    const weights = { savings: 0.3, autonomy: 0.25, debt: 0.2, goals: 0.15, fixed: 0.1 };
    const pfi =
      savingsRateScore * weights.savings +
      autonomyScore * weights.autonomy +
      debtRatioScore * weights.debt +
      goalsProgress * weights.goals +
      fixedRatioScore * weights.fixed;
      
    return {
      pfi, savingsRate, fixedRatio, debtRatio, autonomyMonths, goalsProgress, investmentRate, savingsRateScore, fixedRatioScore, debtRatioScore, autonomyScore
    };
  }, [income, fixed, variable, debt, savings, monthlyInvestment, goals]);
  
  const { pfi, savingsRate, fixedRatio, autonomyMonths, goalsProgress, investmentRate, savingsRateScore, fixedRatioScore, debtRatioScore, autonomyScore } = calculations;

  const pfiScore = Math.round(pfi);

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('title')}</CardTitle>
        <CardDescription>{t('description')}</CardDescription>
      </CardHeader>
      <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="flex flex-col items-center justify-center space-y-2 p-6 bg-muted rounded-lg">
          <div
            className={cn(
              'w-32 h-32 rounded-full flex items-center justify-center text-5xl font-bold text-primary-foreground',
              getScoreColor(pfiScore)
            )}
          >
            {pfiScore}
          </div>
          <p className="text-lg font-semibold">{t('yourPFI')}</p>
        </div>

        <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
            <Indicator label={t('savingsRate')} value={savingsRate} tooltip={t('savingsRateTooltip')} colorClass={getRatioColor(savingsRate, [10, 20])}/>
            <Indicator label={t('financialAutonomy')} value={autonomyScore} tooltip={t('financialAutonomyTooltip', {months: autonomyMonths.toFixed(1)})} colorClass={getRatioColor(autonomyMonths, [3, 6])} />
            <Indicator label={t('fixedExpensesRatio')} value={fixedRatio} tooltip={t('fixedExpensesRatioTooltip')} colorClass={getRatioColor(fixedRatio, [50, 60], true)} />
            <Indicator label={t('debtRatio')} value={debtRatioScore} tooltip={t('debtRatioTooltip')} colorClass={getScoreColor(debtRatioScore)} />
            <Indicator label={t('goalsProgress')} value={goalsProgress} tooltip={t('goalsProgressTooltip')} colorClass={getRatioColor(goalsProgress, [50, 80])} />
            <Indicator label={t('investmentRate')} value={investmentRate} tooltip={t('investmentRateTooltip')} colorClass={getRatioColor(investmentRate, [5, 10])} />
        </div>
      </CardContent>
    </Card>
  );
}

// Override Progress to allow custom color
const OldProgress = ({ value, className }: { value: number, className?: string }) => (
    <div className="w-full bg-muted rounded-full h-2">
      <div className={cn("h-2 rounded-full", className)} style={{ width: `${value}%` }} />
    </div>
);
