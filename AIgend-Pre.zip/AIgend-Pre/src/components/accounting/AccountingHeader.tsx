
"use client";

import { Plus } from "lucide-react";
import { useTranslations } from "next-intl";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface AccountingHeaderProps {
  view: "month" | "week" | "day";
  onViewChange: (view: "month" | "week" | "day") => void;
  onAddTransaction: () => void;
  headerText: string;
}

export function AccountingHeader({
  view,
  onViewChange,
  onAddTransaction,
  headerText,
}: AccountingHeaderProps) {
  const t = useTranslations("Accounting");

  return (
    <header className="flex items-center justify-between border-b p-4 h-[15vh] px-6">
        {/* Left Section (for spacing) */}
        <div className="flex-1"></div>

        {/* Center Section */}
        <div className="flex flex-col items-center justify-center text-center">
            <h1 className="text-2xl font-bold">{t('title')}</h1>
            <h2 className="text-sm font-semibold capitalize text-muted-foreground mt-1">
                {headerText}
            </h2>
            <div className="flex rounded-md bg-background/80 dark:bg-gray-950/70 backdrop-blur-sm shadow-lg p-0.5 border mt-2">
                <Button
                    variant="ghost"
                    size="sm"
                    className={cn("h-7 px-2 text-xs", view === "month" && "text-cyan-400 drop-shadow-cyan-glow")}
                    onClick={() => onViewChange("month")}
                >
                    {t('month')}
                </Button>
                <Button
                    variant="ghost"
                    size="sm"
                    className={cn("h-7 px-2 text-xs", view === "week" && "text-cyan-400 drop-shadow-cyan-glow")}
                    onClick={() => onViewChange("week")}
                >
                    {t('week')}
                </Button>
                <Button
                    variant="ghost"
                    size="sm"
                    className={cn("h-7 px-2 text-xs", view === "day" && "text-cyan-400 drop-shadow-cyan-glow")}
                    onClick={() => onViewChange("day")}
                >
                    {t('day')}
                </Button>
            </div>
        </div>

        {/* Right Section */}
        <div className="flex flex-1 justify-end">
            <Button
                onClick={onAddTransaction}
                size="sm"
                className="shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold"
            >
                <Plus className="h-4 w-4 sm:mr-2 drop-shadow-cyan-glow" />
                <span className="hidden sm:inline drop-shadow-cyan-glow">{t('addTransaction')}</span>
            </Button>
        </div>
    </header>
  );
}
