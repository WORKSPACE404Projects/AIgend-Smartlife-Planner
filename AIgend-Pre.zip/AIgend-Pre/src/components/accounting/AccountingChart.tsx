
"use client";

import * as React from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Rectangle,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isWithinInterval,
  startOfDay,
  startOfMonth,
  startOfWeek,
} from 'date-fns';

import type { AccountingTransaction } from '@/lib/types';
import { useLocale, useTranslations } from 'next-intl';
import { getDateFnsLocale } from '@/lib/i18n';

interface AccountingChartProps {
  view: 'month' | 'week' | 'day';
  currentDate: Date;
  transactions: AccountingTransaction[];
  onBarClick: (transaction: AccountingTransaction) => void;
}

export function AccountingChart({ view, currentDate, transactions, onBarClick }: AccountingChartProps) {
  const t = useTranslations('Accounting');
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);

  const chartData = React.useMemo(() => {
    let interval;
    let dateFormat;

    if (view === 'day') {
      interval = { start: startOfDay(currentDate), end: startOfDay(currentDate) };
      dateFormat = 'eeee';
    } else if (view === 'week') {
      interval = { start: startOfWeek(currentDate, { locale: dateFnsLocale }), end: endOfWeek(currentDate, { locale: dateFnsLocale }) };
      dateFormat = 'E';
    } else { // month
      interval = { start: startOfMonth(currentDate), end: endOfMonth(currentDate) };
      dateFormat = 'd';
    }

    const daysInInterval = eachDayOfInterval(interval);

    return daysInInterval.map(day => {
      const dayTransactions = transactions.filter(t => isSameDay(t.date, day));
      
      const income = dayTransactions
        .filter(t => t.type === 'income')
        .reduce((sum, t) => sum + t.amount, 0);
      
      const expense = dayTransactions
        .filter(t => t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);

      return {
        name: format(day, dateFormat, { locale: dateFnsLocale }),
        date: day,
        income,
        expense,
        transactions: dayTransactions,
      };
    });
  }, [view, currentDate, transactions, locale, dateFnsLocale]);

  const handleBarClick = (data: any) => {
    if (data && data.activePayload && data.activePayload[0]) {
      // For simplicity, let's open the first transaction of the day if a bar is clicked
      const dayTransactions = data.activePayload[0].payload.transactions;
      if (dayTransactions.length > 0) {
        // Find the original transaction object
        const firstTransactionId = dayTransactions[0].id;
        const originalTransaction = transactions.find(t => t.id === firstTransactionId);
        if (originalTransaction) {
            onBarClick(originalTransaction);
        }
      }
    }
  };


  return (
    <div className="h-[350px] w-full md:h-[500px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={chartData} onClick={handleBarClick}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
          <YAxis stroke="hsl(var(--muted-foreground))" />
          <Tooltip
            contentStyle={{
                backgroundColor: "hsl(var(--background))",
                borderColor: "hsl(var(--border))",
            }}
            cursor={{ fill: 'hsl(var(--muted))' }}
           />
          <Legend />
          <Bar dataKey="income" fill="hsl(var(--chart-1))" name={t('income')} radius={[4, 4, 0, 0]} />
          <Bar dataKey="expense" fill="hsl(var(--chart-3))" name={t('expense')} radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
