"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useFieldArray, useForm } from "react-hook-form";
import { z } from "zod";
import { useTranslations } from "next-intl";
import { Loader2, Plus, Trash2, Undo2 } from "lucide-react";
import Link from 'next/link';

import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import type { PersonalData } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { Textarea } from "../ui/textarea";
import { Slider } from "../ui/slider";
import { useFinancialData } from "@/contexts/FinancialContext";
import { timezones } from "@/lib/timezones";
import { Checkbox } from "../ui/checkbox";
import { Label } from "@/components/ui/label";

const createProfileFormSchema = (t: (key: any) => string) => z.object({
    firstName: z.string().max(50).optional(),
    totalMonthlyIncome: z.coerce.number().min(0, { message: t('errorNonNegative') }),
    fixedMonthlyExpenses: z.coerce.number().min(0, { message: t('errorNonNegative') }),
    variableMonthlyExpenses: z.coerce.number().min(0, { message: t('errorNonNegative') }),
    totalDebt: z.coerce.number().min(0, { message: t('errorNonNegative') }),
    liquidSavings: z.coerce.number().min(0, { message: t('errorNonNegative') }),
    monthlyInvestment: z.coerce.number().min(0, { message: t('errorNonNegative') }),
    goals: z.array(z.object({
        id: z.string(),
        name: z.string().min(1, { message: t('errorGoalNameRequired') }),
        targetAmount: z.coerce.number().positive({ message: t('errorPositive') }),
        currentAmount: z.coerce.number().min(0, { message: t('errorNonNegative') }),
    })),
    age: z.coerce.number().positive({ message: t('errorPositive') }).optional(),
    weight: z.coerce.number().positive({ message: t('errorPositive') }).optional(),
    height: z.coerce.number().positive({ message: t('errorPositive') }).optional(),
    sex: z.enum(['male', 'female']).optional(),
    activityLevel: z.enum(['sedentary', 'light', 'moderate', 'intense', 'very_intense']).optional(),
    allergies: z.string().optional(),
    nutritionalGoal: z.enum(['weight_maintenance', 'weight_loss', 'muscle_gain']).optional(),
    fitnessGoal: z.enum(['strength_gain', 'endurance', 'flexibility', 'general_fitness']).optional(),
    availableEquipment: z.string().optional(),
    trainingFacilities: z.string().optional(),
    injuries: z.string().optional(),
    dietaryPreferences: z.enum(['omnivore', 'vegetarian', 'vegan', 'gluten_free']).optional(),
    favoriteFoods: z.string().optional(),
    country: z.string().optional(),
    spiceLevel: z.coerce.number().min(0).max(5).optional(),
    foodGroupPreferences: z.object({
        vegetables: z.coerce.number().min(0).max(5),
        fruits: z.coerce.number().min(0).max(5),
        redMeat: z.coerce.number().min(0).max(5),
        poultry: z.coerce.number().min(0).max(5),
        fish: z.coerce.number().min(0).max(5),
        legumes: z.coerce.number().min(0).max(5),
    }).optional(),
    timezone: z.string().optional(),
});

type ProfileFormValues = z.infer<ReturnType<typeof createProfileFormSchema>>;

function useProfileFormSchema() {
    const t = useTranslations("Profile");
    return React.useMemo(() => createProfileFormSchema(t), [t]);
}

interface ProfileFormProps {
    initialData: PersonalData;
}

export function ProfileForm({ initialData }: ProfileFormProps) {
  const t = useTranslations("Profile");
  const { toast } = useToast();
  const { setFinancialData } = useFinancialData();
  const profileFormSchema = useProfileFormSchema();
  const [isSaving, setIsSaving] = React.useState(false);

  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: initialData,
  });
  
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "goals",
  });

  const facilityOptions = React.useMemo(() => [
    { id: 'home_gym', label: t('facilityHome') },
    { id: 'commercial_gym', label: t('facilityCommercial') },
    { id: 'crossfit_box', label: t('facilityCrossfit') },
    { id: 'powerlifting_gym', label: t('facilityPowerlifting') },
    { id: 'calisthenics_park', label: t('facilityCalisthenics') },
    { id: 'street_workout', label: t('facilityStreetWorkout') },
  ], [t]);

  React.useEffect(() => {
    form.reset(initialData);
  }, [initialData, form]);

  const onSubmit = async (data: ProfileFormValues) => {
    setIsSaving(true);
    try {
      const personalData = data as PersonalData;
      await setFinancialData(personalData);
      toast({
        title: t('toastSuccessTitle'),
        description: t('toastSuccessDescription'),
      });
    } catch (error) {
       toast({
        title: t('toastErrorTitle'),
        description: t('toastErrorDescription'),
        variant: "destructive",
      });
    } finally {
        setIsSaving(false);
    }
  };
  
  const addGoal = () => {
    append({
        id: `new-goal-${Date.now()}`,
        name: '',
        targetAmount: 1000,
        currentAmount: 0,
    });
  }
  
  const cardClasses = "rounded-lg border border-white/20 bg-white/5 text-card-foreground shadow-lg backdrop-blur-md dark:border-white/10 dark:bg-black/20";

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)}>
        <Accordion type="multiple" defaultValue={['personal-data']} className="w-full space-y-4">
            
            <AccordionItem value="personal-data" className={cardClasses}>
                <AccordionTrigger className="px-6 py-4 text-lg font-semibold hover:no-underline">
                    {t('personalDataTitle')}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 border-t pt-6">
                    <div className="space-y-6">
                        <FormField control={form.control} name="firstName" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('firstName')}</FormLabel>
                                <Input placeholder={t('firstNamePlaceholder')} {...field} value={field.value ?? ''} />
                                <FormDescription>{t('firstNameDescription')}</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <FormField control={form.control} name="age" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('age')}</FormLabel>
                                    <Input type="number" {...field} value={field.value ?? ''}/>
                                    <FormMessage />
                                </FormItem>
                            )} />
                            <FormField control={form.control} name="weight" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('weight')}</FormLabel>
                                    <Input type="number" {...field} value={field.value ?? ''}/>
                                    <FormMessage />
                                </FormItem>
                            )} />
                            <FormField control={form.control} name="height" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('height')}</FormLabel>
                                    <Input type="number" {...field} value={field.value ?? ''}/>
                                    <FormMessage />
                                </FormItem>
                            )} />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField control={form.control} name="sex" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('sex')}</FormLabel>
                                    <RadioGroup onValueChange={field.onChange} defaultValue={field.value} className="flex gap-4 pt-2">
                                        <FormItem className="flex items-center space-x-2">
                                            <FormControl><RadioGroupItem value="male" /></FormControl>
                                            <FormLabel className="font-normal">{t('sexMale')}</FormLabel>
                                        </FormItem>
                                        <FormItem className="flex items-center space-x-2">
                                            <FormControl><RadioGroupItem value="female" /></FormControl>
                                            <FormLabel className="font-normal">{t('sexFemale')}</FormLabel>
                                        </FormItem>
                                    </RadioGroup>
                                    <FormMessage />
                                </FormItem>
                            )} />
                            <FormField control={form.control} name="activityLevel" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('activityLevel')}</FormLabel>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <FormControl><SelectTrigger><SelectValue placeholder={t('selectPlaceholder')} /></SelectTrigger></FormControl>
                                        <SelectContent>
                                            <SelectItem value="sedentary">{t('activitySedentary')}</SelectItem>
                                            <SelectItem value="light">{t('activityLight')}</SelectItem>
                                            <SelectItem value="moderate">{t('activityModerate')}</SelectItem>
                                            <SelectItem value="intense">{t('activityIntense')}</SelectItem>
                                            <SelectItem value="very_intense">{t('activityVeryIntense')}</SelectItem>
                                        </SelectContent>
                                    </Select>
                                    <FormMessage />
                                </FormItem>
                            )} />
                        </div>
                        <FormField control={form.control} name="timezone" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('timezone')}</FormLabel>
                                <Select onValueChange={field.onChange} value={field.value}>
                                    <FormControl>
                                        <SelectTrigger>
                                            <SelectValue placeholder={t('timezonePlaceholder')} />
                                        </SelectTrigger>
                                    </FormControl>
                                    <SelectContent>
                                        {timezones.map((tz) => (
                                            <SelectItem key={tz.value} value={tz.value}>
                                                {tz.label}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                                <FormDescription>{t('timezoneDescription')}</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                </AccordionContent>
            </AccordionItem>

            <AccordionItem value="tastes" className={cardClasses}>
                <AccordionTrigger className="px-6 py-4 text-lg font-semibold hover:no-underline">
                    {t('tastesTitle')}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 border-t pt-6">
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField control={form.control} name="country" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('country')}</FormLabel>
                                    <Input placeholder={t('countryPlaceholder')} {...field} value={field.value ?? ''}/>
                                    <FormMessage />
                                </FormItem>
                            )} />
                            <FormField control={form.control} name="spiceLevel" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('spiceLevel')} : <span className="font-bold">{field.value ?? 2}</span></FormLabel>
                                    <FormControl>
                                        <Slider defaultValue={[field.value ?? 2]} onValueChange={(value) => field.onChange(value[0])} max={5} step={1} />
                                    </FormControl>
                                    <FormMessage />
                                </FormItem>
                            )} />
                        </div>

                        <div className="space-y-2">
                            <Label>{t('foodGroupPreferences')}</Label>
                            <FormDescription>{t('foodGroupPreferencesDescription')}</FormDescription>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-8">
                            <FormField control={form.control} name="foodGroupPreferences.vegetables" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('vegetables')} : <span className="font-bold">{field.value ?? 4}</span></FormLabel>
                                    <FormControl>
                                        <Slider defaultValue={[field.value ?? 4]} onValueChange={(value) => field.onChange(value[0])} max={5} step={1} />
                                    </FormControl>
                                </FormItem>
                            )} />
                              <FormField control={form.control} name="foodGroupPreferences.fruits" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('fruits')} : <span className="font-bold">{field.value ?? 4}</span></FormLabel>
                                    <FormControl>
                                        <Slider defaultValue={[field.value ?? 4]} onValueChange={(value) => field.onChange(value[0])} max={5} step={1} />
                                    </FormControl>
                                </FormItem>
                            )} />
                              <FormField control={form.control} name="foodGroupPreferences.redMeat" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('redMeat')} : <span className="font-bold">{field.value ?? 3}</span></FormLabel>
                                    <FormControl>
                                        <Slider defaultValue={[field.value ?? 3]} onValueChange={(value) => field.onChange(value[0])} max={5} step={1} />
                                    </FormControl>
                                </FormItem>
                            )} />
                              <FormField control={form.control} name="foodGroupPreferences.poultry" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('poultry')} : <span className="font-bold">{field.value ?? 5}</span></FormLabel>
                                    <FormControl>
                                        <Slider defaultValue={[field.value ?? 5]} onValueChange={(value) => field.onChange(value[0])} max={5} step={1} />
                                    </FormControl>
                                </FormItem>
                            )} />
                                <FormField control={form.control} name="foodGroupPreferences.fish" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('fish')} : <span className="font-bold">{field.value ?? 3}</span></FormLabel>
                                    <FormControl>
                                        <Slider defaultValue={[field.value ?? 3]} onValueChange={(value) => field.onChange(value[0])} max={5} step={1} />
                                    </FormControl>
                                </FormItem>
                            )} />
                                <FormField control={form.control} name="foodGroupPreferences.legumes" render={({ field }) => (
                                <FormItem>
                                    <FormLabel>{t('legumes')} : <span className="font-bold">{field.value ?? 2}</span></FormLabel>
                                    <FormControl>
                                        <Slider defaultValue={[field.value ?? 2]} onValueChange={(value) => field.onChange(value[0])} max={5} step={1} />
                                    </FormControl>
                                </FormItem>
                            )} />
                        </div>

                        <FormField control={form.control} name="dietaryPreferences" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('dietaryPreferences')}</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl><SelectTrigger><SelectValue placeholder={t('selectPlaceholder')} /></SelectTrigger></FormControl>
                                    <SelectContent>
                                        <SelectItem value="omnivore">{t('dietOmnivore')}</SelectItem>
                                        <SelectItem value="vegetarian">{t('dietVegetarian')}</SelectItem>
                                        <SelectItem value="vegan">{t('dietVegan')}</SelectItem>
                                        <SelectItem value="gluten_free">{t('dietGlutenFree')}</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="allergies" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('allergies')}</FormLabel>
                                <Textarea placeholder={t('allergiesPlaceholder')} {...field} value={field.value ?? ''}/>
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="favoriteFoods" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('customPreferences')}</FormLabel>
                                <Textarea placeholder={t('customPreferencesPlaceholder')} {...field} value={field.value ?? ''}/>
                                <FormDescription>{t('customPreferencesDescription')}</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                </AccordionContent>
            </AccordionItem>
            
             <AccordionItem value="fitness" className={cardClasses}>
                <AccordionTrigger className="px-6 py-4 text-lg font-semibold hover:no-underline">
                    {t('fitnessTitle')}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 border-t pt-6">
                    <div className="space-y-6">
                         <FormField control={form.control} name="fitnessGoal" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('fitnessGoal')}</FormLabel>
                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                    <FormControl><SelectTrigger><SelectValue placeholder={t('selectPlaceholder')} /></SelectTrigger></FormControl>
                                    <SelectContent>
                                        <SelectItem value="general_fitness">{t('goalGeneralFitness')}</SelectItem>
                                        <SelectItem value="strength_gain">{t('goalStrengthGain')}</SelectItem>
                                        <SelectItem value="endurance">{t('goalEndurance')}</SelectItem>
                                        <SelectItem value="flexibility">{t('goalFlexibility')}</SelectItem>
                                    </SelectContent>
                                </Select>
                                <FormMessage />
                            </FormItem>
                        )} />

                        <FormField
                        control={form.control}
                        name="trainingFacilities"
                        render={({ field }) => (
                            <FormItem>
                            <Label>{t('trainingFacilitiesTitle')}</Label>
                            <FormDescription>{t('trainingFacilitiesDescription')}</FormDescription>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pt-2">
                                {facilityOptions.map((item) => (
                                    <FormItem key={item.id} className="flex flex-row items-center space-x-3 space-y-0">
                                        <FormControl>
                                        <Checkbox
                                            checked={field.value?.split(',').includes(item.id)}
                                            onCheckedChange={(checked) => {
                                            const currentValues = field.value ? field.value.split(',').filter(Boolean) : [];
                                            let newValues;
                                            if (checked) {
                                                newValues = [...currentValues, item.id];
                                            } else {
                                                newValues = currentValues.filter((value) => value !== item.id);
                                            }
                                            field.onChange(newValues.join(','));
                                            }}
                                        />
                                        </FormControl>
                                        <Label className="font-normal text-sm">{item.label}</Label>
                                    </FormItem>
                                ))}
                            </div>
                            <FormMessage />
                            </FormItem>
                        )}
                        />

                        <FormField control={form.control} name="availableEquipment" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('availableEquipment')}</FormLabel>
                                <Textarea placeholder={t('availableEquipmentPlaceholder')} {...field} value={field.value ?? ''}/>
                                <FormDescription>{t('availableEquipmentDescription')}</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )} />
                         <FormField control={form.control} name="injuries" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('injuries')}</FormLabel>
                                <Textarea placeholder={t('injuriesPlaceholder')} {...field} value={field.value ?? ''}/>
                                <FormDescription>{t('injuriesDescription')}</FormDescription>
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                </AccordionContent>
             </AccordionItem>

            <AccordionItem value="financials" className={cardClasses}>
                <AccordionTrigger className="px-6 py-4 text-lg font-semibold hover:no-underline">
                     {t('monthlyFlowTitle')}
                </AccordionTrigger>
                 <AccordionContent className="px-6 pb-6 border-t pt-6">
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField control={form.control} name="totalMonthlyIncome" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('totalMonthlyIncome')}</FormLabel>
                                <Input type="number" {...field} />
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="monthlyInvestment" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('monthlyInvestment')}</FormLabel>
                                <Input type="number" {...field} />
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="fixedMonthlyExpenses" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('fixedMonthlyExpenses')}</FormLabel>
                                <Input type="number" {...field} />
                                <FormMessage />
                            </FormItem>
                        )} />
                        <FormField control={form.control} name="variableMonthlyExpenses" render={({ field }) => (
                            <FormItem>
                                <FormLabel>{t('variableMonthlyExpenses')}</FormLabel>
                                <Input type="number" {...field} />
                                <FormMessage />
                            </FormItem>
                        )} />
                    </div>
                 </AccordionContent>
            </AccordionItem>

            <AccordionItem value="goals" className={cardClasses}>
                <AccordionTrigger className="px-6 py-4 text-lg font-semibold hover:no-underline">
                    {t('goalsTitle')}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-6 border-t pt-6">
                     <div className="space-y-4">
                        {fields.map((field, index) => (
                            <div key={field.id} className="flex items-end gap-4 p-4 border rounded-lg">
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 flex-1">
                                    <FormField control={form.control} name={`goals.${index}.name`} render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('goalName')}</FormLabel>
                                            <Input {...field} />
                                            <FormMessage />
                                        </FormItem>
                                    )} />
                                    <FormField control={form.control} name={`goals.${index}.targetAmount`} render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('goalTarget')}</FormLabel>
                                            <Input type="number" {...field} />
                                            <FormMessage />
                                        </FormItem>
                                    )} />
                                    <FormField control={form.control} name={`goals.${index}.currentAmount`} render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>{t('goalCurrent')}</FormLabel>
                                            <Input type="number" {...field} />
                                            <FormMessage />
                                        </FormItem>
                                    )} />
                                </div>
                                <Button type="button" variant="destructive" size="icon" onClick={() => remove(index)}>
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>
                        ))}
                        <Button type="button" variant="outline" onClick={addGoal}>
                            <Plus className="mr-2 h-4 w-4" />
                            {t('addGoalButton')}
                        </Button>
                    </div>
                </AccordionContent>
            </AccordionItem>
        </Accordion>

        <div className="flex justify-end gap-4 mt-8">
            <Link href="/">
                <Button type="button" variant="outline" className="bg-transparent text-cyan-400/80 border-cyan-400/30 hover:bg-cyan-400/10 hover:text-cyan-400">
                    <Undo2 className="mr-2 h-4 w-4" />
                    {t('backButton')}
                </Button>
            </Link>
            <Button type="submit" disabled={isSaving} className="shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold">
                {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                <span className="drop-shadow-cyan-glow">{t('saveButton')}</span>
            </Button>
        </div>
      </form>
    </Form>
  );
}
