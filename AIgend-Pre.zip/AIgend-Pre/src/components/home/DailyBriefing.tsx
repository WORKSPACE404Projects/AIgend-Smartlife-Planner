
'use client';

import * as React from 'react';
import { useLocale, useTranslations } from 'next-intl';
import ReactMarkdown from 'react-markdown';
import { Calendar, Utensils, PiggyBank, Sparkles, AlertCircle, Volume2, Loader2 as AudioLoader, Sun } from 'lucide-react';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Button } from '@/components/ui/button';
import type { CalendarEvent, PersonalData } from '@/lib/types';
import { getDailyBriefing, type DailyBriefingInput, type DailyBriefingOutput } from '@/ai/flows/daily-briefing-flow';
import { convertTextToSpeech } from '@/ai/flows/text-to-speech-flow';
import { isToday, format } from 'date-fns';
import { useAuth } from '@/contexts/AuthContext';

interface DailyBriefingProps {
  personalData: PersonalData;
  events: CalendarEvent[];
}

export function DailyBriefing({ personalData, events }: DailyBriefingProps) {
  const t = useTranslations('DailyBriefing');
  const locale = useLocale();
  const { user } = useAuth();

  const [briefing, setBriefing] = React.useState<DailyBriefingOutput | null>(null);
  const [isLoading, setIsLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);

  const [isAudioLoading, setIsAudioLoading] = React.useState(false);
  const [audioSrc, setAudioSrc] = React.useState<string | null>(null);
  const [audioError, setAudioError] = React.useState<string | null>(null);
  const audioRef = React.useRef<HTMLAudioElement>(null);

  React.useEffect(() => {
    /**
     * Determines the "app day" string for caching. An "app day" starts at 4:00 AM.
     * This uses the user's browser local time.
     * @returns {string} The date string in YYYY-MM-DD format for the current app day.
     */
    const getAppDayString = (): string => {
        const now = new Date();
        const appDayStartDate = new Date(now);
        
        // If it's before 4 AM, the "app day" is considered the previous calendar day.
        if (now.getHours() < 4) {
            appDayStartDate.setDate(appDayStartDate.getDate() - 1);
        }
        
        return format(appDayStartDate, 'yyyy-MM-dd');
    };
      
    const fetchBriefing = async () => {
      if (!user) {
        setIsLoading(false);
        return;
      };

      setIsLoading(true);
      setError(null);
      
      const appDayStr = getAppDayString();
      const cacheKey = `aigend-daily-briefing-${user.uid}-${appDayStr}`;

      // 1. Try to get data from cache first for the current "app day"
      try {
        const cachedData = localStorage.getItem(cacheKey);
        if (cachedData) {
          setBriefing(JSON.parse(cachedData));
          setIsLoading(false);
          return;
        }
      } catch (e) {
        console.warn("Could not read daily briefing from cache", e);
      }

      // 2. If not in cache, this is the first view of the day. Fetch from AI.
      try {
        const todaysEvents = events.filter(e => isToday(e.start));
        const flowInput: DailyBriefingInput = {
          personalData,
          events: todaysEvents.map(e => ({ 
            id: e.id,
            title: e.title,
            start: e.start.toISOString(),
            end: e.end.toISOString(),
            allDay: e.allDay,
            description: e.description,
            category: e.category || 'general',
          })),
          currentDate: new Date().toISOString(),
          locale,
        };
        const result = await getDailyBriefing(flowInput);
        setBriefing(result);
        
        // 3. Save to cache on success
        try {
          localStorage.setItem(cacheKey, JSON.stringify(result));
        } catch (e) {
          console.warn("Could not save daily briefing to cache", e);
        }

      } catch (err) {
        console.error("Error fetching daily briefing:", err);
        setError(t('errorMessage'));
      } finally {
        setIsLoading(false);
      }
    };

    // We only want to run this logic when the component is first mounted
    // or when the user changes. The tab itself being opened/closed
    // doesn't re-trigger this, which is correct behavior for caching.
    fetchBriefing();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, locale]); // Note: We don't include personalData/events here to avoid re-fetching on every profile change within the same day. The fetch uses the data available at the time of the first fetch of the day.

  React.useEffect(() => {
    if (audioSrc && audioRef.current) {
        audioRef.current.play();
    }
  }, [audioSrc]);

  const handlePlayBriefing = async () => {
    if (!briefing) return;
    setIsAudioLoading(true);
    setAudioError(null);
    setAudioSrc(null);

    const fullBriefingText = [
        briefing.greeting,
        briefing.weatherSummary,
        "Agenda Summary: " + briefing.agendaSummary,
        "Diet Summary: " + briefing.dietSummary,
        "Finance Summary: " + briefing.financeSummary,
        "Today's Suggestion: " + briefing.proactiveSuggestion
    ].filter(Boolean).join('\n\n').replace(/[*#_`~>|]/g, '').replace(/\[(.*?)\]\(.*?\)/g, '$1');

    try {
        const audioDataUri = await convertTextToSpeech(fullBriefingText);
        setAudioSrc(audioDataUri);
    } catch (err) {
        console.error("Error generating audio briefing:", err);
        setAudioError(t('audioError')); 
    } finally {
        setIsAudioLoading(false);
    }
  };

  const FallbackMessage = () => (
    <p className="text-sm text-muted-foreground italic">{t('missingDataMessage')}</p>
  );

  const showSkeletons = isLoading || (!error && !briefing);

  if (error) {
    return (
      <div className="flex justify-center">
        <Alert variant="destructive" className="w-full max-w-3xl">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>{t('errorTitle')}</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="flex justify-center">
      <Card className="w-full max-w-3xl">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="space-y-1.5">
              <CardTitle>
                {showSkeletons ? <Skeleton className="h-8 w-3/4" /> : briefing!.greeting}
              </CardTitle>
              {showSkeletons ? (
                <Skeleton className="h-4 w-1/2" />
              ) : (
                <CardDescription>
                  {t('description')}
                </CardDescription>
              )}
            </div>
            {!showSkeletons && briefing && (
              <Button variant="ghost" size="icon" onClick={handlePlayBriefing} disabled={isAudioLoading} aria-label={t('playBriefing')}>
                {isAudioLoading ? <AudioLoader className="h-5 w-5 animate-spin" /> : <Volume2 className="h-5 w-5" />}
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {audioError && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>{t('errorTitle')}</AlertTitle>
              <AlertDescription>{audioError}</AlertDescription>
            </Alert>
          )}

          <div className="flex items-start gap-4">
            <Sun className="h-5 w-5 mt-1 text-primary shrink-0" />
            <div className="prose prose-sm dark:prose-invert max-w-none">
              {showSkeletons ? (
                <div className="space-y-2"><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-3/4" /></div>
              ) : (
                briefing!.weatherSummary ? <ReactMarkdown>{briefing!.weatherSummary}</ReactMarkdown> : <p className="text-sm text-muted-foreground italic">{t('weatherMissing')}</p>
              )}
            </div>
          </div>
          <Separator />

          <div className="flex items-start gap-4">
            <Calendar className="h-5 w-5 mt-1 text-primary shrink-0" />
            <div className="prose prose-sm dark:prose-invert max-w-none">
              {showSkeletons ? (
                <div className="space-y-2"><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-4/5" /></div>
              ) : (
                briefing!.agendaSummary ? <ReactMarkdown>{briefing!.agendaSummary}</ReactMarkdown> : <FallbackMessage />
              )}
            </div>
          </div>
          <Separator />
          <div className="flex items-start gap-4">
            <Utensils className="h-5 w-5 mt-1 text-primary shrink-0" />
            <div className="prose prose-sm dark:prose-invert max-w-none">
              {showSkeletons ? (
                <div className="space-y-2"><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-4/5" /></div>
              ) : (
                briefing!.dietSummary ? <ReactMarkdown>{briefing!.dietSummary}</ReactMarkdown> : <FallbackMessage />
              )}
            </div>
          </div>
          <Separator />
          <div className="flex items-start gap-4">
            <PiggyBank className="h-5 w-5 mt-1 text-primary shrink-0" />
            <div className="prose prose-sm dark:prose-invert max-w-none">
              {showSkeletons ? (
                <div className="space-y-2"><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-4/5" /></div>
              ) : (
                briefing!.financeSummary ? <ReactMarkdown>{briefing!.financeSummary}</ReactMarkdown> : <FallbackMessage />
              )}
            </div>
          </div>
          <Separator />
          <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-lg">
            <Sparkles className="h-5 w-5 mt-1 text-accent-foreground shrink-0" />
            <div className="prose prose-sm dark:prose-invert max-w-none">
              <h4 className="font-semibold !mt-0">{t('suggestionTitle')}</h4>
              {showSkeletons ? (
                <div className="space-y-2"><Skeleton className="h-4 w-full" /><Skeleton className="h-4 w-4/5" /></div>
              ) : (
                briefing!.proactiveSuggestion ? <ReactMarkdown>{briefing!.proactiveSuggestion}</ReactMarkdown> : <FallbackMessage />
              )}
            </div>
          </div>
        </CardContent>
      </Card>
      {audioSrc && <audio ref={audioRef} src={audioSrc} />}
    </div>
  );
}
