'use client';

import * as React from 'react';
import { Loader2, Bot, User, Send, Mic, MicOff } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";
import ReactMarkdown from 'react-markdown';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import type { CalendarEvent, PersonalData } from "@/lib/types";
import { chatWithPlanningAgent, type PlanningAgentChatInput } from '@/ai/flows/central-assistant-flow';
import useSpeechRecognition from "@/hooks/use-speech-recognition";
import { useCalendar } from '@/contexts/CalendarContext';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

interface AgentChatProps {
    personalData: PersonalData;
    generalEvents: CalendarEvent[];
}

export function AgentChat({ personalData, generalEvents }: AgentChatProps) {
    const tAgent = useTranslations("PlanningAgent");
    const locale = useLocale();
    const { saveEvent, deleteEvent } = useCalendar();

    const [messages, setMessages] = React.useState<Message[]>([]);
    const [input, setInput] = React.useState('');
    const [isAgentLoading, setIsAgentLoading] = React.useState(false);
    const messagesEndRef = React.useRef<HTMLDivElement>(null);
    const {
        text: transcript,
        isListening,
        startListening,
        stopListening,
        hasRecognitionSupport,
    } = useSpeechRecognition(locale);

    React.useEffect(() => {
        if (transcript) {
            setInput(transcript);
        }
    }, [transcript]);

    React.useEffect(() => {
        if (messages.length === 0) {
            setMessages([{ role: 'assistant', content: tAgent('initialMessage') }]);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [tAgent]);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    React.useEffect(scrollToBottom, [messages, isAgentLoading]);

    const handleAgentSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isAgentLoading) return;

        const currentQuery = input;
        const userMessage: Message = { role: 'user', content: currentQuery };
        
        const currentHistory = [...messages];
        setMessages((prev) => [...prev, userMessage]);
        setInput('');
        setIsAgentLoading(true);

        try {
            const timezone = personalData.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone;
            const flowInput: PlanningAgentChatInput = {
                userName: personalData.firstName,
                query: currentQuery,
                history: currentHistory,
                events: generalEvents.map(e => ({ 
                    id: e.id,
                    title: e.title,
                    start: e.start.toISOString(),
                    end: e.end.toISOString(),
                    allDay: e.allDay,
                    description: e.description,
                    category: 'general',
                })),
                currentDate: new Date().toISOString(),
                timezone,
                locale,
            };

            const result = await chatWithPlanningAgent(flowInput);
            
            const assistantMessage: Message = { role: 'assistant', content: result.response };
            setMessages((prev) => [...prev, assistantMessage]);

            if (result.action) {
                if (result.action.type === 'save_event') {
                    await saveEvent({
                        ...result.action.payload,
                        start: new Date(result.action.payload.start),
                        end: new Date(result.action.payload.end),
                    });
                } else if (result.action.type === 'delete_event') {
                    await deleteEvent(result.action.payload.eventId);
                }
            }
            
        } catch (error) {
            const errorMessage: Message = { role: 'assistant', content: tAgent('errorMessage') };
            setMessages((prev) => [...prev, errorMessage]);
            console.error("Error calling planning agent flow:", error);
        } finally {
            setIsAgentLoading(false);
        }
    };

    return (
        <Card className="w-full h-full flex flex-col relative border-none shadow-none">
            <CardHeader>
                <CardTitle>{tAgent('title')}</CardTitle>
                <CardDescription>{tAgent('description')}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col overflow-hidden">
                <ScrollArea className="h-full pr-4">
                    <div className="space-y-4">
                        {messages.map((message, index) => (
                            <div key={index} className={cn('flex items-start gap-3', message.role === 'user' ? 'justify-end' : 'justify-start')}>
                                {message.role === 'assistant' && (<Avatar className="h-8 w-8 shadow-cyan-glow"><AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback></Avatar>)}
                                <div className={cn('max-w-xl rounded-lg p-3 text-sm prose prose-sm dark:prose-invert prose-p:my-2 prose-headings:my-3', message.role === 'user' ? 'bg-primary/30 text-primary-foreground border border-primary/50 backdrop-blur-sm' : 'border border-border/20 bg-card/50 backdrop-blur-sm')}>
                                    <ReactMarkdown>{message.content}</ReactMarkdown>
                                </div>
                                {message.role === 'user' && (<Avatar className="h-8 w-8"><AvatarFallback><User /></AvatarFallback></Avatar>)}
                            </div>
                        ))}
                        {isAgentLoading && (
                        <div className="flex items-start gap-3 justify-start">
                            <Avatar className="h-8 w-8 shadow-cyan-glow"><AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback></Avatar>
                            <div className="rounded-lg p-3 flex items-center space-x-2 border border-border/20 bg-card/50 backdrop-blur-sm">
                                <Loader2 className="h-4 w-4 animate-spin" />
                                <span className="text-sm text-muted-foreground">{tAgent('loading')}</span>
                            </div>
                        </div>
                        )}

                        {messages.length === 1 && !isAgentLoading && hasRecognitionSupport && (
                            <div className="flex flex-col items-center justify-center pt-16 gap-4 text-center">
                                <Button
                                    type="button"
                                    size="icon"
                                    className="h-20 w-20 rounded-full bg-primary/10 text-primary"
                                    onClick={startListening}
                                    disabled={isListening}
                                    aria-label={tAgent('startVoiceInput')}
                                >
                                    {isListening ? (
                                        <Loader2 className="h-10 w-10 animate-spin" />
                                    ) : (
                                        <Mic className="h-10 w-10" />
                                    )}
                                </Button>
                                <p className="text-sm text-muted-foreground">
                                    {isListening ? tAgent('listeningPrompt') : tAgent('tapToSpeakPrompt')}
                                </p>
                            </div>
                        )}

                        <div ref={messagesEndRef} />
                    </div>
                </ScrollArea>
            </CardContent>
            <CardFooter>
                <form onSubmit={handleAgentSubmit} className="flex w-full items-center space-x-2">
                <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder={isListening ? tAgent('inputPlaceholderListening') : tAgent('inputPlaceholder')}
                    disabled={isAgentLoading}
                    className="bg-transparent"
                />
                {hasRecognitionSupport && (
                    <Button
                    type="button"
                    size="icon"
                    variant={isListening ? "destructive" : "outline"}
                    onClick={isListening ? stopListening : startListening}
                    disabled={isAgentLoading}
                    aria-label={isListening ? "Stop listening" : "Start listening"}
                    >
                    {isListening ? <MicOff /> : <Mic />}
                    </Button>
                )}
                <Button 
                    type="submit" 
                    size="icon"
                    className="shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400"
                    disabled={isAgentLoading || !input.trim()}>
                    <Send className="h-4 w-4 drop-shadow-cyan-glow" />
                </Button>
                </form>
            </CardFooter>
        </Card>
    );
}
