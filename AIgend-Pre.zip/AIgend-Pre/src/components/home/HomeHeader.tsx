
"use client";

import { useTranslations } from "next-intl";

interface HomeHeaderProps {
}

export function HomeHeader() {
  const t = useTranslations("Sidebar");

  return (
    <header className="flex items-center justify-center border-b p-4 h-[15vh] text-center">
      <h1 className="text-2xl font-bold">{t('home')}</h1>
    </header>
  );
}
