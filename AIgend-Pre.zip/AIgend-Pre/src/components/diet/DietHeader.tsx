
"use client";

import { useTranslations } from "next-intl";

interface DietHeaderProps {
}

export function DietHeader() {
  const t = useTranslations("Diet");

  return (
    <header className="flex items-center justify-center border-b p-4 h-[15vh] text-center">
      <h1 className="text-2xl font-bold">{t('title')}</h1>
    </header>
  );
}
