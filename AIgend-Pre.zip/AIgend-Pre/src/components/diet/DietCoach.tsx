"use client";

import * as React from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { Bot, Loader2, Sparkles, CalendarPlus } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import type { PersonalData } from '@/lib/types';
import { getWeeklyMenu, type DietCoachInput, type DietCoachOutput } from '@/ai/flows/diet-coach-flow';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { useCalendar } from '@/contexts/CalendarContext';

interface DietCoachProps {
  personalData: PersonalData;
  calculations: {
    tdee: number;
    bmi: number;
  } | null;
}

export function DietCoach({ personalData, calculations }: DietCoachProps) {
  const t = useTranslations('DietCoach');
  const locale = useLocale();
  const { toast } = useToast();
  const router = useRouter();
  const { saveDietPlanAsEvents } = useCalendar();

  const [isLoading, setIsLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [mealPlan, setMealPlan] = React.useState<DietCoachOutput | null>(null);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = React.useState(false);

  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  React.useEffect(() => {
    if(isLoading || mealPlan) {
        scrollToBottom();
    }
  }, [isLoading, mealPlan]);


  const handleGenerateMenu = async () => {
    if (!calculations) return;
    setIsLoading(true);
    setError(null);
    setMealPlan(null);

    const flowInput: DietCoachInput = {
        ...personalData,
        tdee: calculations.tdee,
        locale: locale,
    };
    
    try {
      const result = await getWeeklyMenu(flowInput);
      setMealPlan(result);
    } catch (err) {
      console.error("Error generating meal plan:", err);
      setError(t('errorMessage'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddToCalendar = async () => {
    if (!mealPlan) return;
    try {
        await saveDietPlanAsEvents(mealPlan.weeklyMenu);
        toast({
            title: t('planAddedSuccess'),
            description: t('planAddedSuccessDescription'),
        });
        router.push('/');
    } catch (err) {
        console.error("Error saving diet plan to calendar:", err);
        toast({
            title: t('planAddedError'),
            variant: 'destructive',
        });
    } finally {
        setIsConfirmDialogOpen(false);
    }
  };


  return (
    <>
    <Card className="max-w-2xl mx-auto flex flex-col h-full min-h-[500px]">
      <CardHeader>
        <CardTitle>{t('title')}</CardTitle>
        <CardDescription>{t('description')}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col overflow-hidden">
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            <div className="flex items-start gap-3 justify-start">
              <Avatar className="h-8 w-8 shadow-cyan-glow">
                <AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback>
              </Avatar>
              <div className="rounded-lg p-3 text-sm border border-border/20 bg-card/50 backdrop-blur-sm">
                <p>{t('initialMessage')}</p>
              </div>
            </div>

            {isLoading && (
              <div className="flex items-start gap-3 justify-start">
                <Avatar className="h-8 w-8 shadow-cyan-glow">
                  <AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback>
                </Avatar>
                <div className="rounded-lg p-3 flex items-center space-x-2 border border-border/20 bg-card/50 backdrop-blur-sm">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm text-muted-foreground">{t('loading')}</span>
                </div>
              </div>
            )}

            {error && (
                 <Alert variant="destructive">
                    <AlertTitle>{t('errorTitle')}</AlertTitle>
                    <AlertDescription>{error}</AlertDescription>
                </Alert>
            )}

            {mealPlan && (
                 <div className="flex items-start gap-3 justify-start">
                    <Avatar className="h-8 w-8 shadow-cyan-glow">
                        <AvatarFallback className="border border-white/10 bg-black/20"><Bot className="text-cyan-400 drop-shadow-cyan-glow" /></AvatarFallback>
                    </Avatar>
                     <div className="rounded-lg p-4 text-sm w-full border border-border/20 bg-card/50 backdrop-blur-sm">
                        <p className="font-semibold mb-2">{t('planTitle')}</p>
                        <p className="italic mb-4">{mealPlan.summary}</p>

                        <Accordion type="single" collapsible className="w-full">
                            {mealPlan.weeklyMenu.map((dailyMenu, index) => (
                                <AccordionItem value={`item-${index}`} key={index}>
                                    <AccordionTrigger>{dailyMenu.day} (~{dailyMenu.totalCalories} kcal)</AccordionTrigger>
                                    <AccordionContent>
                                        <div className="space-y-3">
                                            <div>
                                                <h4 className="font-semibold">{t('breakfast')}</h4>
                                                <p className="font-bold">{dailyMenu.breakfast.name}</p>
                                                <p className="text-xs text-muted-foreground">{dailyMenu.breakfast.description}</p>
                                            </div>
                                             <div>
                                                <h4 className="font-semibold">{t('lunch')}</h4>
                                                <p className="font-bold">{dailyMenu.lunch.name}</p>
                                                <p className="text-xs text-muted-foreground">{dailyMenu.lunch.description}</p>
                                            </div>
                                             <div>
                                                <h4 className="font-semibold">{t('dinner')}</h4>
                                                <p className="font-bold">{dailyMenu.dinner.name}</p>
                                                <p className="text-xs text-muted-foreground">{dailyMenu.dinner.description}</p>
                                            </div>
                                            {dailyMenu.snacks && dailyMenu.snacks.length > 0 && (
                                                <div>
                                                    <h4 className="font-semibold">{t('snacks')}</h4>
                                                    <ul className="list-disc pl-5 space-y-1">
                                                        {dailyMenu.snacks.map((snack, sIndex) => (
                                                            <li key={sIndex}>
                                                                <p className="font-bold">{snack.name}</p>
                                                                <p className="text-xs text-muted-foreground">{snack.description}</p>
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            )}
                                        </div>
                                    </AccordionContent>
                                </AccordionItem>
                            ))}
                        </Accordion>
                     </div>
                </div>
            )}
             <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="flex flex-col sm:flex-row gap-2 pt-6">
        <Button 
            onClick={handleGenerateMenu} 
            disabled={isLoading} 
            className="w-full shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold"
        >
          <Sparkles className="mr-2 h-4 w-4 drop-shadow-cyan-glow" />
          <span className="drop-shadow-cyan-glow">{mealPlan ? t('regenerateButton') : t('generateButton')}</span>
        </Button>
        {mealPlan && (
            <Button onClick={() => setIsConfirmDialogOpen(true)} variant="secondary" className="w-full">
                <CalendarPlus className="mr-2 h-4 w-4" />
                {t('addToCalendarButton')}
            </Button>
        )}
      </CardFooter>
    </Card>
    <AlertDialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <AlertDialogContent>
            <AlertDialogHeader>
                <AlertDialogTitle>{t('addToCalendarTitle')}</AlertDialogTitle>
                <AlertDialogDescription>
                    {t('addToCalendarDescription')}
                </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
                <AlertDialogCancel onClick={() => setIsConfirmDialogOpen(false)}>{t('cancelButton')}</AlertDialogCancel>
                <AlertDialogAction onClick={handleAddToCalendar}>{t('confirmButton')}</AlertDialogAction>
            </AlertDialogFooter>
        </AlertDialogContent>
    </AlertDialog>
    </>
  );
}
