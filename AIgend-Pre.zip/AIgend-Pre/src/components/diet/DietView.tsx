
"use client";

import * as React from "react";
import dynamic from 'next/dynamic';
import { useTranslations } from "next-intl";
import Link from 'next/link';
import { AlertCircle, ChevronLeft, ChevronRight, LineChart, Target, Minimize2 } from "lucide-react";

import { DietHeader } from "@/components/diet/DietHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import type { CalendarEvent, PersonalData } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Tabs, TabsContent } from "../ui/tabs";
import { Skeleton } from "../ui/skeleton";

// --- Dynamic Import for Lazy Loading ---
const DynamicDietCoach = dynamic(() => import('@/components/diet/DietCoach').then(mod => mod.DietCoach), {
  loading: () => (
    <div className="max-w-2xl mx-auto">
      <Skeleton className="h-[500px] w-full" />
    </div>
  ),
  ssr: false
});

const DynamicDietCalendarView = dynamic(() => import('@/components/calendar/DietCalendarView').then(mod => mod.DietCalendarView), {
  loading: () => <Skeleton className="h-full w-full min-h-[200px]" />,
  ssr: false
});


interface DietViewProps {
  personalData: PersonalData;
  dietEvents: CalendarEvent[];
  onEventClick: (event: CalendarEvent) => void;
}

const activityFactors: Record<string, number> = {
  sedentary: 1.2,
  light: 1.375,
  moderate: 1.55,
  intense: 1.725,
  very_intense: 1.9,
};

const getBmiCategory = (bmi: number, t: (key: string) => string) => {
  if (bmi < 18.5) return { category: t('bmiUnderweight'), color: 'text-chart-4' };
  if (bmi < 25) return { category: t('bmiNormal'), color: 'text-chart-1' };
  if (bmi < 30) return { category: t('bmiOverweight'), color: 'text-chart-2' };
  return { category: t('bmiObesity'), color: 'text-chart-3' };
};

export function DietView({ personalData, dietEvents, onEventClick }: DietViewProps) {
  const t = useTranslations("Diet");
  const [expandedView, setExpandedView] = React.useState<string | null>(null);

  // Tab state management
  const tabs = React.useMemo(() => [
    { value: 'help', label: t('title') },
    { value: 'metrics', label: t('metricsTab') },
    { value: 'planner', label: t('plannerTab') },
    { value: 'weekly-view', label: t('weeklyViewTab') },
  ], [t]);

  const [activeTab, setActiveTab] = React.useState(tabs[0].value);
  const activeTabIndex = React.useMemo(() => tabs.findIndex(tab => tab.value === activeTab), [tabs, activeTab]);

  const handlePrevTab = () => {
    const newIndex = activeTabIndex > 0 ? activeTabIndex - 1 : tabs.length - 1;
    setActiveTab(tabs[newIndex].value);
  };

  const handleNextTab = () => {
    const newIndex = activeTabIndex < tabs.length - 1 ? activeTabIndex + 1 : 0;
    setActiveTab(tabs[newIndex].value);
  };

  const calculations = React.useMemo(() => {
    const { age, weight, height, sex, activityLevel } = personalData;

    if (!age || !weight || !height || !sex || !activityLevel) {
      return null;
    }

    // BMR Calculation (Revised Harris-Benedict)
    let bmr;
    if (sex === 'male') {
      bmr = 88.36 + (13.4 * weight) + (4.8 * height) - (5.7 * age);
    } else {
      bmr = 447.6 + (9.2 * weight) + (3.1 * height) - (4.3 * age);
    }

    // TDEE Calculation
    const tdee = bmr * activityFactors[activityLevel];

    // BMI Calculation
    const heightInMeters = height / 100;
    const bmi = weight / (heightInMeters * heightInMeters);

    const bmiInfo = getBmiCategory(bmi, (key) => t(key));

    return {
      tdee: Math.round(tdee),
      bmi: parseFloat(bmi.toFixed(1)),
      bmiCategory: bmiInfo.category,
      bmiColor: bmiInfo.color
    };
  }, [personalData, t]);

  const getExpandedViewTitle = () => {
    if (expandedView === 'metrics') {
      return t('resultsTitle');
    }
    return '';
  };

  const MetricsCardContent = () => (
    <CardContent className="space-y-6">
        <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
            <div className="p-3 bg-primary/10 rounded-full">
                <Target className="h-8 w-8 text-primary"/>
            </div>
            <p className="text-lg">
                {t('tdeeResult', {tdee: calculations!.tdee})}
            </p>
        </div>
        <div className="flex items-center gap-4 p-4 bg-muted rounded-lg">
            <div className="p-3 bg-primary/10 rounded-full">
                <LineChart className="h-8 w-8 text-primary"/>
            </div>
            <div>
                <p className="text-lg">
                    {t('bmiResult', {bmi: calculations!.bmi})}
                </p>
                <p className={cn("text-sm font-semibold", calculations!.bmiColor)}>
                  {t('bmiCategoryLabel')} {calculations!.bmiCategory}
                </p>
            </div>
        </div>
    </CardContent>
  );

  return (
    <div className="flex h-screen flex-col text-foreground">
      <DietHeader />
      <main className="h-[85vh] overflow-auto p-4 md:p-6">
        {!calculations ? (
          <Alert variant="destructive" className="max-w-2xl mx-auto">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>{t('dataNeededTitle')}</AlertTitle>
            <AlertDescription>
                <p className="mb-4">{t('dataNeeded')}</p>
                <Link href="/profile">
                    <Button variant="outline">{t('profile')}</Button>
                </Link>
            </AlertDescription>
          </Alert>
        ) : (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
             <div className="flex items-center justify-center gap-4 px-1">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handlePrevTab}>
                    <ChevronLeft className="h-5 w-5" />
                </Button>

                <div className="flex items-center justify-center gap-4 flex-1">
                    {tabs.map((tab, index) => (
                        <button
                            key={tab.value}
                            onClick={() => setActiveTab(tab.value)}
                            className={cn(
                                "py-1 font-medium transition-colors",
                                activeTabIndex === index
                                    ? "text-foreground text-sm"
                                    : "text-muted-foreground text-2xl leading-none"
                            )}
                        >
                            {activeTabIndex === index ? tab.label : '•'}
                        </button>
                    ))}
                </div>
                
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={handleNextTab}>
                    <ChevronRight className="h-5 w-5" />
                </Button>
            </div>
            
            <TabsContent value="help" className="mt-4">
              <Card className="max-w-2xl mx-auto">
                  <CardHeader>
                      <CardTitle>{t('title')}</CardTitle>
                      <CardDescription>{t('helpDescription')}</CardDescription>
                  </CardHeader>
                  <CardContent className="prose prose-sm dark:prose-invert max-w-none space-y-4">
                      <div>
                          <h4>{t('metricsTab')}</h4>
                          <ul>
                              <li>{t('helpMetrics1')}</li>
                              <li>{t('helpMetrics2')}</li>
                          </ul>
                      </div>
                      <div>
                          <h4>{t('plannerTab')}</h4>
                          <ul>
                              <li>{t('helpPlanner1')}</li>
                              <li>{t('helpPlanner2')}</li>
                              <li>{t('helpPlanner3')}</li>
                          </ul>
                      </div>
                      <div>
                          <h4>{t('weeklyViewTab')}</h4>
                          <ul>
                              <li>{t('helpWeeklyView1')}</li>
                          </ul>
                      </div>
                  </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="metrics" className="space-y-6 mt-4">
              <Card 
                className="max-w-2xl mx-auto cursor-pointer"
                onClick={() => setExpandedView('metrics')}
              >
                <CardHeader>
                  <CardTitle>{t('resultsTitle')}</CardTitle>
                  <CardDescription>{t('resultsDescription')}</CardDescription>
                </CardHeader>
                <MetricsCardContent />
              </Card>
            </TabsContent>
            <TabsContent value="planner" className="mt-4">
              <DynamicDietCoach personalData={personalData} calculations={calculations} />
            </TabsContent>
             <TabsContent value="weekly-view" className="mt-4">
              <DynamicDietCalendarView events={dietEvents} onEventClick={onEventClick} />
            </TabsContent>
          </Tabs>
        )}
      </main>
      
      {expandedView && (
        <div className="fixed inset-0 z-50 bg-black/20 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0">
          <div className="w-full h-full flex flex-col p-4 md:p-6">
            <header className="flex items-center justify-between pb-4 shrink-0">
                <h2 className="text-2xl font-bold">{getExpandedViewTitle()}</h2>
                <Button variant="ghost" size="icon" onClick={() => setExpandedView(null)}>
                    <Minimize2 className="h-6 w-6" />
                    <span className="sr-only">Minimize</span>
                </Button>
            </header>
            <div className="flex-1 overflow-auto flex items-center justify-center">
              {expandedView === 'metrics' && (
                <Card className="max-w-2xl w-full">
                    <CardHeader>
                        <CardTitle>{t('resultsTitle')}</CardTitle>
                        <CardDescription>{t('resultsDescription')}</CardDescription>
                    </CardHeader>
                    <MetricsCardContent />
                </Card>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
