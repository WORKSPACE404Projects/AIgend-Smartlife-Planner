import type { SVGProps } from "react";

export function AIgendLogo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M12 2L2 22h20L12 2z" />
      <path d="M7 16l5-10 5 10" />
      <path d="M4.5 14h15" />
    </svg>
  );
}
