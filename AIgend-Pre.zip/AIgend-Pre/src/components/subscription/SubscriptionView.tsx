'use client';

import * as React from 'react';
import { useTranslations } from 'next-intl';
import { Check, Sparkles, Calendar, Landmark, UtensilsCrossed, Dumbbell, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { Badge } from '../ui/badge';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import { Label } from '../ui/label';

export function SubscriptionView() {
  const t = useTranslations('Subscription');
  const [billingCycle, setBillingCycle] = React.useState('annually');
  const [expandedCard, setExpandedCard] = React.useState<string | null>(null);

  const modules = [
    {
      id: 'organization',
      title: t('organizationModuleTitle'),
      description: t('organizationModuleDescription'),
      price: 1.99,
      icon: Calendar,
      features: [
        t('organizationModuleFeature1'),
        t('organizationModuleFeature2'),
      ],
    },
    {
      id: 'accounting',
      title: t('accountingModuleTitle'),
      description: t('accountingModuleDescription'),
      price: 1.99,
      icon: Landmark,
      features: [
        t('accountingModuleFeature1'),
        t('accountingModuleFeature2'),
      ],
    },
    {
      id: 'diet',
      title: t('dietModuleTitle'),
      description: t('dietModuleDescription'),
      price: 1.99,
      icon: UtensilsCrossed,
      features: [
        t('dietModuleFeature1'),
        t('dietModuleFeature2'),
      ],
    },
    {
      id: 'fitness',
      title: t('fitnessModuleTitle'),
      description: t('fitnessModuleDescription'),
      price: 1.99,
      icon: Dumbbell,
      features: [
        t('fitnessModuleFeature1'),
        t('fitnessModuleFeature2'),
      ],
    },
  ];
  
  const handleToggle = (id: string) => {
    setExpandedCard(prev => (prev === id ? null : id));
  }
  
  const allAccessFeatures = modules.flatMap(m => m.features);

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="text-center">
        <h1 className="text-3xl font-bold tracking-tight">{t('title')}</h1>
        <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">{t('description')}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {modules.map(mod => {
          const isExpanded = expandedCard === mod.id;
          return (
            <Card 
              key={mod.id} 
              onClick={() => handleToggle(mod.id)}
              className={cn("cursor-pointer transition-all duration-300", isExpanded && "ring-2 ring-primary")}
            >
              <CardHeader className="flex flex-row items-center justify-between">
                <div className="flex items-center gap-4">
                  <mod.icon className="h-8 w-8 text-primary" />
                  <CardTitle>{mod.title}</CardTitle>
                </div>
                <div className="flex flex-col items-end">
                    <p className="text-2xl font-bold">${mod.price}</p>
                    <p className="text-sm text-muted-foreground -mt-1">{t('perMonth')}</p>
                </div>
              </CardHeader>
              <div className={cn(
                "overflow-hidden transition-[max-height] duration-500 ease-in-out",
                isExpanded ? "max-h-[500px]" : "max-h-0"
              )}>
                <CardContent className="pt-4 border-t">
                    <p className="text-sm text-muted-foreground mb-4">{mod.description}</p>
                    <ul className="space-y-2 text-sm">
                        {mod.features.map((feature, index) => (
                            <li key={index} className="flex items-start gap-2">
                                <Check className="h-4 w-4 text-chart-1 mt-0.5 shrink-0" />
                                <span>{feature}</span>
                            </li>
                        ))}
                    </ul>
                </CardContent>
                <CardFooter>
                  <Button className="w-full shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold">
                    <span className="drop-shadow-cyan-glow">{t('subscribeButton')}</span>
                  </Button>
                </CardFooter>
              </div>
            </Card>
          )
        })}
      </div>

      <Card 
        onClick={() => handleToggle('all-access')}
        className={cn("cursor-pointer transition-all duration-300", expandedCard === 'all-access' ? "ring-2 ring-primary" : "border-border")}
      >
        <div className="relative p-6">
             <Badge variant="default" className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 px-4 py-1 text-base">
                {t('bestValue')}
            </Badge>
            <div className="flex justify-between items-center">
                <div className="flex items-center gap-4">
                    <Sparkles className="h-8 w-8 text-primary"/>
                    <h2 className="text-2xl font-bold">{t('allAccessPass')}</h2>
                </div>
                {expandedCard === 'all-access' ? <ChevronUp className="h-6 w-6" /> : <ChevronDown className="h-6 w-6" />}
            </div>
        </div>
        
         <div className={cn(
            "overflow-hidden transition-[max-height] duration-500 ease-in-out",
            expandedCard === 'all-access' ? "max-h-[1000px]" : "max-h-0"
          )}>
            <div className="p-6 pt-0">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="md:col-span-2 space-y-4">
                        <p className="text-muted-foreground">{t('allAccessDescription')}</p>
                        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-sm">
                            {allAccessFeatures.map((feature, index) => (
                                <li key={index} className="flex items-start gap-2">
                                    <Check className="h-4 w-4 text-chart-1 mt-0.5 shrink-0" />
                                    <span>{feature}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                    <div className="flex flex-col justify-center p-4 bg-muted/50 rounded-lg">
                        <RadioGroup value={billingCycle} onValueChange={setBillingCycle} className="w-full space-y-2">
                            <Label htmlFor="monthly-pack" className="flex items-center justify-between p-3 border rounded-lg cursor-pointer has-[:checked]:border-primary relative">
                                <Badge variant="secondary" className="absolute -top-2 -right-2">{t('save25')}</Badge>
                                <div>
                                    <span className="font-semibold text-sm">{t('billedMonthly')}</span>
                                    <p className="text-xl font-bold">{t('allAccessMonthlyPrice')}</p>
                                </div>
                                <RadioGroupItem value="monthly" id="monthly-pack" />
                            </Label>
                            <Label htmlFor="annual-pack" className="flex items-center justify-between p-3 border rounded-lg cursor-pointer has-[:checked]:border-primary relative">
                                <Badge variant="destructive" className="absolute -top-2 -right-2">{t('save50')}</Badge>
                                <div>
                                    <span className="font-semibold text-sm">{t('billedAnnually')}</span>
                                    <p className="text-xl font-bold">{t('allAccessAnnualPrice')}</p>
                                </div>
                                <RadioGroupItem value="annually" id="annual-pack" />
                            </Label>
                        </RadioGroup>
                        <Button className="w-full mt-4 shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold">
                          <span className="drop-shadow-cyan-glow">{t('subscribeButton')}</span>
                        </Button>
                    </div>
                </div>
            </div>
        </div>
      </Card>
    </div>
  );
}
