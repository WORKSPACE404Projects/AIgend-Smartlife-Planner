
"use client";

import { format } from "date-fns";
import { ChevronLeft, ChevronRight, Plus } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";

import { Button } from "@/components/ui/button";
import { getDateFnsLocale } from "@/lib/i18n";

interface HeaderProps {
  currentDate: Date;
  onPrev: () => void;
  onNext: () => void;
  onAddEvent: () => void;
}

export function Header({
  currentDate,
  onPrev,
  onNext,
  onAddEvent,
}: HeaderProps) {
  const t = useTranslations("Header");
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);

  const getHeaderText = () => {
    return format(currentDate, "MMMM yyyy", { locale: dateFnsLocale });
  };

  return (
    <header className="flex items-center justify-between border-b p-4 h-[15vh] px-6">
        {/* Left Section (for spacing) */}
        <div className="flex-1"></div>

        {/* Center Section */}
        <div className="flex flex-col items-center justify-center text-center">
            <h1 className="text-2xl font-bold">{t('appTitle')}</h1>
            <div className="flex items-center gap-1 mt-2">
                <Button variant="ghost" size="icon" onClick={onPrev} className="h-8 w-8">
                <ChevronLeft className="h-5 w-5" />
                <span className="sr-only">Previous</span>
                </Button>
                <h2 className="w-32 text-center text-sm font-semibold text-muted-foreground">
                {getHeaderText()}
                </h2>
                <Button variant="ghost" size="icon" onClick={onNext} className="h-8 w-8">
                <ChevronRight className="h-5 w-5" />
                <span className="sr-only">Next</span>
                </Button>
            </div>
        </div>

        {/* Right Section */}
        <div className="flex flex-1 justify-end">
            <Button
                onClick={onAddEvent}
                size="sm"
                className="shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 transition-all text-cyan-400 font-semibold"
            >
                <Plus className="h-4 w-4 sm:mr-2 drop-shadow-cyan-glow" />
                <span className="hidden sm:inline drop-shadow-cyan-glow">{t('addEvent')}</span>
            </Button>
        </div>
    </header>
  );
}
