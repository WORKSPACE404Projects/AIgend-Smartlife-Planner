"use client";

import {
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  isToday,
  startOfMonth,
  startOfWeek,
} from "date-fns";
import { cn } from "@/lib/utils";
import type { CalendarEvent } from "@/lib/types";
import { useLocale, useTranslations } from "next-intl";
import { getDateFnsLocale } from "@/lib/i18n";
import { Calendar, Dumbbell, UtensilsCrossed } from "lucide-react";

interface MonthlyViewProps {
  currentDate: Date;
  events: CalendarEvent[];
  onEventClick: (event: CalendarEvent) => void;
  onCellClick: (date: Date) => void;
}

const EventIcon = ({ category }: { category: 'diet' | 'general' | 'fitness' | undefined }) => {
    switch (category) {
        case 'diet':
            return <UtensilsCrossed className="h-3 w-3 shrink-0" />;
        case 'fitness':
            return <Dumbbell className="h-3 w-3 shrink-0" />;
        case 'general':
        default:
            return <Calendar className="h-3 w-3 shrink-0" />;
    }
};

export function MonthlyView({ currentDate, events, onEventClick, onCellClick }: MonthlyViewProps) {
  const t = useTranslations("MonthlyView");
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);

  const firstDayOfMonth = startOfMonth(currentDate);
  const lastDayOfMonth = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({
    start: startOfWeek(firstDayOfMonth, { locale: dateFnsLocale }),
    end: endOfWeek(lastDayOfMonth, { locale: dateFnsLocale }),
  });

  const daysOfWeek = eachDayOfInterval({
    start: startOfWeek(currentDate, { locale: dateFnsLocale }),
    end: endOfWeek(currentDate, { locale: dateFnsLocale }),
  }).map(day => format(day, 'eee', { locale: dateFnsLocale }));

  const getEventsForDay = (day: Date) => {
    return events
      .filter((event) => isSameDay(event.start, day))
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  };

  return (
    <div className="grid grid-cols-7 grid-rows-[auto_repeat(6,minmax(0,1fr))] h-full bg-black/10 dark:bg-black/20 p-1 gap-1 rounded-lg border border-white/10">
      {/* Weekday Headers */}
      {daysOfWeek.map((day) => (
        <div key={day} className="text-center font-semibold text-xs py-2 text-muted-foreground uppercase tracking-wider">
          {day}
        </div>
      ))}

      {/* Day Cells */}
      {daysInMonth.map((day) => (
        <div
          key={day.toString()}
          onClick={() => onCellClick(day)}
          className={cn(
            "rounded-md p-1.5 flex flex-col transition-colors duration-200 cursor-pointer overflow-hidden backdrop-blur-sm",
            isSameMonth(day, currentDate)
              ? "bg-background/10 hover:bg-background/20"
              : "bg-black/10 text-muted-foreground hover:bg-black/20"
          )}
        >
          <time
            dateTime={format(day, "yyyy-MM-dd")}
            className={cn(
              "self-end h-6 w-6 flex items-center justify-center rounded-full text-xs font-semibold",
              isToday(day) && "bg-cyan-400 text-cyan-950 shadow-cyan-glow"
            )}
          >
            {format(day, "d")}
          </time>
          <div className="flex-1 overflow-y-auto -mx-1 pr-1">
            <div className="space-y-1">
              {getEventsForDay(day).slice(0, 3).map((event) => (
                  <div
                    key={event.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      onEventClick(event);
                    }}
                    style={{ borderColor: event.color || 'hsl(var(--primary))' }}
                    className={cn(
                        "p-1 rounded-sm text-[10px] cursor-pointer truncate border-l-4 bg-primary/10 hover:bg-primary/30 flex items-center gap-1",
                    )}
                  >
                    <EventIcon category={event.category} />
                    <span className="font-semibold text-foreground/90 truncate">{event.title}</span>
                  </div>
              ))}
               {getEventsForDay(day).length > 3 && (
                <div className="text-[10px] text-muted-foreground font-semibold mt-1 px-1">
                  {t('more', {count: getEventsForDay(day).length - 3})}
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
