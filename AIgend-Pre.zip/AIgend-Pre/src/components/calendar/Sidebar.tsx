
'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTranslations } from "next-intl";
import { 
    Calendar, Landmark, HeartPulse, User, LogOut, Cog, Gamepad2, Home, UtensilsCrossed, Gem, Menu 
} from "lucide-react";
import { useAuth } from '@/contexts/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from "@/components/ui/button";
import { useFinancialData } from '@/contexts/FinancialContext';
import { cn } from '@/lib/utils';
import { Skeleton } from '../ui/skeleton';

export function Sidebar() {
  const t = useTranslations("Sidebar");
  const { user, logout, loading: authLoading } = useAuth();
  const { financialData } = useFinancialData();
  const [isOpen, setIsOpen] = React.useState(false);
  const pathname = usePathname();
  const [isClient, setIsClient] = React.useState(false);

  React.useEffect(() => {
    setIsClient(true);
  }, []);

  const handleLogout = async () => {
    await logout();
    setIsOpen(false);
  };

  const handleLinkClick = () => {
    setIsOpen(false);
  };

  const navItems = [
    { href: "/", icon: Home, label: t('home') },
    { href: "/calendar", icon: Calendar, label: t('calendar') },
    { href: "/accounting", icon: Landmark, label: t('accounting') },
    { href: "/diet", icon: UtensilsCrossed, label: t('diet') },
    { href: "/fitness", icon: HeartPulse, label: t('fitness') },
    { href: "/games", icon: Gamepad2, label: t('games') },
    { href: "/profile", icon: User, label: t('profile') },
    { href: "/subscription", icon: Gem, label: t('subscription') },
    { href: "/settings", icon: Cog, label: t('settings') },
  ];

  return (
    <>
      {/* Overlay for when menu is open on mobile */}
      {isOpen && (
        <div
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 z-40 bg-black/60 sm:hidden"
          aria-hidden="true"
        />
      )}

      {/* Main container for sidebar and trigger */}
      <div
        className={cn(
          'fixed top-0 left-0 z-50 flex h-full transition-transform duration-300 ease-in-out',
          isOpen ? 'translate-x-0' : '-translate-x-[300px]'
        )}
      >
        {/* Main sidebar panel */}
        <div
          className="w-[300px] h-full flex flex-col bg-background/80 dark:bg-gray-950/70 backdrop-blur-sm text-foreground shadow-lg border-r-0"
        >
          <div className="flex flex-col p-0 h-full">
            <div className="p-6 pb-4 border-b border-border dark:border-gray-700">
              {authLoading ? (
                <div className="flex items-center gap-4">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
              ) : user ? (
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarImage src={user.photoURL || undefined} alt={t('userAvatarAlt')} />
                    <AvatarFallback className="bg-muted dark:bg-gray-600 dark:text-white">
                      {financialData.firstName ? financialData.firstName.charAt(0).toUpperCase() : <User className="h-5 w-5" />}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-base font-semibold">
                      {financialData.firstName ? t('welcomeUser', { name: financialData.firstName }) : (user.isAnonymous ? t('guestUser') : t('authenticatedUser'))}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {user.isAnonymous ? t('anonymousAccount') : t('googleAccount')}
                    </p>
                  </div>
                </div>
              ) : (
                <>
                  <p className="text-lg font-semibold">{t('menuTitle')}</p>
                  <p className="text-sm text-muted-foreground">{t('menuDescription')}</p>
                </>
              )}
            </div>
            <div className="flex-1 flex flex-col justify-between p-6">
              <nav className="flex-1 space-y-2">
                {navItems.map((item) => {
                  const localePath = `/${pathname.split('/')[1]}${item.href === '/' ? '' : item.href}`;
                  const isActive = isClient && pathname === localePath;
                  return (
                    <Link href={item.href} key={item.href} onClick={handleLinkClick}>
                      <Button
                        variant="ghost"
                        className={cn(
                          "w-full justify-start gap-2 text-base",
                          isActive
                            ? "font-semibold text-primary bg-primary/10"
                            : "font-normal text-muted-foreground"
                        )}
                      >
                        <item.icon className="text-cyan-400 drop-shadow-cyan-glow h-5 w-5 shrink-0" />
                        {item.label}
                      </Button>
                    </Link>
                  );
                })}
              </nav>
               {authLoading ? (
                <Skeleton className="h-10 mt-2 w-full" />
              ) : user && (
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-2 text-base bg-transparent text-cyan-400/80 border-cyan-400/30 hover:bg-cyan-400/10 hover:text-cyan-400"
                  onClick={handleLogout}
                >
                  <LogOut className="text-cyan-400 drop-shadow-cyan-glow h-5 w-5 shrink-0" /> {t('logout')}
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Trigger Tab, positioned to the right of the panel */}
        <div
          onClick={() => setIsOpen(!isOpen)}
          className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-r-lg bg-background/80 dark:bg-gray-950/70 backdrop-blur-sm shadow-lg border-y-0 border-r-0 border-border/0"
          style={{ marginTop: '2vh' }}
          aria-label={t('menuTitle')}
        >
          <Menu className="h-6 w-6 text-cyan-400 drop-shadow-cyan-glow" />
        </div>
      </div>
    </>
  );
}
