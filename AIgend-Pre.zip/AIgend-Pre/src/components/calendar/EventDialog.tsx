"use client";

import * as React from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { format, setHours, setMinutes } from "date-fns";
import { CalendarIcon, Trash2 } from "lucide-react";
import { useLocale, useTranslations } from "next-intl";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import type { CalendarEvent } from "@/lib/types";
import { getDateFnsLocale } from "@/lib/i18n";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useCalendar } from "@/contexts/CalendarContext";

const createEventFormSchema = (t: (key: any) => string) => z.object({
    title: z.string().min(2, { message: t('titleError') }),
    allDay: z.boolean(),
    start: z.date(),
    end: z.date(),
    description: z.string().optional(),
    reminder: z.coerce.number().optional(),
}).refine(data => {
    if (!data.start || !data.end) return true;
    return data.end >= data.start;
}, {
    message: t('endDateError'),
    path: ["end"],
});

type EventFormValues = z.infer<ReturnType<typeof createEventFormSchema>>;

function useEventFormSchema() {
    const t = useTranslations("EventDialog");
    return React.useMemo(() => createEventFormSchema(t), [t]);
}

interface EventDialogProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  event: CalendarEvent | null;
  date: Date | null;
}

export function EventDialog({ isOpen, onOpenChange, event, date }: EventDialogProps) {
  const t = useTranslations("EventDialog");
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);
  const eventFormSchema = useEventFormSchema();
  const { saveEvent, deleteEvent } = useCalendar();

  const form = useForm<EventFormValues>({
    resolver: zodResolver(eventFormSchema),
  });

  const { reset, setValue, watch, getValues } = form;

  React.useEffect(() => {
    if (isOpen) {
      const defaultValues = (() => {
        if (event) {
          return {
            ...event,
            start: new Date(event.start),
            end: new Date(event.end),
          };
        }
        const baseDate = date || new Date();
        return {
          title: "",
          allDay: false,
          start: setHours(setMinutes(baseDate, 0), 9),
          end: setHours(setMinutes(baseDate, 0), 10),
          description: "",
          reminder: undefined,
        };
      })();
      reset(defaultValues);
    }
  }, [isOpen, event, date, reset]);


  const onSubmit = async (data: EventFormValues) => {
    if (event) {
      await saveEvent({ ...data, id: event.id });
    } else {
      await saveEvent(data);
    }
    onOpenChange(false);
  };
  
  const handleDelete = async () => {
    if (event) {
        await deleteEvent(event.id);
        onOpenChange(false);
    }
  }

  const handleTimeChange = (field: 'start' | 'end', time: string) => {
    if (!time) return;
    const [hours, minutes] = time.split(':').map(Number);
    const currentDateValue = getValues(field) || new Date();
    const newDate = new Date(currentDateValue);
    newDate.setHours(hours, minutes, 0, 0);
    setValue(field, newDate, { shouldValidate: true, shouldDirty: true });
  };

  const startTime = watch('start');
  const endTime = watch('end');

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent 
        className="sm:max-w-[480px]"
        onOpenAutoFocus={(e) => e.preventDefault()}
      >
        <ScrollArea className="max-h-[90vh]">
          <div className="p-6">
            <DialogHeader>
              <DialogTitle>{event ? t('editEvent') : t('addEvent')}</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('titleLabel')}</FormLabel>
                      <FormControl>
                        <Input placeholder={t('titlePlaceholder')} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="allDay"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                      <div className="space-y-0.5">
                        <FormLabel>{t('allDayLabel')}</FormLabel>
                        <FormDescription>{t('allDayDescription')}</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="start"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>{t('startLabel')}</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button variant={"outline"} className={cn("pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                {field.value ? format(field.value, 'MMM d, yyyy', {locale: dateFnsLocale}) : <span>{t('datePlaceholder')}</span>}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus locale={dateFnsLocale} />
                          </PopoverContent>
                        </Popover>
                        {!form.watch("allDay") && <Input type="time" value={startTime ? format(startTime, 'HH:mm') : ''} onChange={(e) => handleTimeChange('start', e.target.value)} className="mt-2"/>}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="end"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>{t('endLabel')}</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button variant={"outline"} className={cn("pl-3 text-left font-normal", !field.value && "text-muted-foreground")}>
                                {field.value ? format(field.value, 'MMM d, yyyy', {locale: dateFnsLocale}) : <span>{t('datePlaceholder')}</span>}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar mode="single" selected={field.value} onSelect={field.onChange} locale={dateFnsLocale} />
                          </PopoverContent>
                        </Popover>
                        {!form.watch("allDay") && <Input type="time" value={endTime ? format(endTime, 'HH:mm') : ''} onChange={(e) => handleTimeChange('end', e.target.value)} className="mt-2"/>}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="reminder"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('reminderLabel')}</FormLabel>
                      <Select onValueChange={(value) => field.onChange(value === "none" ? undefined : +value)} defaultValue={field.value?.toString()}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t('reminderPlaceholder')} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">{t('reminderNone')}</SelectItem>
                          <SelectItem value="5">{t('reminder5min')}</SelectItem>
                          <SelectItem value="15">{t('reminder15min')}</SelectItem>
                          <SelectItem value="30">{t('reminder30min')}</SelectItem>
                          <SelectItem value="60">{t('reminder60min')}</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('descriptionLabel')}</FormLabel>
                      <FormControl>
                        <Textarea placeholder={t('descriptionPlaceholder')} className="resize-none" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter className="pt-4">
                  {event && (
                    <Button type="button" variant="destructive" onClick={handleDelete} className="mr-auto">
                      <Trash2 className="mr-2 h-4 w-4" /> {t('deleteButton')}
                    </Button>
                  )}
                  <DialogClose asChild>
                    <Button type="button" variant="outline">{t('cancelButton')}</Button>
                  </DialogClose>
                  <Button type="submit" className="shadow-cyan-glow bg-gradient-to-br from-[#16224f] to-[#05060b] border border-white/10 ring-1 ring-slate-400 text-cyan-400 font-semibold">
                    <span className="drop-shadow-cyan-glow">{t('saveButton')}</span>
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
