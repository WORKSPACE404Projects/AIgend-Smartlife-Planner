"use client";

import {
  eachDayOfInterval,
  endOfWeek,
  format,
  isToday,
  startOfWeek,
  areIntervalsOverlapping,
  differenceInMinutes,
  startOfDay,
  endOfDay
} from "date-fns";
import { cn } from "@/lib/utils";
import type { CalendarEvent } from "@/lib/types";
import { Hours } from "./Hours";
import { useLocale } from "next-intl";
import { getDateFnsLocale } from "@/lib/i18n";
import { Calendar, Dumbbell, UtensilsCrossed } from "lucide-react";

interface WeeklyViewProps {
  currentDate: Date;
  events: CalendarEvent[];
  onEventClick: (event: CalendarEvent) => void;
  onCellClick: (date: Date) => void;
}

export function WeeklyView({ currentDate, events, onEventClick, onCellClick }: WeeklyViewProps) {
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);

  const weekStart = startOfWeek(currentDate, { locale: dateFnsLocale });
  const weekEnd = endOfWeek(currentDate, { locale: dateFnsLocale });
  const daysInWeek = eachDayOfInterval({ start: weekStart, end: weekEnd });

  const getEventsForDay = (day: Date) => {
    return events
      .filter(event => areIntervalsOverlapping({ start: event.start, end: event.end }, { start: startOfDay(day), end: endOfDay(day) }))
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  };

  return (
    <div className="h-full overflow-auto bg-black/10 dark:bg-black/20 p-1 rounded-lg border border-white/10">
      <div className="flex min-w-[700px]">
        <Hours />
        <div className="flex-1 grid grid-cols-7 gap-1">
          {daysInWeek.map((day, dayIdx) => (
            <div key={day.toString()} className="flex flex-col bg-background/10 rounded-md overflow-hidden">
              <div className="text-center py-2 bg-transparent">
                <p className="text-xs text-muted-foreground uppercase">{format(day, "E", { locale: dateFnsLocale })}</p>
                <p className={cn(
                    "text-2xl font-bold h-8 w-8 mx-auto flex items-center justify-center rounded-full", 
                    isToday(day) && "bg-cyan-400 text-cyan-950 shadow-cyan-glow"
                  )}>
                  {format(day, "d")}
                </p>
              </div>
              <div className="relative flex-1">
                {/* Hour lines */}
                <div className="absolute inset-0">
                    {[...Array(24)].map((_, i) => (
                      <div
                        key={i}
                        className="h-[60px] border-t border-white/10"
                        onClick={() => onCellClick(new Date(day.setHours(i, 0, 0, 0)))}
                      ></div>
                    ))}
                </div>
                {/* Events */}
                <div className="relative">
                  {getEventsForDay(day).map((event) => {
                    const top = (differenceInMinutes(event.start, startOfDay(event.start)) / 60) * 60;
                    const height = Math.max(30, differenceInMinutes(event.end, event.start));
                    return (
                      <div
                        key={event.id}
                        onClick={() => onEventClick(event)}
                        className={cn(
                          "absolute left-2 right-2 p-1.5 rounded-lg text-primary-foreground z-10 cursor-pointer shadow-lg backdrop-blur-sm border border-black/10 flex items-start gap-1.5",
                           !event.color && "bg-primary/50"
                        )}
                        style={{ top: `${top}px`, height: `${height}px`, minHeight: '30px', backgroundColor: event.color ? `${event.color}80` : undefined }}
                      >
                        {event.category === 'diet' && <UtensilsCrossed className="h-3.5 w-3.5 mt-0.5 shrink-0" />}
                        {event.category === 'fitness' && <Dumbbell className="h-3.5 w-3.5 mt-0.5 shrink-0" />}
                        {(!event.category || event.category === 'general') && <Calendar className="h-3.5 w-3.5 mt-0.5 shrink-0" />}
                        <div className="flex-1 overflow-hidden">
                          <p className="font-bold text-xs truncate">{event.title}</p>
                          <p className="text-[10px] opacity-80 truncate">{format(event.start, 'HH:mm', { locale: dateFnsLocale })} - {format(event.end, 'HH:mm', { locale: dateFnsLocale })}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
