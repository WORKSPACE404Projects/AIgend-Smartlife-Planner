"use client";

import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useLocale } from "next-intl";
import { getDateFnsLocale } from "@/lib/i18n";

export function Hours() {
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);
  return (
    <div className="w-16 text-right pr-2 shrink-0">
      {/* This empty div aligns the hour labels with the day columns */}
      <div className="h-[80px]" />
      {[...Array(24)].map((_, i) => (
        <div key={i} className="h-[60px] relative">
          <span
            className={cn(
              "text-xs text-muted-foreground absolute right-2",
               i === 0 ? "top-[-8px]" : "-top-2"
            )}
          >
            {format(new Date(2022, 0, 1, i, 0), "HH:00", {
              locale: dateFnsLocale,
            })}
          </span>
        </div>
      ))}
    </div>
  );
}
