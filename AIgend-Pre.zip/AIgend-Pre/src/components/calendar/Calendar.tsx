"use client";

import type { CalendarEvent } from "@/lib/types";
import { MonthlyView } from "./MonthlyView";
import { WeeklyView } from "./WeeklyView";
import { DailyView } from "./DailyView";

interface CalendarProps {
  view: "month" | "week" | "day";
  currentDate: Date;
  events: CalendarEvent[];
  onEventClick: (event: CalendarEvent) => void;
  onCellClick: (date: Date) => void;
}

export function Calendar({ view, currentDate, events, onEventClick, onCellClick }: CalendarProps) {
  return (
    <div className="flex-1 h-full">
      {view === "month" && (
        <MonthlyView
          currentDate={currentDate}
          events={events}
          onEventClick={onEventClick}
          onCellClick={onCellClick}
        />
      )}
      {view === "week" && (
        <WeeklyView
          currentDate={currentDate}
          events={events}
          onEventClick={onEventClick}
          onCellClick={onCellClick}
        />
      )}
      {view === "day" && (
        <DailyView
          currentDate={currentDate}
          events={events}
          onEventClick={onEventClick}
          onCellClick={onCellClick}
        />
      )}
    </div>
  );
}
