
"use client";

import { format, isToday, differenceInMinutes, startOfDay, areIntervalsOverlapping, endOfDay } from "date-fns";
import { cn } from "@/lib/utils";
import type { CalendarEvent } from "@/lib/types";
import { Hours } from "./Hours";
import { useLocale } from "next-intl";
import { getDateFnsLocale } from "@/lib/i18n";
import { Calendar, Dumbbell, UtensilsCrossed } from "lucide-react";

interface DailyViewProps {
  currentDate: Date;
  events: CalendarEvent[];
  onEventClick: (event: CalendarEvent) => void;
  onCellClick: (date: Date) => void;
}

export function DailyView({ currentDate, events, onEventClick, onCellClick }: DailyViewProps) {
  const locale = useLocale();
  const dateFnsLocale = getDateFnsLocale(locale);

  const getEventsForDay = (day: Date) => {
    return events
      .filter((event) =>
        areIntervalsOverlapping(
          { start: event.start, end: event.end },
          { start: startOfDay(day), end: endOfDay(day) }
        )
      )
      .sort((a, b) => a.start.getTime() - b.start.getTime());
  };

  return (
    <div className={cn("h-full rounded-lg border border-white/20 bg-white/5 text-card-foreground shadow-lg backdrop-blur-md dark:border-white/10 dark:bg-black/20")}>
      <div className="h-full overflow-y-auto">
        <div className="flex">
          <Hours />
          <div className="flex-1 bg-transparent rounded-md">
            <div className="text-center py-2 bg-transparent sticky top-0 z-20 backdrop-blur-sm border-b border-white/10">
              <p className="text-xs text-muted-foreground uppercase">{format(currentDate, "eeee", { locale: dateFnsLocale })}</p>
              <p className={cn(
                  "text-2xl font-bold h-8 w-8 mx-auto flex items-center justify-center rounded-full", 
                  isToday(currentDate) && "bg-cyan-400 text-cyan-950 shadow-cyan-glow"
                )}>
                {format(currentDate, "d")}
              </p>
            </div>
            <div className="relative">
               {/* Hour lines */}
              <div className="absolute inset-0">
                  {[...Array(24)].map((_, i) => (
                    <div
                      key={i}
                      className="h-[60px] border-t border-white/10"
                      onClick={() => onCellClick(new Date(currentDate.setHours(i, 0, 0, 0)))}
                    ></div>
                  ))}
              </div>
               {/* Events */}
              <div className="relative">
                {getEventsForDay(currentDate).map((event) => {
                  const top = differenceInMinutes(event.start, startOfDay(event.start));
                  const height = Math.max(30, differenceInMinutes(event.end, event.start));
                  return (
                    <div
                      key={event.id}
                      onClick={() => onEventClick(event)}
                      className={cn(
                        "absolute left-4 right-4 p-2 rounded-lg text-primary-foreground z-10 cursor-pointer shadow-lg backdrop-blur-sm border border-black/10 flex items-start gap-2",
                        !event.color && 'bg-primary/50'
                      )}
                      style={{ 
                          top: `${top}px`, 
                          height: `${height}px`, 
                          minHeight: '30px',
                          backgroundColor: event.color ? `${event.color}80` : undefined
                      }}
                    >
                      {event.category === 'diet' && <UtensilsCrossed className="h-4 w-4 mt-0.5 shrink-0" />}
                      {event.category === 'fitness' && <Dumbbell className="h-4 w-4 mt-0.5 shrink-0" />}
                      {(!event.category || event.category === 'general') && <Calendar className="h-4 w-4 mt-0.5 shrink-0" />}
                      <div className="flex-1 overflow-hidden">
                        <p className="font-bold text-sm truncate">{event.title}</p>
                        <p className="text-xs truncate">{format(event.start, 'HH:mm', {locale: dateFnsLocale})} - {format(event.end, 'HH:mm', {locale: dateFnsLocale})}</p>
                        {event.description && <p className="text-xs opacity-80 mt-1 truncate">{event.description}</p>}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
