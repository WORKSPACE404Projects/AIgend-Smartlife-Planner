"use client";

import * as React from 'react';
import { useTranslations } from 'next-intl';
import { Button } from '@/components/ui/button';
import { X, Circle, RotateCcw } from 'lucide-react';
import { CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const Square = ({ value, onSquareClick }: { value: 'X' | 'O' | null; onSquareClick: () => void }) => {
  return (
    <Button
      variant="outline"
      className="flex h-20 w-20 items-center justify-center rounded-lg border-2 text-4xl font-bold md:h-24 md:w-24"
      onClick={onSquareClick}
    >
      {value === 'X' && <X className="h-10 w-10 text-chart-3" />}
      {value === 'O' && <Circle className="h-10 w-10 text-chart-4" />}
    </Button>
  );
};

const calculateWinner = (squares: Array<'X' | 'O' | null>) => {
  const lines = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  for (let i = 0; i < lines.length; i++) {
    const [a, b, c] = lines[i];
    if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
      return squares[a];
    }
  }
  return null;
};

export function TicTacToe() {
  const t = useTranslations('Games');
  const [squares, setSquares] = React.useState(Array(9).fill(null));
  const [xIsNext, setXIsNext] = React.useState(true);

  const winner = calculateWinner(squares);
  const isDraw = !winner && squares.every(Boolean);

  let status;
  if (winner) {
    status = `${t('winner')} ${winner}`;
  } else if (isDraw) {
    status = t('draw');
  } else {
    status = `${t('nextPlayer')}: ${xIsNext ? 'X' : 'O'}`;
  }

  const handleClick = (i: number) => {
    if (squares[i] || winner) {
      return;
    }
    const nextSquares = squares.slice();
    nextSquares[i] = xIsNext ? 'X' : 'O';
    setSquares(nextSquares);
    setXIsNext(!xIsNext);
  };

  const handleRestart = () => {
    setSquares(Array(9).fill(null));
    setXIsNext(true);
  };

  return (
    <div className="flex flex-col items-center space-y-4">
        <CardHeader className="text-center p-0 mb-2">
            <CardTitle>{t('ticTacToeTitle')}</CardTitle>
            <CardDescription>{t('ticTacToeDescription')}</CardDescription>
        </CardHeader>
        <div className="text-lg font-semibold h-6">{status}</div>
        <div className="grid grid-cols-3 gap-2">
        {squares.map((_, i) => (
            <Square key={i} value={squares[i]} onSquareClick={() => handleClick(i)} />
        ))}
        </div>
        <Button onClick={handleRestart} variant="secondary">
            <RotateCcw className="mr-2 h-4 w-4" />
            {t('restartGame')}
        </Button>
    </div>
  );
}
