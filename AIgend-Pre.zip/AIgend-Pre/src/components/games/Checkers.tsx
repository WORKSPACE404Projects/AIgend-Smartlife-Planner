
'use client';

import * as React from 'react';
import { useTranslations } from 'next-intl';
import { Crown, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { CheckersGame, type Player, type Position } from '@/lib/checkers-logic';

export function Checkers() {
  const t = useTranslations('Checkers');
  const gameRef = React.useRef(new CheckersGame());
  const [gameState, setGameState] = React.useState(gameRef.current.getState());

  const handleSquareClick = (row: number, col: number) => {
    const piece = gameState.board[row][col];
    if (gameState.winner) return;

    if (piece && piece.player === gameState.currentPlayer) {
      gameRef.current.selectPiece({ row, col });
    } else if (gameState.selectedPiece) {
      gameRef.current.movePiece({ row, col });
    }
    setGameState(gameRef.current.getState());
  };

  const handleRestart = () => {
    gameRef.current.reset();
    setGameState(gameRef.current.getState());
  };

  const getStatusMessage = () => {
    if (gameState.winner) {
      return gameState.winner === 1 ? t('player1Wins') : t('player2Wins');
    }
    return gameState.currentPlayer === 1 ? t('player1Turn') : t('player2Turn');
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="text-lg font-semibold h-6">{getStatusMessage()}</div>
      <div className="grid grid-cols-8 border bg-card-foreground shadow-lg aspect-square">
        {gameState.board.map((row, rowIndex) =>
          row.map((piece, colIndex) => {
            const isLight = (rowIndex + colIndex) % 2 === 0;
            const isSelected =
              gameState.selectedPiece?.row === rowIndex &&
              gameState.selectedPiece?.col === colIndex;
            const isValidMove = gameState.validMoves.some(
              (m) => m.row === rowIndex && m.col === colIndex
            );

            return (
              <div
                key={`${rowIndex}-${colIndex}`}
                onClick={() => handleSquareClick(rowIndex, colIndex)}
                className={cn(
                  'w-full h-full flex items-center justify-center relative aspect-square',
                  isLight ? 'bg-secondary' : 'bg-muted-foreground',
                  gameState.winner ? 'cursor-not-allowed' : 'cursor-pointer'
                )}
              >
                {piece && (
                  <div
                    className={cn(
                      'w-[75%] h-[75%] rounded-full flex items-center justify-center shadow-md transition-all duration-150',
                      piece.player === 1 ? 'bg-white text-black' : 'bg-black text-white',
                      isSelected && 'ring-4 ring-green-500'
                    )}
                  >
                    {piece.type === 'king' && <Crown className="w-1/2 h-1/2" />}
                  </div>
                )}
                {isValidMove && (
                  <div className="w-1/3 h-1/3 rounded-full bg-green-500/50"></div>
                )}
              </div>
            );
          })
        )}
      </div>
      <Button onClick={handleRestart} variant="secondary">
        <RotateCcw className="mr-2 h-4 w-4" />
        {t('restartGame')}
      </Button>
    </div>
  );
}
