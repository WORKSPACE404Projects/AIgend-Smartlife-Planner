
'use client';

import * as React from 'react';
import { useTranslations } from 'next-intl';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { generateSudoku, solveSudoku } from '@/lib/sudoku-logic';
import { Loader2, RotateCcw } from 'lucide-react';

const emptyGrid = Array(9).fill(Array(9).fill(0));

export function Sudoku() {
  const t = useTranslations('Sudoku');
  const [grid, setGrid] = React.useState<number[][]>(emptyGrid);
  const [initialGrid, setInitialGrid] = React.useState<number[][]>(emptyGrid);
  const [selectedCell, setSelectedCell] = React.useState<{ row: number; col: number } | null>(null);
  const [isGenerating, setIsGenerating] = React.useState(true);

  const startNewGame = React.useCallback((difficulty: 'easy' | 'medium' | 'hard' = 'medium') => {
    setIsGenerating(true);
    // Use timeout to allow loader to render before blocking thread
    setTimeout(() => {
        const newGrid = generateSudoku(difficulty);
        setGrid(newGrid);
        setInitialGrid(JSON.parse(JSON.stringify(newGrid)));
        setSelectedCell(null);
        setIsGenerating(false);
    }, 50);
  }, []);

  React.useEffect(() => {
    startNewGame();
  }, [startNewGame]);

  const handleCellClick = (row: number, col: number) => {
    if (initialGrid[row][col] === 0) {
      setSelectedCell({ row, col });
    }
  };

  const handleNumberInput = (num: number) => {
    if (selectedCell) {
      const newGrid = grid.map((row) => [...row]);
      newGrid[selectedCell.row][selectedCell.col] = num;
      setGrid(newGrid);
    }
  };
  
  const handleErase = () => {
    if (selectedCell) {
        const newGrid = grid.map(row => [...row]);
        newGrid[selectedCell.row][selectedCell.col] = 0;
        setGrid(newGrid);
    }
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>{t('title')}</CardTitle>
        <CardDescription>{t('description')}</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col items-center space-y-4">
        {isGenerating ? (
            <div className="flex flex-col items-center justify-center h-80 w-full">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="mt-2 text-muted-foreground">{t('generating')}</p>
            </div>
        ) : (
             <div className="grid grid-cols-9 gap-0.5 bg-gray-400 p-1 rounded-md shadow-lg">
                {grid.map((row, rowIndex) =>
                    row.map((cell, colIndex) => {
                    const isInitial = initialGrid[rowIndex][colIndex] !== 0;
                    const isSelected = selectedCell?.row === rowIndex && selectedCell?.col === colIndex;
                    const isSameArea = selectedCell && 
                        (Math.floor(selectedCell.row / 3) === Math.floor(rowIndex / 3) ||
                         Math.floor(selectedCell.col / 3) === Math.floor(colIndex / 3));

                    return (
                        <div
                        key={`${rowIndex}-${colIndex}`}
                        onClick={() => handleCellClick(rowIndex, colIndex)}
                        className={cn(
                            'w-9 h-9 md:w-10 md:h-10 flex items-center justify-center text-lg md:text-xl font-bold cursor-pointer transition-colors',
                            'bg-background',
                            !isInitial && 'text-primary',
                            isInitial && 'text-foreground font-extrabold',
                            isSelected && 'bg-primary/20 ring-2 ring-primary z-10',
                            !isSelected && isSameArea && 'bg-muted/50',
                            (rowIndex % 3 === 2 && rowIndex !== 8) && 'border-b-2 border-gray-400',
                            (colIndex % 3 === 2 && colIndex !== 8) && 'border-r-2 border-gray-400'
                        )}
                        >
                        {cell !== 0 ? cell : ''}
                        </div>
                    );
                    })
                )}
            </div>
        )}

        <div className="grid grid-cols-5 gap-2 w-full">
            {Array.from({ length: 9 }, (_, i) => i + 1).map((num) => (
                <Button key={num} variant="outline" onClick={() => handleNumberInput(num)}>
                    {num}
                </Button>
            ))}
            <Button variant="destructive" onClick={handleErase}>
                {t('erase')}
            </Button>
        </div>
        
        <div className="flex gap-2 pt-4">
            <Button onClick={() => startNewGame('easy')}>{t('newGameEasy')}</Button>
            <Button onClick={() => startNewGame('medium')} variant="secondary">{t('newGameMedium')}</Button>
            <Button onClick={() => startNewGame('hard')} variant="destructive">{t('newGameHard')}</Button>
        </div>
      </CardContent>
    </Card>
  );
}

