
'use client';

import { ThemeProvider as NextThemesProvider } from 'next-themes';
import { type ThemeProviderProps } from 'next-themes/dist/types';
import { AuthProvider } from '@/contexts/AuthContext';
import { FinancialProvider } from '@/contexts/FinancialContext';
import { CalendarProvider } from '@/contexts/CalendarContext';
import { AccountingProvider } from '@/contexts/AccountingContext';
import { ExerciseProvider } from '@/contexts/ExerciseContext';

export function Providers({ children, ...props }: ThemeProviderProps) {
  return (
    <NextThemesProvider {...props}>
      <AuthProvider>
        <FinancialProvider>
          <AccountingProvider>
            <ExerciseProvider>
              <CalendarProvider>
                {children}
              </CalendarProvider>
            </ExerciseProvider>
          </AccountingProvider>
        </FinancialProvider>
      </AuthProvider>
    </NextThemesProvider>
  );
}
