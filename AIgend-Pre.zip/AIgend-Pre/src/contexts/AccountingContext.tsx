
'use client';

import { createContext, useState, useContext, useEffect, type ReactNode, useCallback } from 'react';
import { subDays, startOfToday } from 'date-fns';
import type { AccountingTransaction } from '@/lib/types';
import { useAuth } from './AuthContext';

const getLocalStorageKey = (uid: string) => `aigend-accounting-transactions-${uid}`;

interface AccountingContextType {
  transactions: AccountingTransaction[];
  loading: boolean;
  saveTransaction: (transactionData: Omit<AccountingTransaction, 'id'> | AccountingTransaction) => Promise<void>;
  deleteTransaction: (transactionId: string) => Promise<void>;
}

const AccountingContext = createContext<AccountingContextType | undefined>(undefined);

export function AccountingProvider({ children }: { children: ReactNode }) {
    const { user, loading: authLoading } = useAuth();
    const [transactions, setTransactions] = useState<AccountingTransaction[]>([]);
    const [loading, setLoading] = useState(true);

    const loadTransactions = useCallback((uid: string) => {
        setLoading(true);
        try {
            const key = getLocalStorageKey(uid);
            const storedData = localStorage.getItem(key);
            if (storedData) {
                const parsedData: AccountingTransaction[] = JSON.parse(storedData);
                const transactionsWithDates = parsedData.map(t => ({
                    ...t,
                    date: new Date(t.date)
                }));
                setTransactions(transactionsWithDates);
            } else {
                // Generate initial data on-demand on the client
                const today = startOfToday();
                const initialTransactions: AccountingTransaction[] = [
                    {
                        id: 't1',
                        type: 'income',
                        description: 'Monthly Salary',
                        amount: 3500,
                        date: subDays(today, 5)
                    },
                    {
                        id: 't2',
                        type: 'expense',
                        description: 'Groceries',
                        amount: 85.50,
                        date: subDays(today, 4)
                    },
                    {
                        id: 't3',
                        type: 'expense',
                        description: 'Internet Bill',
                        amount: 60,
                        date: subDays(today, 2)
                    },
                    {
                        id: 't4',
                        type: 'income',
                        description: 'Freelance Work',
                        amount: 450,
                        date: subDays(today, 1)
                    },
                    {
                        id: 't5',
                        type: 'expense',
                        description: 'Dinner with friends',
                        amount: 120,
                        date: today
                    }
                ];
                setTransactions(initialTransactions);
            }
        } catch (error) {
            console.error("Error loading transactions from localStorage:", error);
            // Fallback to empty if there's an error.
            setTransactions([]);
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        if (!authLoading && user) {
            loadTransactions(user.uid);
        } else if (!authLoading && !user) {
            setTransactions([]);
            setLoading(false);
        }
    }, [user?.uid, authLoading, loadTransactions]);
    
    const persistTransactions = (updatedTransactions: AccountingTransaction[]) => {
        setTransactions(updatedTransactions);
        if (user) {
            try {
                const key = getLocalStorageKey(user.uid);
                localStorage.setItem(key, JSON.stringify(updatedTransactions));
            } catch (error) {
                console.error("Error saving transactions to localStorage:", error);
            }
        }
    };

    const saveTransaction = async (transactionData: Omit<AccountingTransaction, 'id'> | AccountingTransaction) => {
        let updatedTransactions;
        if ('id' in transactionData) {
            updatedTransactions = transactions.map(t => t.id === transactionData.id ? transactionData : t);
        } else {
            const newTransaction: AccountingTransaction = {
                id: Math.random().toString(36).substr(2, 9),
                ...transactionData,
            };
            updatedTransactions = [...transactions, newTransaction];
        }
        persistTransactions(updatedTransactions);
    };

    const deleteTransaction = async (transactionId: string) => {
        const updatedTransactions = transactions.filter(t => t.id !== transactionId);
        persistTransactions(updatedTransactions);
    };

    return (
        <AccountingContext.Provider value={{ transactions, loading, saveTransaction, deleteTransaction }}>
            {children}
        </AccountingContext.Provider>
    );
}

export const useAccounting = () => {
  const context = useContext(AccountingContext);
  if (context === undefined) {
    throw new Error('useAccounting must be used within an AccountingProvider');
  }
  return context;
};
