
'use client';

import { createContext, useState, useContext, useEffect, type ReactNode } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User as FirebaseUser } from 'firebase/auth';
import { auth, googleProvider, isFirebaseEnabled } from '@/lib/firebase';
import { usePathname, useRouter } from 'next/navigation';
import { useLocale } from 'next-intl';

interface AuthContextType {
  user: FirebaseUser | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  isFirebaseEnabled: boolean;
  authError: string | null;
  authErrorDetails: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authErrorDetails, setAuthErrorDetails] = useState<string | null>(null);
  const router = useRouter();
  const pathname = usePathname();
  const locale = useLocale();

  useEffect(() => {
    if (!isFirebaseEnabled) {
      setUser(null);
      setLoading(false);
      return;
    }

    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        setAuthError(null);
        setAuthErrorDetails(null);
      } else {
        setUser(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    if (!isFirebaseEnabled || !auth || !googleProvider) {
        console.warn("Firebase Auth is not configured. Cannot sign in.");
        return;
    }
    setLoading(true);
    setAuthError(null);
    setAuthErrorDetails(null);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error: any) {
      const hostname = window.location.hostname;
      console.error(`Firebase Auth Error Code: ${error.code}`);
      console.error(`Auth attempt from domain: ${hostname}`);
      
      if (error.code === 'auth/unauthorized-domain') {
          setAuthError('unauthorizedDomainError');
          setAuthErrorDetails(hostname);
      } else {
          console.error("Error signing in with Google", error);
          setAuthError('genericSignInError');
          setAuthErrorDetails(null);
      }
      setLoading(false);
    }
  };

  const logout = async () => {
    if (user) {
        // Clear all localStorage keys associated with the user's UID for a clean logout
        Object.keys(localStorage)
            .filter(key => key.includes(user.uid))
            .forEach(key => localStorage.removeItem(key));
    }
    
    if (isFirebaseEnabled && auth.currentUser) {
        await signOut(auth);
    }
    // The onAuthStateChanged listener will automatically handle setting user to null.
  };

  useEffect(() => {
    if (loading) return; // Wait until loading is complete

    const isLoginPage = pathname.endsWith('/login');

    if (!user && !isLoginPage) {
      router.push(`/${locale}/login`);
    } else if (user && isLoginPage) {
      router.push(`/${locale}`);
    }
  }, [user, loading, router, pathname, locale]);

  return (
    <AuthContext.Provider value={{ user, loading, signInWithGoogle, logout, isFirebaseEnabled, authError, authErrorDetails }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
