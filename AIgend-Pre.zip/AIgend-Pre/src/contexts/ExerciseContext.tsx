'use client';

import { createContext, useState, useContext, useEffect, type ReactNode, useCallback } from 'react';
import type { ExerciseGuideOutput } from '@/ai/schemas';
import { getExerciseGuide } from '@/ai/flows/exercise-guide-flow';
import type { LoggedWorkout } from '@/lib/types';
import { useAuth } from './AuthContext';


const GUIDES_STORAGE_KEY = 'aigend-exercise-guides';
const LOGS_STORAGE_KEY_PREFIX = 'aigend-workout-logs-';

interface ExerciseContextType {
  guides: { [exerciseName: string]: ExerciseGuideOutput };
  loadingGuides: { [exerciseName: string]: boolean };
  getGuide: (exerciseName: string, locale: string) => Promise<ExerciseGuideOutput>;
  loggedWorkouts: LoggedWorkout[];
  logWorkout: (workout: Omit<LoggedWorkout, 'id'>) => Promise<void>;
  loadingLogs: boolean;
}

const ExerciseContext = createContext<ExerciseContextType | undefined>(undefined);

export function ExerciseProvider({ children }: { children: ReactNode }) {
    const { user, loading: authLoading } = useAuth();
    const [guides, setGuides] = useState<{ [key: string]: ExerciseGuideOutput }>({});
    const [loadingGuides, setLoadingGuides] = useState<{ [key: string]: boolean }>({});
    const [loggedWorkouts, setLoggedWorkouts] = useState<LoggedWorkout[]>([]);
    const [loadingLogs, setLoadingLogs] = useState(true);

    useEffect(() => {
        try {
            const storedData = localStorage.getItem(GUIDES_STORAGE_KEY);
            if (storedData) {
                setGuides(JSON.parse(storedData));
            }
        } catch (error) {
            console.error("Error loading exercise guides from localStorage:", error);
        }
    }, []);

    const persistGuides = (updatedGuides: { [key: string]: ExerciseGuideOutput }) => {
        setGuides(updatedGuides);
        try {
            localStorage.setItem(GUIDES_STORAGE_KEY, JSON.stringify(updatedGuides));
        } catch (error) {
            console.error("Error saving exercise guides to localStorage:", error);
        }
    };

    const getGuide = useCallback(async (exerciseName: string, locale: string): Promise<ExerciseGuideOutput> => {
        const lowerCaseExerciseName = exerciseName.toLowerCase();
        if (guides[lowerCaseExerciseName]) {
            return guides[lowerCaseExerciseName];
        }

        setLoadingGuides(prev => ({ ...prev, [lowerCaseExerciseName]: true }));
        try {
            const result = await getExerciseGuide({ exerciseName, locale });
            const newGuides = { ...guides, [lowerCaseExerciseName]: result };
            persistGuides(newGuides);
            return result;
        } catch (error) {
            console.error(`Error fetching guide for ${exerciseName}:`, error);
            throw error; 
        } finally {
            setLoadingGuides(prev => ({ ...prev, [lowerCaseExerciseName]: false }));
        }
    }, [guides]);


    // New workout logging logic
    const loadLoggedWorkouts = useCallback((uid: string) => {
        setLoadingLogs(true);
        try {
            const key = `${LOGS_STORAGE_KEY_PREFIX}${uid}`;
            const storedData = localStorage.getItem(key);
            if (storedData) {
                const parsedData: LoggedWorkout[] = JSON.parse(storedData);
                const workoutsWithDates = parsedData.map(w => ({
                    ...w,
                    date: new Date(w.date)
                }));
                setLoggedWorkouts(workoutsWithDates);
            } else {
                setLoggedWorkouts([]);
            }
        } catch (error) {
            console.error("Error loading workout logs from localStorage:", error);
            setLoggedWorkouts([]);
        } finally {
            setLoadingLogs(false);
        }
    }, []);

    useEffect(() => {
        if (!authLoading && user) {
            loadLoggedWorkouts(user.uid);
        } else if (!authLoading && !user) {
            setLoggedWorkouts([]);
            setLoadingLogs(false);
        }
    }, [user?.uid, authLoading, loadLoggedWorkouts]);

    const persistLogs = (updatedLogs: LoggedWorkout[]) => {
        setLoggedWorkouts(updatedLogs);
        if (user) {
            try {
                const key = `${LOGS_STORAGE_KEY_PREFIX}${user.uid}`;
                localStorage.setItem(key, JSON.stringify(updatedLogs));
            } catch (error) {
                console.error("Error saving workout logs to localStorage:", error);
            }
        }
    };
    
    const logWorkout = async (workout: Omit<LoggedWorkout, 'id'>) => {
        const newLog: LoggedWorkout = {
            id: `log-${Date.now()}`,
            ...workout
        };
        const updatedLogs = [...loggedWorkouts, newLog].sort((a,b) => b.date.getTime() - a.date.getTime());
        persistLogs(updatedLogs);
    };


    return (
        <ExerciseContext.Provider value={{ guides, loadingGuides, getGuide, loggedWorkouts, logWorkout, loadingLogs }}>
            {children}
        </ExerciseContext.Provider>
    );
}

export const useExercise = () => {
  const context = useContext(ExerciseContext);
  if (context === undefined) {
    throw new Error('useExercise must be used within an ExerciseProvider');
  }
  return context;
};
