'use client';

import { createContext, useState, useContext, useEffect, type ReactNode, useCallback } from 'react';
import type { PersonalData } from '@/lib/types';
import { useAuth } from './AuthContext';

const defaultPersonalData: PersonalData = {
    firstName: "",
    totalMonthlyIncome: 0,
    fixedMonthlyExpenses: 0,
    variableMonthlyExpenses: 0,
    totalDebt: 0,
    liquidSavings: 0,
    monthlyInvestment: 0,
    goals: [],
    age: undefined,
    weight: undefined,
    height: undefined,
    sex: undefined,
    activityLevel: undefined,
    allergies: "",
    nutritionalGoal: undefined,
    fitnessGoal: undefined,
    availableEquipment: "",
    trainingFacilities: undefined,
    injuries: "",
    dietaryPreferences: undefined,
    favoriteFoods: "",
    country: "",
    spiceLevel: 2,
    foodGroupPreferences: {
        vegetables: 4,
        fruits: 4,
        redMeat: 3,
        poultry: 5,
        fish: 3,
        legumes: 2,
    },
};

const getLocalStorageKey = (uid: string) => `aigend-personal-data-${uid}`;


interface FinancialContextType {
  financialData: PersonalData;
  setFinancialData: (data: PersonalData) => Promise<void>;
  loading: boolean;
}

const FinancialContext = createContext<FinancialContextType | undefined>(undefined);

export function FinancialProvider({ children }: { children: ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const [financialData, setFinancialDataState] = useState<PersonalData>(defaultPersonalData);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback((uid: string) => {
    setLoading(true);
    try {
        const key = getLocalStorageKey(uid);
        const storedData = localStorage.getItem(key);
        if (storedData) {
            const parsedData = JSON.parse(storedData);
            // Merge with defaults to ensure all keys are present after updates
            setFinancialDataState({ ...defaultPersonalData, ...parsedData });
        } else {
            setFinancialDataState(defaultPersonalData);
        }
    } catch (error) {
        console.error("Error loading data from localStorage:", error);
        setFinancialDataState(defaultPersonalData);
    } finally {
        setLoading(false);
    }
  }, []);

  useEffect(() => {
    // This check is to avoid errors during server-side rendering
    if (typeof window === 'undefined') {
        setLoading(false);
        return;
    }
    
    if (!authLoading && user) {
      loadData(user.uid);
    } else if (!authLoading && !user) {
      // No user, reset to default and stop loading
      setFinancialDataState(defaultPersonalData);
      setLoading(false);
    }
  }, [user?.uid, authLoading, loadData]);

  const setFinancialData = async (data: PersonalData) => {
    // Update local state immediately for responsiveness
    setFinancialDataState(data);
    
    // Persist to localStorage if there's a user
    if (user) {
        try {
            const key = getLocalStorageKey(user.uid);
            localStorage.setItem(key, JSON.stringify(data));
        } catch (error) {
            console.error("Error saving data to localStorage:", error);
        }
    } else {
        console.warn("Cannot persist data: no user is authenticated.");
    }
  };

  return (
    <FinancialContext.Provider value={{ financialData, setFinancialData, loading: loading || authLoading }}>
      {children}
    </FinancialContext.Provider>
  );
}

export const useFinancialData = () => {
    const context = useContext(FinancialContext);
    if (context === undefined) {
        throw new Error('useFinancialData must be used within a FinancialProvider');
    }
    return context;
};
