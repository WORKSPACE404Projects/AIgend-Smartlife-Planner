
'use client';

import { createContext, useState, useContext, useEffect, type ReactNode, useCallback } from 'react';
import { addDays, addHours, setHours, setMinutes, startOfDay, startOfWeek, endOfWeek, subDays, startOfToday } from 'date-fns';
import type { CalendarEvent } from '@/lib/types';
import type { DietCoachOutput, DailyMenu as DietDailyMenu, FitnessCoachOutput, DailyWorkoutSchema as FitnessDailyWorkout } from '@/ai/schemas';
import { useAuth } from './AuthContext';

const getLocalStorageKey = (uid: string) => `aigend-calendar-events-${uid}`;

interface CalendarContextType {
  events: CalendarEvent[];
  loading: boolean;
  saveEvent: (eventData: Omit<CalendarEvent, 'id'> | CalendarEvent) => Promise<void>;
  deleteEvent: (eventId: string) => Promise<void>;
  saveDietPlanAsEvents: (weeklyMenu: DietCoachOutput['weeklyMenu']) => Promise<void>;
  saveWorkoutPlanAsEvents: (weeklyPlan: FitnessCoachOutput['weeklyPlan']) => Promise<void>;
}

const CalendarContext = createContext<CalendarContextType | undefined>(undefined);

export function CalendarProvider({ children }: { children: ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(true);

  const loadEvents = useCallback((uid: string) => {
    setLoading(true);
    try {
      const key = getLocalStorageKey(uid);
      const storedData = localStorage.getItem(key);
      if (storedData) {
        const parsedData: CalendarEvent[] = JSON.parse(storedData);
        // Dates are stored as strings in JSON, so we need to convert them back to Date objects
        const eventsWithDates = parsedData.map(e => ({
            ...e,
            start: new Date(e.start),
            end: new Date(e.end)
        }));
        setEvents(eventsWithDates);
      } else {
        // Generate initial data on-demand on the client
        const today = startOfToday();
        const initialEvents: CalendarEvent[] = [
          {
            id: '1',
            title: "Project Kick-off Meeting",
            start: addHours(today, 10),
            end: addHours(today, 11),
            allDay: false,
            description: "Initial meeting to discuss the new project timeline.",
            category: 'general'
          },
          {
            id: '2',
            title: "Design Review",
            start: addDays(today, 1),
            end: addDays(today, 1),
            allDay: true,
            description: "Review of the new UI/UX mockups.",
            category: 'general'
          },
          {
            id: '3',
            title: "Dentist Appointment",
            start: addHours(subDays(today, 2), 14),
            end: addHours(subDays(today, 2), 15),
            allDay: false,
            description: "Routine check-up.",
            category: 'general'
          },
           {
            id: '4',
            title: "Team Lunch",
            start: addHours(today, 12),
            end: addHours(today, 13),
            allDay: false,
            category: 'general'
          }
        ];
        setEvents(initialEvents);
      }
    } catch (error) {
      console.error("Error loading events from localStorage:", error);
      // Fallback to empty array on error
      setEvents([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!authLoading && user) {
      loadEvents(user.uid);
    } else if (!authLoading && !user) {
      setEvents([]);
      setLoading(false);
    }
  }, [user?.uid, authLoading, loadEvents]);

  const persistEvents = (updatedEvents: CalendarEvent[]) => {
    setEvents(updatedEvents);
    if (user) {
      try {
        const key = getLocalStorageKey(user.uid);
        localStorage.setItem(key, JSON.stringify(updatedEvents));
      } catch (error) {
        console.error("Error saving events to localStorage:", error);
      }
    }
  };

  const saveEvent = async (eventData: Omit<CalendarEvent, 'id'> | CalendarEvent) => {
    let updatedEvents;
    if ('id' in eventData) {
      updatedEvents = events.map(e => e.id === eventData.id ? eventData : e);
    } else {
      const newEvent: CalendarEvent = {
        id: Math.random().toString(36).substr(2, 9),
        category: 'general',
        ...eventData,
      };
      updatedEvents = [...events, newEvent];
    }
    persistEvents(updatedEvents);
  };

  const deleteEvent = async (eventId: string) => {
    const updatedEvents = events.filter(e => e.id !== eventId);
    persistEvents(updatedEvents);
  };

  const saveDietPlanAsEvents = async (weeklyMenu: DietDailyMenu[]) => {
    // 1. Remove all existing diet events for the current week to avoid duplicates
    const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
    const weekEndVal = endOfWeek(new Date(), { weekStartsOn: 1 });
    
    const nonDietEvents = events.filter(e => {
        if (e.category === 'diet') {
            const eventDate = startOfDay(e.start);
            return !(eventDate >= weekStart && eventDate <= weekEndVal);
        }
        return true;
    });

    // 2. Define meal times and color
    const mealTimes = {
      breakfast: { start: 8, end: 9 },
      lunch: { start: 13, end: 14 },
      dinner: { start: 19, end: 20 },
    };
    const snackTimes = [
      { start: { hour: 11, minute: 0 }, end: { hour: 11, minute: 30 } },
      { start: { hour: 17, minute: 0 }, end: { hour: 17, minute: 30 } },
    ];
    const dietEventColor = 'hsl(var(--chart-1))';

    // 3. Create new events for the meal plan
    const newDietEvents: CalendarEvent[] = [];
    weeklyMenu.forEach((dailyMenu, dayIndex) => {
        const dayOfPlan = addDays(weekStart, dayIndex);

        // Add Breakfast, Lunch, Dinner
        (['breakfast', 'lunch', 'dinner'] as const).forEach(mealType => {
            const meal = dailyMenu[mealType];
            const times = mealTimes[mealType];
            if (meal?.name && times) {
                newDietEvents.push({
                    id: `diet-${dayIndex}-${mealType}-${Date.now()}`,
                    title: meal.name,
                    description: meal.description,
                    start: setHours(setMinutes(dayOfPlan, 0), times.start),
                    end: setHours(setMinutes(dayOfPlan, 0), times.end),
                    allDay: false,
                    category: 'diet',
                    color: dietEventColor
                });
            }
        });

        // Add snacks
        if (dailyMenu.snacks && dailyMenu.snacks.length > 0) {
            dailyMenu.snacks.forEach((snack, snackIndex) => {
                const times = snackTimes[snackIndex % snackTimes.length];
                if (snack.name && times) {
                    newDietEvents.push({
                        id: `diet-snack-${dayIndex}-${snackIndex}-${Date.now()}`,
                        title: `Snack: ${snack.name}`,
                        description: snack.description,
                        start: setHours(setMinutes(dayOfPlan, times.start.minute), times.start.hour),
                        end: setHours(setMinutes(dayOfPlan, times.end.minute), times.end.hour),
                        allDay: false,
                        category: 'diet',
                        color: dietEventColor
                    });
                }
            });
        }
    });

    persistEvents([...nonDietEvents, ...newDietEvents]);
  };
  
  const saveWorkoutPlanAsEvents = async (weeklyPlan: FitnessDailyWorkout[]) => {
    // 1. Remove existing fitness events for the current week
    const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
    const weekEndVal = endOfWeek(new Date(), { weekStartsOn: 1 });

    const nonFitnessEvents = events.filter(e => {
        if (e.category === 'fitness') {
            const eventDate = startOfDay(e.start);
            return !(eventDate >= weekStart && eventDate <= weekEndVal);
        }
        return true;
    });

    // 2. Create new events for the workout plan
    const newFitnessEvents: CalendarEvent[] = [];
    const workoutTime = { start: 18, end: 19 }; // Default to 6 PM - 7 PM
    const fitnessEventColor = 'hsl(var(--chart-4))';

    weeklyPlan.forEach((dailyWorkout, dayIndex) => {
        if (dailyWorkout.exercises.length > 0) { // Only create events for days with exercises
            const dayOfPlan = addDays(weekStart, dayIndex);
            
            newFitnessEvents.push({
                id: `fitness-${dayIndex}-${Date.now()}`,
                title: dailyWorkout.focus,
                description: dailyWorkout.exercises.map(ex => `${ex.name}: ${ex.sets} sets of ${ex.reps}`).join('\n'),
                start: setHours(setMinutes(dayOfPlan, 0), workoutTime.start),
                end: setHours(setMinutes(dayOfPlan, 0), workoutTime.end),
                allDay: false,
                category: 'fitness',
                color: fitnessEventColor,
            });
        }
    });
    
    persistEvents([...nonFitnessEvents, ...newFitnessEvents]);
  };

  return (
    <CalendarContext.Provider value={{ events, loading, saveEvent, deleteEvent, saveDietPlanAsEvents, saveWorkoutPlanAsEvents }}>
      {children}
    </CalendarContext.Provider>
  );
}

export const useCalendar = () => {
  const context = useContext(CalendarContext);
  if (context === undefined) {
    throw new Error('useCalendar must be used within a CalendarProvider');
  }
  return context;
};
