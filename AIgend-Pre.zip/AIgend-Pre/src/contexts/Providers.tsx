
'use client';

import { ThemeProvider as NextThemesProvider } from 'next-themes';
import { type ThemeProviderProps } from 'next-themes/dist/types';
import { AuthProvider } from '@/contexts/AuthContext';
import { FinancialProvider } from '@/contexts/FinancialContext';
import { CalendarProvider } from '@/contexts/CalendarContext';
import { AccountingProvider } from '@/contexts/AccountingContext';

export function Providers({ children, ...props }: ThemeProviderProps) {
  return (
    <NextThemesProvider {...props}>
      <AuthProvider>
        <FinancialProvider>
          <AccountingProvider>
            <CalendarProvider>
              {children}
            </CalendarProvider>
          </AccountingProvider>
        </FinancialProvider>
      </AuthProvider>
    </NextThemesProvider>
  );
}
